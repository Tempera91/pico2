# © 2021 Microchip Technology Inc. and its subsidiaries
#
# Subject to your compliance with these terms, you may use Microchip software
# and any derivatives exclusively with Microchip products. You're responsible
# for complying with 3rd party license terms applicable to your use of 3rd party
# software (including open source software) that may accompany Microchip software.
# SOFTWARE IS "AS IS." NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY,
# APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,
# MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP
# BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS,
# DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER
# CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
# FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY
# ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT EXCEED AMOUNT OF FEES, IF ANY,
# YOU PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

# PAC194x5x Python Library Version 1.0.0

import sys
import os
import struct
import time
import numpy as np
sys.path.append('/Users/Me/python/modules')


class PAC194x5x:
    PAC1941_PRODUCT_ID = 104
    PAC1942_1_PRODUCT_ID = 105
    PAC1943_PRODUCT_ID = 106
    PAC1944_PRODUCT_ID = 107
    PAC1941_2_PRODUCT_ID = 108
    PAC1942_2_PRODUCT_ID = 109
    PAC1951_PRODUCT_ID = 120
    PAC1952_1_PRODUCT_ID = 121
    PAC1953_PRODUCT_ID = 122
    PAC1954_PRODUCT_ID = 123
    PAC1951_2_PRODUCT_ID = 124
    PAC1952_2_PRODUCT_ID = 125

    REFRESH = 0
    REFRESH_G = 1
    REFRESH_V = 2

    VBUS_SCALE_9 = 9
    VBUS_SCALE_32 = 32
    VSENSE_SCALE_100MV = 100

    SAMPLE_MODE_1024_ADAPTIVE = 0
    SAMPLE_MODE_256_ADAPTIVE = 1
    SAMPLE_MODE_64_ADAPTIVE = 2
    SAMPLE_MODE_8_ADAPTIVE = 3
    SAMPLE_MODE_1024 = 4
    SAMPLE_MODE_256 = 5
    SAMPLE_MODE_64 = 6
    SAMPLE_MODE_8 = 7
    SAMPLE_MODE_SINGLE_SHOT = 8
    SAMPLE_MODE_SINGLE_SHOT_8X = 9
    SAMPLE_MODE_FAST = 10
    SAMPLE_MODE_BURST = 11
    SAMPLE_MODE_SLEEP = 15

    TOTAL_NUMBER_OF_BYTES = 163

    # Error code
    NO_ERRORS = 0
    ERROR_INPUT_PARAMETER = 8
    ERROR_MCP2221_BRIDGE_MISSING = 9

    # 'REGISTER_NAME': [i2c_address, no_of_bytes]
    registers_addresses = {'REFRESH': [0, 0],
                           'CTRL': [0x01, 2],
                           'ACC_COUNT': [0x2, 4],
                           'VACC1': [0x3, 7],
                           'VACC2': [0x4, 7],
                           'VACC3': [0x5, 7],
                           'VACC4': [0x6, 7],
                           'VBUS1': [0x7, 2],
                           'VBUS2': [0x8, 2],
                           'VBUS3': [0x9, 2],
                           'VBUS4': [0xA, 2],
                           'VSENSE1': [0xB, 2],
                           'VSENSE2': [0xC, 2],
                           'VSENSE3': [0xD, 2],
                           'VSENSE4': [0xE, 2],
                           'VBUS1_AVG': [0xF, 2],
                           'VBUS2_AVG': [0x10, 2],
                           'VBUS3_AVG': [0x11, 2],
                           'VBUS4_AVG': [0x12, 2],
                           'VSENSE1_AVG': [0x13, 2],
                           'VSENSE2_AVG': [0x14, 2],
                           'VSENSE3_AVG': [0x15, 2],
                           'VSENSE4_AVG': [0x16, 2],
                           'VPOWER1': [0x17, 4],
                           'VPOWER2': [0x18, 4],
                           'VPOWER3': [0x19, 4],
                           'VPOWER4': [0x1A, 4],
                           'SMBUS': [0x1C, 1],
                           'NEG_PWR_FSR': [0x1D, 2],
                           'REFRESH_G': [0x1E, 0],
                           'REFRESH_V': [0x1F, 0],
                           'SLOW': [0x20, 1],
                           'CTRL_ACT': [0x21, 2],
                           'NEG_PWR_FSR_ACT': [0x22, 2],
                           'CTRL_LAT': [0x23, 2],
                           'NEG_PWR_FSR_LAT': [0x24, 2],
                           'ACCUM_CONFIG': [0x25, 1],
                           'ALERT_STATUS': [0x26, 3],
                           'SLOW_ALERT1': [0x27, 3],
                           'GPIO_ALERT2': [0x28, 3],
                           'ACC_FULLNESS_LIMITS': [0x29, 2],
                           'OC_LIMIT_1': [0x30, 2],
                           'OC_LIMIT_2': [0x31, 2],
                           'OC_LIMIT_3': [0x32, 2],
                           'OC_LIMIT_4': [0x33, 2],
                           'UC_LIMIT_1': [0x34, 2],
                           'UC_LIMIT_2': [0x35, 2],
                           'UC_LIMIT_3': [0x36, 2],
                           'UC_LIMIT_4': [0x37, 2],
                           'OP_LIMIT_1': [0x38, 3],
                           'OP_LIMIT_2': [0x39, 3],
                           'OP_LIMIT_3': [0x3A, 3],
                           'OP_LIMIT_4': [0x3B, 3],
                           'OV_LIMIT_1': [0x3C, 2],
                           'OV_LIMIT_2': [0x3D, 2],
                           'OV_LIMIT_3': [0x3E, 2],
                           'OV_LIMIT_4': [0x3F, 2],
                           'UV_LIMIT_1': [0x40, 2],
                           'UV_LIMIT_2': [0x41, 2],
                           'UV_LIMIT_3': [0x42, 2],
                           'UV_LIMIT_4': [0x43, 2],
                           'OC_LIMIT_NSAMPLES': [0x44, 1],
                           'UC_LIMIT_NSAMPLES': [0x45, 1],
                           'OP_LIMIT_NSAMPLES': [0x46, 1],
                           'OV_LIMIT_NSAMPLES': [0x47, 1],
                           'UV_LIMIT_NSAMPLES': [0x48, 1],
                           'ALERT_ENABLE': [0x49, 3],
                           'ACCUM_CONFIG_ACT': [0x4A, 1],
                           'ACCUM_CONFIG_LAT': [0x4B, 1],
                           'PRODUCT_ID': [0xFD, 1],
                           'MANUFACTURER_ID': [0xFE, 1],
                           'REVISION_ID': [0xFF, 1]
                           }

    def __init__(self, i2c_address=0x20,
                 mcp2221_i2c_bridge=None,
                 rsense1=0.004, rsense2=0.004,
                 rsense3=0.004, rsense4=0.004,
                 voltage_ratio1=1, voltage_ratio2=1,
                 voltage_ratio3=1, voltage_ratio4=1):
        """
        Description: Represents the constructor of the pac194x5x class. Its purpose is to create the object and to
        correctly set the communication parameters in order to interact with the chip. The user can also set the Rsense
        values for each channel and the voltage ratios. After the connection is established, the SMBUS register is read
        in order to determine the communication protocol. The constructor will read the Product ID to determine what
        type of device is used.

        :param i2c_address: Represents the i2c address of the device that is accessed via MCP2221.
        :param mcp2221_i2c_bridge: Represents a mcp2221 object that allows the library to communicate with the device
                                   using the methods provided by mcp2221.py.
        :param rsense1: Represents the sense resistor value measured in Ohms for channel 1
        :param rsense2: Represents the sense resistor value measured in Ohms for channel 2
        :param rsense3: Represents the sense resistor value measured in Ohms for channel 3
        :param rsense4: Represents the sense resistor value measured in Ohms for channel 4
        :param voltage_ratio1: Represents the ratio corresponding to CH1 used to determine the voltage coefficient for
                               the low side devices. (coefficient = 1 / ratio). The default value is 1, but it should be
                               customized according to your hardware configuration.
        :param voltage_ratio2: Represents the ratio corresponding to CH2 used to determine the voltage coefficient for
                               the low side devices. (coefficient = 1 / ratio). The default value is 1, but it should be
                               customized according to your hardware configuration.
        :param voltage_ratio3: Represents the ratio corresponding to CH3 used to determine the voltage coefficient for
                               the low side devices. (coefficient = 1 / ratio). The default value is 1, but it should be
                               customized according to your hardware configuration.
        :param voltage_ratio4: Represents the ratio corresponding to CH4 used to determine the voltage coefficient for
                               the low side devices. (coefficient = 1 / ratio). The default value is 1, but it should be
                               customized according to your hardware configuration.
        """
        # Bridge communication access
        self.mcp2221 = mcp2221_i2c_bridge
        # Client address
        self.i2c_address = i2c_address
        # device type: 0 for pac194x; 1 for pac195x
        self.pac5x = 0
        # Sense resistors values for each channel
        self.rsense = np.empty(4)
        self.rsense[0] = rsense1
        self.rsense[1] = rsense2
        self.rsense[2] = rsense3
        self.rsense[3] = rsense4
        self.voltage_ratio = np.empty(4)
        self.voltage_ratio[0] = 1 / voltage_ratio1
        self.voltage_ratio[1] = 1 / voltage_ratio2
        self.voltage_ratio[2] = 1 / voltage_ratio3
        self.voltage_ratio[3] = 1 / voltage_ratio4

        # Energy unit used in defining the real value of the energy
        self.energy_unit = pow(10, 12) / 3.6  # 3.6 is for conversion from W to Wh and 10^12 is for pico Display
        # Specifies if the device uses i2c or smbus protocol for communication
        self.i2c_communication_protocol = True

        # set default values
        # Keeping track of current and previous timestamp
        self.time_stamp = 0
        self.prev_timestamp = 0
        # Number of available channels according to the device type
        self.active_channels = 0
        # Stores the last error occurrence
        self.last_error = 0

        # Dictionary that can store the raw values of the registers
        self.registers_values = {'control': 0,
                                 'acc_count': 0,
                                 'vacc_ch1': 0,
                                 'vacc_ch2': 0,
                                 'vacc_ch3': 0,
                                 'vacc_ch4': 0,
                                 'vbus_ch1': 0,
                                 'vbus_ch2': 0,
                                 'vbus_ch3': 0,
                                 'vbus_ch4': 0,
                                 'vsense_ch1': 0,
                                 'vsense_ch2': 0,
                                 'vsense_ch3': 0,
                                 'vsense_ch4': 0,
                                 'vbus_avg_ch1': 0,
                                 'vbus_avg_ch2': 0,
                                 'vbus_avg_ch3': 0,
                                 'vbus_avg_ch4': 0,
                                 'vsense_avg_ch1': 0,
                                 'vsense_avg_ch2': 0,
                                 'vsense_avg_ch3': 0,
                                 'vsense_avg_ch4': 0,
                                 'vpower_ch1': 0,
                                 'vpower_ch2': 0,
                                 'vpower_ch3': 0,
                                 'vpower_ch4': 0,
                                 'smbus': 0,
                                 'neg_pwr_fsr': 0,
                                 'slow': 0,
                                 'control_act': 0,
                                 'neg_pwr_fsr_act': 0,
                                 'control_lat': 0,
                                 'neg_pwr_fsr_lat': 0,
                                 'accum_config': 0,
                                 'alert_status': 0,
                                 'slow_alert1': 0,
                                 'gpio_alert2': 0,
                                 'acc_fullness_limits': 0,
                                 'oc_limit_ch1': 0,
                                 'oc_limit_ch2': 0,
                                 'oc_limit_ch3': 0,
                                 'oc_limit_ch4': 0,
                                 'uc_limit_ch1': 0,
                                 'uc_limit_ch2': 0,
                                 'uc_limit_ch3': 0,
                                 'uc_limit_ch4': 0,
                                 'op_limit_ch1': 0,
                                 'op_limit_ch2': 0,
                                 'op_limit_ch3': 0,
                                 'op_limit_ch4': 0,
                                 'ov_limit_ch1': 0,
                                 'ov_limit_ch2': 0,
                                 'ov_limit_ch3': 0,
                                 'ov_limit_ch4': 0,
                                 'uv_limit_ch1': 0,
                                 'uv_limit_ch2': 0,
                                 'uv_limit_ch3': 0,
                                 'uv_limit_ch4': 0,
                                 'oc_limit_nsample': 0,
                                 'uc_limit_nsample': 0,
                                 'op_limit_nsample': 0,
                                 'ov_limit_nsample': 0,
                                 'uv_limit_nsample': 0,
                                 'alert_enable': 0,
                                 'accum_config_act': 0,
                                 'accum_config_lat': 0,
                                 'product_id': 0,
                                 'manufacturer_id': 0,
                                 'revision_id': 0
                                 }

        result = self.mcp2221.SMBus_Block_Read(self.i2c_address, usePec=0,
                                               regAddr=self.registers_addresses['SMBUS'][0],
                                               byteCount=self.registers_addresses['SMBUS'][1])
        result = int.from_bytes(result, byteorder='big', signed=False)
        self.i2c_communication_protocol = not bool(self.get_bits_value(result, 1, 2))

        if self.mcp2221:
            # identify if the device is pac4x or 5x
            res = self.get_product_id()

            if res == self.PAC1941_PRODUCT_ID:
                self.pac5x = 0
                self.active_channels = 1
            elif res == self.PAC1942_1_PRODUCT_ID:
                self.pac5x = 0
                self.active_channels = 2
            elif res == self.PAC1943_PRODUCT_ID:
                self.pac5x = 0
                self.active_channels = 3
            elif res == self.PAC1944_PRODUCT_ID:
                self.pac5x = 0
                self.active_channels = 4
            elif res == self.PAC1941_2_PRODUCT_ID:
                self.pac5x = 0
                self.active_channels = 1
            elif res == self.PAC1942_2_PRODUCT_ID:
                self.pac5x = 0
                self.active_channels = 2
            elif res == self.PAC1951_PRODUCT_ID:
                self.pac5x = 1
                self.active_channels = 1
            elif res == self.PAC1952_1_PRODUCT_ID:
                self.pac5x = 1
                self.active_channels = 2
            elif res == self.PAC1953_PRODUCT_ID:
                self.pac5x = 1
                self.active_channels = 3
            elif res == self.PAC1954_PRODUCT_ID:
                self.pac5x = 1
                self.active_channels = 4
            elif res == self.PAC1951_2_PRODUCT_ID:
                self.pac5x = 1
                self.active_channels = 1
            elif res == self.PAC1952_2_PRODUCT_ID:
                self.pac5x = 1
                self.active_channels = 2
        else:
            print('PAC194x5x access error! Exit.')
            self.mcp2221.Close()
            exit()

        result = self.send_refresh(0)

        if result != 0:
            self.last_error = result

    # Registers & Measurements

    def refresh(self, delay=0.128):
        """
        Description: Sends a simple Refresh command to the device using the mcp2221.py writing method to the 0x00
        address of the device. After the command is sent, the program waits for a configurable number of seconds, so it
        makes sure the command has taken effect. The method updates the previous and current timestamp.

        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_MCP2221_BRIDGE_MISSING, if no mcp2221 bridge has been added to the pac194x5x attributes
        """
        if self.mcp2221:
            result = self.mcp2221.I2C_Write(self.i2c_address, [self.registers_addresses['REFRESH'][0]])
            if result == 0:
                time.sleep(delay)
                self.prev_timestamp = self.time_stamp
                self.time_stamp = time.time()
        else:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            result = self.ERROR_MCP2221_BRIDGE_MISSING
        return result

    def set_control(self, ctrl_value, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value for the Control register using the mcp2221.py writing method at the 0x01 address
        of the device and if, the refresh type has been added, it will send a refresh command for the settings to take
        effect. After that, it will wait for a configurable number of seconds,to make sure the command has taken effect.

        :param ctrl_value: Bits 15:0; Represents the new Control register value for the chip. Note that if the parameter
                           is out of the expected range, an OverflowError will occur as the method expects 2 bytes.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the ctrl_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if ctrl_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        # write CTRL register
        value = ctrl_value.to_bytes(self.registers_addresses['CTRL'][1], 'big', signed=False)
        if len(value) > self.registers_addresses['CTRL'][1]:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        address = self.registers_addresses['CTRL'][0]
        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0], value[1]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
        return result

    def get_control(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the Control register data using the mcp2221.py reading method from the 0x01 address of the
        device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 15:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['CTRL'][0],
                                              no_of_bytes=self.registers_addresses['CTRL'][1],
                                              signed=False)
        return result

    def get_acc_count(self, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Gets the Acc_Count register data using the mcp2221.py reading method from the 0x02 address of the
        device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: Bits 31:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None

        if use_list is False:
            result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['ACC_COUNT'][0],
                                                  no_of_bytes=self.registers_addresses['ACC_COUNT'][1],
                                                  signed=False)
        else:
            result = self.registers_values['acc_count']

        return result

    def get_vacc(self, channel_index, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Gets the Vacc_N register real data using the mcp2221.py reading method from one of the 0x03, 0x04,
        0x05 or 0x06 addresses of the device which corresponds to the assigned channel of the device. (N is considered
        1, 2, 3 or 4). A Refresh command will be sent to the device before reading the register value if the
        refresh_type parameter has been added.

        :param channel_index: This selects for which channel to get the Vacc register data. It takes one of the values:
                              1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: Bits 55:0 converted to W or V, if successful;
                 None, otherwise.
        """
        if self.mcp2221:
            if (channel_index is None) | (channel_index > 4):
                self.last_error = self.ERROR_INPUT_PARAMETER
                return None

            if refresh_type is not None:
                result = self.send_refresh(refresh_type=refresh_type, delay=delay)
                if result != 0:
                    self.last_error = result
                    return None

            config = self.get_ch_accum_config(channel_index=channel_index, use_list=use_list)

            if config == 0:
                bidir_v, _ = self.get_bidir_fsr_v_lat(channel_index=channel_index, use_list=use_list)
                bidir_i, _ = self.get_bidir_fsr_i_lat(channel_index=channel_index, use_list=use_list)
                bidir = (bidir_v | bidir_i)
                unit = self.get_power_unit(channel_index=channel_index, use_list=use_list)
            elif config == 1:
                bidir, _ = self.get_bidir_fsr_i_lat(channel_index=channel_index, use_list=use_list)
                unit = self.get_vsense_lsb(channel_index=channel_index, use_list=use_list)
            elif config == 2:
                bidir, _ = self.get_bidir_fsr_v_lat(channel_index=channel_index, use_list=use_list)
                unit = self.get_vbus_lsb(channel_index=channel_index, use_list=use_list)
            else:
                bidir = False
                unit = 0

            if use_list is False:
                reg_name = [self.registers_addresses['VACC1'][0], self.registers_addresses['VACC2'][0],
                            self.registers_addresses['VACC3'][0], self.registers_addresses['VACC4'][0]]
                result = self.read_register_i2c_smbus(reg_address=reg_name[channel_index-1],
                                                      no_of_bytes=self.registers_addresses['VACC1'][1],
                                                      signed=bidir)
            else:
                reg_name = ['vacc_ch1', 'vacc_ch2', 'vacc_ch3', 'vacc_ch4']
                result = self.registers_values[reg_name[channel_index - 1]]

            result = result * unit * self.voltage_ratio[channel_index-1]
            return result
        else:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return None

    def get_vbus(self, channel_index, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Gets the Vbus_N register real data using the mcp2221.py reading method from one of the 0x07, 0x08,
        0x09 or 0x0A addresses of the device which corresponds to the assigned channel. (N is considered 1, 2, 3 or 4).
        A Refresh command will be sent to the device before reading the register value if the refresh_type parameter has
        been added.

        :param channel_index: Selects for which channel to set the Vbus register data. It takes one of the values: 1, 2,
                              3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: Bits 15:0 converted to V, if successful;
                 None, otherwise.
        """
        if self.mcp2221:
            if (channel_index is None) | (channel_index > 4):
                self.last_error = self.ERROR_INPUT_PARAMETER
                return None

            if refresh_type is not None:
                result = self.send_refresh(refresh_type=refresh_type, delay=delay)
                if result != 0:
                    self.last_error = result
                    return None
            lsb = self.get_vbus_lsb(channel_index=channel_index, use_list=use_list)
            bidir, _ = self.get_bidir_fsr_v_lat(channel_index=channel_index, use_list=use_list)

            if use_list is False:
                reg_name = [self.registers_addresses['VBUS1'][0], self.registers_addresses['VBUS2'][0],
                            self.registers_addresses['VBUS3'][0], self.registers_addresses['VBUS4'][0]]
                result = self.read_register_i2c_smbus(reg_address=reg_name[channel_index-1],
                                                      no_of_bytes=self.registers_addresses['VBUS1'][1],
                                                      signed=bidir)
            else:
                reg_name = ['vbus_ch1', 'vbus_ch2', 'vbus_ch3', 'vbus_ch4']
                result = self.registers_values[reg_name[channel_index-1]]

            result = float(result * lsb) * self.voltage_ratio[channel_index-1]
            if result - int(result) > 0.999:
                result = round(result)
            return result
        else:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return None

    def get_vsense(self, channel_index, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Gets the Vsense_N register real data using the mcp2221.py reading method from one of the 0x0B,0x0C,
        0x0D or 0x0E addresses of the device which corresponds to the assigned. (N is considered 1, 2, 3 or 4). A
        Refresh command will be sent to the device before reading the register value if the refresh_type parameter has
        been added.

        :param channel_index: This selects for which channel to get the Vsense register data. It takes one of the
                              values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: Bits 15:0 converted to mV, if successful;
                 None, otherwise.
        """
        if self.mcp2221:
            if (channel_index is None) | (channel_index > 4):
                self.last_error = self.ERROR_INPUT_PARAMETER
                return None

            if refresh_type is not None:
                result = self.send_refresh(refresh_type=refresh_type, delay=delay)
                if result != 0:
                    self.last_error = result
                    return None
            lsb = self.get_vsense_lsb(channel_index=channel_index, use_list=use_list)
            bidir, _ = self.get_bidir_fsr_i_lat(channel_index=channel_index, use_list=use_list)

            if use_list is False:
                reg_name = [self.registers_addresses['VSENSE1'][0], self.registers_addresses['VSENSE2'][0],
                            self.registers_addresses['VSENSE3'][0], self.registers_addresses['VSENSE4'][0]]
                result = self.read_register_i2c_smbus(reg_address=reg_name[channel_index-1],
                                                      no_of_bytes=self.registers_addresses['VSENSE1'][1],
                                                      signed=bidir)
            else:
                reg_name = ['vsense_ch1', 'vsense_ch2', 'vsense_ch3', 'vsense_ch4']
                result = self.registers_values[reg_name[channel_index - 1]]

            result = float(result * lsb)
            if result - int(result) > 0.999:
                result = round(result)
            return result
        else:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return None

    def get_current(self, channel_index, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Calculates the Current value using the Vsense_N register and the Rsense_N resistor value for the
        selected channel. (N is considered 1, 2, 3 or 4). Rsense value should be set before calculating the current
        value, which means either when creating the pac194x5x object using the constructor or by using the set_rsense()
        method. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param channel_index: This selects for which channel to get the Current value. It takes one of the
                              values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: Current value reported in mA, if successful;
                 None, otherwise.
        """
        if self.mcp2221:
            if (channel_index is None) | (channel_index > 4):
                self.last_error = self.ERROR_INPUT_PARAMETER
                return None

            if refresh_type is not None:
                result = self.send_refresh(refresh_type=refresh_type, delay=delay)
                if result != 0:
                    self.last_error = result
                    return None

            result = self.get_vsense(channel_index=channel_index, use_list=use_list)

            if result is not None:
                result = result / float(self.rsense[channel_index - 1])
                return result
            else:
                return None
        else:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return None

    def get_vbus_avg(self, channel_index, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Gets the Vbus_Avg_N register real data using the mcp2221.py reading method from one of the 0x0F,
        0x10, 0x11 or 0x12 addresses of the device which corresponds to the assigned channel. (N is considered 1, 2, 3
        or 4). A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param channel_index: This selects for which channel to get the Vbus_Avg_N register data. It takes one of the
                              values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: Bits 15:0 converted to V, if successful;
                 None, otherwise.
        """
        if self.mcp2221:
            if (channel_index is None) | (channel_index > 4):
                self.last_error = self.ERROR_INPUT_PARAMETER
                return None

            if refresh_type is not None:
                result = self.send_refresh(refresh_type=refresh_type, delay=delay)
                if result != 0:
                    self.last_error = result
                    return None
            lsb = self.get_vbus_lsb(channel_index=channel_index, use_list=use_list)
            bidir, _ = self.get_bidir_fsr_v_lat(channel_index=channel_index, use_list=use_list)

            if use_list is False:
                reg_name = [self.registers_addresses['VBUS1_AVG'][0], self.registers_addresses['VBUS2_AVG'][0],
                            self.registers_addresses['VBUS3_AVG'][0], self.registers_addresses['VBUS4_AVG'][0]]
                result = self.read_register_i2c_smbus(reg_address=reg_name[channel_index-1],
                                                      no_of_bytes=self.registers_addresses['VBUS1_AVG'][1],
                                                      signed=bidir)
            else:
                reg_name = ['vbus_avg_ch1', 'vbus_avg_ch2', 'vbus_avg_ch3', 'vbus_avg_ch4']
                result = self.registers_values[reg_name[channel_index-1]]

            result = float(result * lsb)
            if result - int(result) > 0.999:
                result = round(result)
            return result
        else:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return None

    def get_vsense_avg(self, channel_index, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Gets the Vsense_Avg_N register real data using the mcp2221.py reading method from one of the 0x13,
        0x14, 0x15 or 0x16 addresses of the device which corresponds to the assigned channel. (N is considered 1, 2, 3
        or 4). A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param channel_index: This selects for which channel to get the Vsense_Avg register data. It takes one of the
                              values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: Bits 15:0 converted to mV, if successful;
                 None, otherwise.
        """
        if self.mcp2221:
            if (channel_index is None) | (channel_index > 4):
                self.last_error = self.ERROR_INPUT_PARAMETER
                return None

            if refresh_type is not None:
                result = self.send_refresh(refresh_type=refresh_type, delay=delay)
                if result != 0:
                    self.last_error = result
                    return None
            lsb = self.get_vsense_lsb(channel_index=channel_index, use_list=use_list)
            bidir, _ = self.get_bidir_fsr_i_lat(channel_index=channel_index, use_list=use_list)

            if use_list is False:
                reg_name = [self.registers_addresses['VSENSE1_AVG'][0], self.registers_addresses['VSENSE2_AVG'][0],
                            self.registers_addresses['VSENSE3_AVG'][0], self.registers_addresses['VSENSE4_AVG'][0]]
                result = self.read_register_i2c_smbus(reg_address=reg_name[channel_index-1],
                                                      no_of_bytes=self.registers_addresses['VSENSE1'][1],
                                                      signed=bidir)
            else:
                reg_name = ['vsense_avg_ch1', 'vsense_avg_ch2', 'vsense_avg_ch3', 'vsense_avg_ch4']
                result = self.registers_values[reg_name[channel_index - 1]]

            result = float(result * lsb)
            if result - int(result) > 0.999:
                result = round(result)
            return result
        else:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return None

    def get_current_avg(self, channel_index, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Calculates the Current_Avg value using the Vsense_Avg_N register and the Rsense_N resistor value
        for the selected channel. (N is considered 1, 2, 3 or 4). Rsense value should be set before calculating the
        current value, which means either when creating the pac194x5x object using the constructor or by using the
        set_rsense() method. A Refresh command will be sent to the device before reading the register value if the
        refresh_type parameter has been added.

        :param channel_index: This selects for which channel to get the Current_Avg value. It takes one of the values:
                              1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: Current_Avg value reported in mA, if successful;
                 None, otherwise.
        """
        if self.mcp2221:
            if (channel_index is None) | (channel_index > 4):
                self.last_error = self.ERROR_INPUT_PARAMETER
                return None

            if refresh_type is not None:
                result = self.send_refresh(refresh_type=refresh_type, delay=delay)
                if result != 0:
                    self.last_error = result
                    return None

            result = self.get_vsense_avg(channel_index=channel_index, use_list=use_list)

            if result is not None:
                result = result / float(self.rsense[channel_index - 1])
                return result
            else:
                return None
        else:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return None

    def get_vpower(self, channel_index, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Gets the Vpower_N register real data using the mcp2221.py reading method from one of the 0x17,0x18,
        0x19 or 0x1A addresses of the device which corresponds to the assigned channel. (N is considered 1, 2, 3 or 4).
        A Refresh command will be sent to the device before reading the register value if the refresh_type parameter has
        been added.

        :param channel_index: This selects for which channel to get the Vpower register data.It takes one of the values:
                              1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: Bits 31:2 converted to W, if successful;
                 None, otherwise.
        """
        if self.mcp2221:
            if (channel_index is None) | (channel_index > 4):
                self.last_error = self.ERROR_INPUT_PARAMETER
                return None

            if refresh_type is not None:
                result = self.send_refresh(refresh_type=refresh_type, delay=delay)
                if result != 0:
                    self.last_error = result
                    return None
            lsb = self.get_power_unit(channel_index=channel_index, use_list=use_list)
            bidir_v, _ = self.get_bidir_fsr_v_lat(channel_index=channel_index, use_list=use_list)
            bidir_i, _ = self.get_bidir_fsr_i_lat(channel_index=channel_index, use_list=use_list)
            bidir = (bidir_v | bidir_i)

            if use_list is False:
                reg_name = [self.registers_addresses['VPOWER1'][0], self.registers_addresses['VPOWER2'][0],
                            self.registers_addresses['VPOWER3'][0], self.registers_addresses['VPOWER4'][0]]
                result = self.read_register_i2c_smbus(reg_address=reg_name[channel_index-1],
                                                      no_of_bytes=self.registers_addresses['VPOWER1'][1],
                                                      signed=bidir)
            else:
                reg_name = ['vpower_ch1', 'vpower_ch2', 'vpower_ch3', 'vpower_ch4']
                result = self.registers_values[reg_name[channel_index - 1]]

            result = result >> 2
            result = float(result * lsb) * self.voltage_ratio[channel_index-1]
            return result
        else:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return None

    def get_energy(self, channel_index, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Calculates the Energy_N value using the Vacc_N register real value (N is considered 1, 2, 3 or 4)
        and depending on the Single Shot mode, it also uses the sample frequency or the timestamp difference according
        to the formula.

        :param channel_index: This selects for which channel to get the Vacc register data. It takes one of the values:
                              1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: Energy value in pWh, if successful;
                 None, otherwise.
        """
        if self.mcp2221:
            if refresh_type is not None:
                result = self.send_refresh(refresh_type=refresh_type, delay=delay)
                if result != 0:
                    self.last_error = result
                    return None
            samp_mode = self.get_sample_mode(use_list=use_list)
            if (samp_mode == self.SAMPLE_MODE_SINGLE_SHOT) or (samp_mode == self.SAMPLE_MODE_SINGLE_SHOT_8X):
                single_shot = True
            else:
                single_shot = False

            if single_shot is False:
                result = (self.get_vacc(channel_index=channel_index, use_list=use_list) /
                          float(self.get_sample_frequency(use_list=use_list))) * \
                         self.get_power_unit(channel_index=channel_index, use_list=use_list) * self.energy_unit
            else:
                result = self.get_vacc(channel_index=channel_index, use_list=use_list) * \
                         ((self.time_stamp - self.prev_timestamp) / 1000.0) * \
                         self.get_power_unit(channel_index=channel_index, use_list=use_list) * self.energy_unit
                if samp_mode == self.SAMPLE_MODE_SINGLE_SHOT_8X:
                    result = result / 8.0
            return result
        else:
            return None

    def set_smbus(self, smbus_value, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value for the Smbus register using the mcp2221.py writing method at the 0x1C address of
        the device and if the refresh type has been added, it will send a refresh command for the settings to take
        effect, after which it will wait for a configurable number of seconds, so it makes sure the command has taken
        effect. The method evaluates if the communication protocol has been changed and updates the corresponding
        attribute of the object.

        :param smbus_value: Bits 7:0; Represents the new Smbus register value for the device. Note that if the parameter
                            is out the expected range, an OverflowError will occur as the method expects 1 byte.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the smbus_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if smbus_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        # write SMBUS register
        value = smbus_value.to_bytes(self.registers_addresses['SMBUS'][1], 'big', signed=False)

        address = self.registers_addresses['SMBUS'][0]
        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0]])
        if result != 0:
            self.last_error = result
            return result

        byte_count = self.get_bits_value(value=smbus_value, no_of_bits=1, position=2)
        if byte_count == 1:
            self.i2c_communication_protocol = False
        else:
            self.i2c_communication_protocol = True

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
        return result

    def get_smbus(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the Smbus register data using the mcp2221.py reading method from the 0x1C address of the
        device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added. The method evaluates if the communication protocol has been changed and updates the
        corresponding attribute of the object.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 7:0, if successful;
                 None, otherwise
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['SMBUS'][0],
                                              no_of_bytes=self.registers_addresses['SMBUS'][1],
                                              signed=False)

        byte_count = self.get_bits_value(value=result, no_of_bits=1, position=2)
        if byte_count == 1:
            self.i2c_communication_protocol = False
        else:
            self.i2c_communication_protocol = True

        return result

    def set_neg_pwr_fsr(self, fsr_value, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value for the Neg_Pwr_Fsr register using the mcp2221.py writing method at the 0x1D
        address of the device and if the refresh type has been added, it will send a refresh command for the settings
        to take effect, after which it will wait for a configurable number of seconds, so it makes sure the command has
        taken effect.

        :param fsr_value: Bits 15:0; Represents the new Neg_Pwr_Fsr register value for the device. Note that if the
                          parameter is out of the expected range, an OverflowError will occur as the method expects 2
                          bytes.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the fsr_value parameter is None or the refresh_type is out of range.

        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if fsr_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        # write NEG_PWR_FSR register
        value = fsr_value.to_bytes(self.registers_addresses['NEG_PWR_FSR'][1], 'big', signed=False)

        address = self.registers_addresses['NEG_PWR_FSR'][0]
        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0], value[1]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
        return result

    def get_neg_pwr_fsr(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the Neg_Pwr_Fsr register data using the mcp2221.py reading method from the 0x1D address of the
        device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 15:0, if successful;
                 None, otherwise
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['NEG_PWR_FSR'][0],
                                              no_of_bytes=self.registers_addresses['NEG_PWR_FSR'][1],
                                              signed=False)
        return result

    def refresh_g(self, delay=0.128):
        """
        Description: Sends a Refresh_G command to the device using the mcp2221.py writing method to the 0x1E address of
        the device. After the command is sent, the program waits for a configurable number of seconds, so it makes sure
        the command has taken effect. The method updates the previous and current timestamp.

        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed
                 ERROR_MCP2221_BRIDGE_MISSING, if no mcp2221 bridge has been added to the pac194x5x attributes
        """
        if self.mcp2221:
            result = self.mcp2221.I2C_Write(self.i2c_address, [self.registers_addresses['REFRESH_G'][0]])
            if result == 0:
                time.sleep(delay)
                self.prev_timestamp = self.time_stamp
                self.time_stamp = time.time()
        else:
            result = self.ERROR_MCP2221_BRIDGE_MISSING
        return result

    def refresh_v(self, delay=0.128):
        """
        Description: Sends a Refresh_V command to the device using the mcp2221.py writing method to the 0x1F address of
        the device. After the command is sent, the program waits for a configurable number of seconds, so it makes sure
        the command has taken effect. The method updates the previous and current timestamp.

        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed
                 ERROR_MCP2221_BRIDGE_MISSING, if no mcp2221 bridge has been added to the pac194x5x attributes
        """
        if self.mcp2221:
            result = self.mcp2221.I2C_Write(self.i2c_address, [self.registers_addresses['REFRESH_V'][0]])
            if result == 0:
                time.sleep(delay)
                self.prev_timestamp = self.time_stamp
                self.time_stamp = time.time()
        else:
            result = self.ERROR_MCP2221_BRIDGE_MISSING
        return result

    def set_slow(self, slow_value, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value for the Slow register using the mcp2221.py writing method at the 0x20 address of
        the device and if the refresh type has been added, it will send a refresh command for the settings to take
        effect, after which it will wait for a configurable number of seconds, so it makes sure the command has taken
        effect.

        :param slow_value: Bits 7:0; represents the new Slow register value for the chip. Note that if the parameter is
                           out of the expected range, an OverflowError will occur as the method expects 1 byte.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the slow_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if slow_value is None:
            return self.ERROR_INPUT_PARAMETER

        # write SLOW register
        value = slow_value.to_bytes(self.registers_addresses['SLOW'][1], 'big', signed=False)

        address = self.registers_addresses['SLOW'][0]
        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0]])
        if result != 0:
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
        return result

    def get_slow(self, refresh_type=None, delay=0.128):
        """
        Description:Gets the Slow register data using the mcp2221.py reading method from the 0x20 address of the device.
        Refresh command will be sent to the device before reading the register value if the refresh_type parameter has
        been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 7:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['SLOW'][0],
                                              no_of_bytes=self.registers_addresses['SLOW'][1],
                                              signed=False)
        return result

    def get_control_act(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the Neg_Pwr_Fst_Act register data using the mcp2221.py reading method from the 0x22 address of
        the device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.

        :return: Bits 15:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['CTRL_ACT'][0],
                                              no_of_bytes=self.registers_addresses['CTRL_ACT'][1],
                                              signed=False)
        return result

    def get_neg_pwr_fsr_act(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the Neg_Pwr_Fst_Act register data using the mcp2221.py reading method from the 0x22 address of
        the device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 15:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['NEG_PWR_FSR_ACT'][0],
                                              no_of_bytes=self.registers_addresses['NEG_PWR_FSR_ACT'][1],
                                              signed=False)
        return result

    def get_control_lat(self, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Gets the Ctrl_Lat register data using the mcp2221.py reading method from the 0x23 address of the
        device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: Bits 15:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        if use_list is False:
            result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['CTRL_LAT'][0],
                                                  no_of_bytes=self.registers_addresses['CTRL_LAT'][1],
                                                  signed=False)
        else:
            result = self.registers_values['control_lat']
        return result

    def get_neg_pwr_fsr_lat(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the Neg_Pwr_Fst_Lat register data using the mcp2221.py reading method from the 0x24 address of
        the device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 15:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['NEG_PWR_FSR_LAT'][0],
                                              no_of_bytes=self.registers_addresses['NEG_PWR_FSR_LAT'][1],
                                              signed=False)
        return result

    def set_accum_config(self, accum_value, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value for the Accum_Config register using the mcp2221.py writing method at the 0x25
        address of the device and if the refresh type has been added, it will send a refresh command for the settings to
        take effect, after which it will wait for a configurable number of seconds, so it makes sure the command has
        taken effect.

        :param accum_value:  Bits 7:0; Represents the new Accum_Config register value for the chip. Note that if the
                             parameter is out of the expected range, an OverflowError will occur as the method expects 1
                             byte.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the accum_value is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if accum_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        # write ACCUM_CONFIG register
        value = accum_value.to_bytes(self.registers_addresses['ACCUM_CONFIG'][1], 'big', signed=False)

        address = self.registers_addresses['ACCUM_CONFIG'][0]
        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
        return result

    def get_accum_config(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the Accum_Config register data using the mcp2221.py reading method from the 0x25 address of
        the device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 7:0, if successful;
                 None, otherwise
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['ACCUM_CONFIG'][0],
                                              no_of_bytes=self.registers_addresses['ACCUM_CONFIG'][1],
                                              signed=False)
        return result

    def get_alert_status(self, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Gets the Alert_Status register data using the mcp2221.py reading method from the 0x26 address of
        the device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: Bits 23:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        if use_list is False:
            result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['ALERT_STATUS'][0],
                                                  no_of_bytes=self.registers_addresses['ALERT_STATUS'][1],
                                                  signed=False)
        else:
            result = self.registers_values['alert_status']
        return result

    def set_slow_alert1(self, slow_value, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value for the Slow_Alert1 register using the mcp2221.py writing method at the 0x27
        address of the device and if the refresh type has been added, it will send a refresh command for the settings to
        take effect, after which it will wait for a configurable number of seconds, so it makes sure the command has
        taken effect.

        :param slow_value: Bits 23:0, the new Slow_Alert1 register value for the device. Note that if the parameter is out
                           of the expected range, an OverflowError will occur as the method expects 3 bytes.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the slow_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if slow_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        # write SLOW_ALERT1 register
        value = slow_value.to_bytes(self.registers_addresses['SLOW_ALERT1'][1], 'big', signed=False)
        if len(value) > self.registers_addresses['SLOW_ALERT1'][1]:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        address = self.registers_addresses['SLOW_ALERT1'][0]
        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0], value[1], value[2]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
        return result

    def get_slow_alert1(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the Slow_Alert1 register data using the mcp2221.py reading method from the 0x27 address of the
        device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 23:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['SLOW_ALERT1'][0],
                                              no_of_bytes=self.registers_addresses['SLOW_ALERT1'][1],
                                              signed=False)
        return result

    def set_gpio_alert2(self, gpio_value, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value for the GPIO_Alert2 register using the mcp2221.py writing method at the 0x28
        address of the device device and if the refresh type has been added, it will send a refresh command for the
        settings to take effect, after which it will wait for a configurable number of seconds, so it makes sure the
        command has taken effect.

        :param gpio_value: Bits 23:0; Represents the new GPIO_Alert2 register value for the chip. Note that if the
                           parameter is out of the expected range, an OverflowError will occur as the method expects 3 bytes.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the gpio_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if gpio_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        # write GPIO_ALERT2 register
        value = gpio_value.to_bytes(self.registers_addresses['GPIO_ALERT2'][1], 'big', signed=False)
        if len(value) > self.registers_addresses['GPIO_ALERT2'][1]:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        address = self.registers_addresses['GPIO_ALERT2'][0]
        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0], value[1], value[2]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
        return result

    def get_gpio_alert2(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the GPIO_Alert2 register data using the mcp2221.py reading method from the 0x28 address of the
        device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 23:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['GPIO_ALERT2'][0],
                                              no_of_bytes=self.registers_addresses['GPIO_ALERT2'][1],
                                              signed=False)
        return result

    def set_acc_fullness_limits(self, limits_value, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value for the ACC_Fullness_Limits register using the mcp2221.py writing method at the
        0x29 address of the device and if the refresh type has been added, it will send a refresh command for the
        settings to take effect, after which it will wait for a configurable number of seconds, so it makes sure the
        command has taken effect.

        :param limits_value: its 15:0; Represents the new ACC_Fullness_Limits register value for the chip. Note that if
                             the parameter is out of the expected range, an OverflowError will occur as the method
                             expects 2 bytes.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the limits_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if limits_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        # write ACC_FULLNESS_LIMITS register
        value = limits_value.to_bytes(self.registers_addresses['ACC_FULLNESS_LIMITS'][1], 'big', signed=False)
        if len(value) > self.registers_addresses['ACC_FULLNESS_LIMITS'][1]:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        address = self.registers_addresses['ACC_FULLNESS_LIMITS'][0]
        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0], value[1]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
        return result

    def get_acc_fullness_limits(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the ACC_Fullness_Limits register data using the mcp2221.py reading method from the 0x29
        address of the device. A Refresh command will be sent to the device before reading the register value if the
        refresh_type parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 15:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['ACC_FULLNESS_LIMITS'][0],
                                              no_of_bytes=self.registers_addresses['ACC_FULLNESS_LIMITS'][1],
                                              signed=False)
        return result

    def set_oc_limit(self, oc_value, channel_index, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value in mA for one of the OC_Limit registers using the mcp2221.py writing method at one
        of the 0x30-0x33 addresses corresponding to the 4 channels of the device and if the refresh type has been added,
        it will send a refresh command for the settings to take effect, after which it will wait for a configurable
        number of seconds, so it makes sure the command has taken effect. The method will convert the oc_value to the
        expected raw value before sending it to the device.

        :param oc_value: Represents the new OC_Limit register value in mA; if the value is out of the register range, it
                         will be correctly limited and then sent to the device.
        :param channel_index: This selects for which channel to set the OC_Limit register data. It takes one of the
                              values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the oc_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if oc_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        current = self.VSENSE_SCALE_100MV / float(self.rsense[channel_index - 1])
        if oc_value >= current:
            oc_limit = 0x7fff
        else:
            if oc_value <= (-1 * current):
                oc_limit = 0x8000
            else:
                oc_limit = (oc_value * pow(2, 15)) / (self.VSENSE_SCALE_100MV / float(self.rsense[channel_index - 1]))

        # write OC_LIMIT register
        oc_limit = int(oc_limit)
        value = self.get_array_value(oc_limit, self.registers_addresses['OC_LIMIT_1'][1])
        if channel_index == 1:
            address = self.registers_addresses['OC_LIMIT_1'][0]
        elif channel_index == 2:
            address = self.registers_addresses['OC_LIMIT_2'][0]
        elif channel_index == 3:
            address = self.registers_addresses['OC_LIMIT_3'][0]
        elif channel_index == 4:
            address = self.registers_addresses['OC_LIMIT_4'][0]
        else:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0], value[1]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
        return result

    def get_oc_limit(self, channel_index, refresh_type=None, delay=0.128):
        """
        Description: Gets the OC_Limit register real data in mA using the mcp2221.py reading method from one of the
        0x30-0x33 addresses corresponding to the four channels of the device. A Refresh command will be sent to the
        device before reading the register value if the refresh_type parameter has been added.

        :param channel_index: This selects for which channel to get the OC_Limit register data. It takes one of the
                              values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 15:0 converted to mA, if successful;
                 None, otherwise.
        """
        if self.mcp2221:
            if refresh_type is not None:
                result = self.send_refresh(refresh_type=refresh_type, delay=delay)
                if result != 0:
                    self.last_error = result
                    return None

            if not (0 < channel_index & channel_index < 5):
                return self.ERROR_INPUT_PARAMETER

            reg_name = [self.registers_addresses['OC_LIMIT_1'][0], self.registers_addresses['OC_LIMIT_2'][0],
                        self.registers_addresses['OC_LIMIT_3'][0], self.registers_addresses['OC_LIMIT_4'][0]]
            result = self.read_register_i2c_smbus(reg_address=reg_name[channel_index - 1],
                                                  no_of_bytes=self.registers_addresses['OC_LIMIT_1'][1],
                                                  signed=True)
            if (result >> 15) & 0x1 == 1:
                result = result | 0xffff0000
            else:
                result = result & 0xffff

            oc_limit = ((self.VSENSE_SCALE_100MV / self.rsense[channel_index - 1]) * result) / float(pow(2, 15))

            return round(oc_limit, 3)
        else:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return None

    def set_uc_limit(self, uc_value, channel_index, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value in mA for one of the UC_Limit registers using the mcp2221.py writing method at one
        of the 0x34-0x37 addresses corresponding to the 4 channels of the device and if the refresh type has been added,
        it will send a refresh command for the settings to take effect, after which it will wait for a configurable
        number of seconds, so it makes sure the command has taken effect .The method will convert the uc_value to the
        expected raw value before sending it to the device.

        :param uc_value: Represents the new UC_Limit register value in mA; if the value is out of the register range, it
                         will be correctly limited and then sent to the device.
        :param channel_index: This selects for which channel to get the UC_Limit register data. It takes one of the
                              values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the uc_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if uc_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        current = self.VSENSE_SCALE_100MV / float(self.rsense[channel_index - 1])
        if uc_value >= current:
            uc_limit = 0x7fff
        else:
            if uc_value <= (-1 * current):
                uc_limit = 0x8000
            else:
                uc_limit = (uc_value * pow(2, 15)) / (self.VSENSE_SCALE_100MV / float(self.rsense[channel_index - 1]))

        # write UC_LIMIT register
        uc_limit = int(uc_limit)
        value = self.get_array_value(uc_limit, self.registers_addresses['UC_LIMIT_1'][1])
        if channel_index == 1:
            address = self.registers_addresses['UC_LIMIT_1'][0]
        elif channel_index == 2:
            address = self.registers_addresses['UC_LIMIT_2'][0]
        elif channel_index == 3:
            address = self.registers_addresses['UC_LIMIT_3'][0]
        elif channel_index == 4:
            address = self.registers_addresses['UC_LIMIT_4'][0]
        else:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0], value[1]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
        return result

    def get_uc_limit(self, channel_index, refresh_type=None, delay=0.128):
        """
        Description: Gets the UC_Limit register real data in mA using the mcp2221.py reading method from one of the
        0x34-0x37 addresses corresponding to the four channels of the device. A Refresh command will be sent to the
        device before reading the register value if the refresh_type parameter has been added.

        :param channel_index: This selects for which channel to get the UC_Limit register data. It takes one of the
                              values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 15:0 converted to mA, if successful;
                 None, otherwise.
        """
        if self.mcp2221:
            if refresh_type is not None:
                result = self.send_refresh(refresh_type=refresh_type, delay=delay)
                if result != 0:
                    self.last_error = result
                    return None

            if not (0 < channel_index & channel_index < 5):
                return self.ERROR_INPUT_PARAMETER

            reg_name = [self.registers_addresses['UC_LIMIT_1'][0], self.registers_addresses['UC_LIMIT_2'][0],
                        self.registers_addresses['UC_LIMIT_3'][0], self.registers_addresses['UC_LIMIT_4'][0]]
            result = self.read_register_i2c_smbus(reg_address=reg_name[channel_index - 1],
                                                  no_of_bytes=self.registers_addresses['UC_LIMIT_1'][1],
                                                  signed=True)
            if (result >> 15) & 0x1 == 1:
                result = result | 0xffff0000
            else:
                result = result & 0xffff

            uc_limit = ((self.VSENSE_SCALE_100MV / self.rsense[channel_index - 1]) * result) / float(pow(2, 15))

            return round(uc_limit, 3)
        else:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return None

    def set_op_limit(self, op_value, channel_index, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value in W for one of the OP_Limit registers using the mcp2221.py writing method at one
        of the 0x38-0x3B addresses corresponding to the 4 channels of the device and if the refresh type has been added,
        it will send a refresh command for the settings to take effect, after which it will wait for a configurable
        number of seconds, so it makes sure the command has taken effect. The method will convert the op_value to the
        expected raw value before sending it to the device.

        :param op_value: Represents the new OP_Limit register value in W; if the value is out of the register range, it
                         will be correctly limited and then sent to the device.
        :param channel_index: This selects for which channel to get the OP_Limit register data. It takes one of the
                              values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the op_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if op_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        if self.pac5x == 0:
            power = (self.VSENSE_SCALE_100MV * self.VBUS_SCALE_9) / float(self.rsense[channel_index - 1] * 1000)
        else:
            power = (self.VSENSE_SCALE_100MV * self.VBUS_SCALE_32) / float(self.rsense[channel_index - 1] * 1000)

        if op_value >= power:
            op_limit = 0x7fffff
        else:
            if op_value <= (-1 * power):
                op_limit = 0x800000
            else:
                op_limit = op_value * pow(2, 23) / power

        # write OP_LIMIT register
        op_limit = int(op_limit)
        value = self.get_array_value(op_limit, self.registers_addresses['OP_LIMIT_1'][1])
        if channel_index == 1:
            address = self.registers_addresses['OP_LIMIT_1'][0]
        elif channel_index == 2:
            address = self.registers_addresses['OP_LIMIT_2'][0]
        elif channel_index == 3:
            address = self.registers_addresses['OP_LIMIT_3'][0]
        elif channel_index == 4:
            address = self.registers_addresses['OP_LIMIT_4'][0]
        else:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0], value[1], value[2]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
        return result

    def get_op_limit(self, channel_index, refresh_type=None, delay=0.128):
        """
        Description: Gets the OP_Limit register real data in W using the mcp2221.py reading method from one of the
        0x38-0x3B addresses corresponding to the four channels of the device. A Refresh command will be sent to the
        device before reading the register value if the refresh_type parameter has been added.

        :param channel_index: This selects for which channel to get the OP_Limit register data. It takes one of the
                              values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 23:0 converted to W, if successful;
                 None, otherwise.
        """
        if self.mcp2221:
            if refresh_type is not None:
                result = self.send_refresh(refresh_type=refresh_type, delay=delay)
                if result != 0:
                    self.last_error = result
                    return None

            if not (0 < channel_index & channel_index < 5):
                return self.ERROR_INPUT_PARAMETER

            reg_name = [self.registers_addresses['OP_LIMIT_1'][0], self.registers_addresses['OP_LIMIT_2'][0],
                        self.registers_addresses['OP_LIMIT_3'][0], self.registers_addresses['OP_LIMIT_4'][0]]
            result = self.read_register_i2c_smbus(reg_address=reg_name[channel_index - 1],
                                                  no_of_bytes=self.registers_addresses['OP_LIMIT_1'][1],
                                                  signed=True)
            if (result >> 23) & 0x1 == 1:
                result = result | 0xff000000
            else:
                result = result & 0xffffff

            if self.pac5x == 0:
                power = (self.VSENSE_SCALE_100MV * self.VBUS_SCALE_9) / \
                        float(self.rsense[channel_index - 1] * 1000)
            else:
                power = (self.VSENSE_SCALE_100MV * self.VBUS_SCALE_32) / \
                        float(self.rsense[channel_index - 1] * 1000)

            op_limit = (power * result) / float(pow(2, 23))

            return round(op_limit, 3)
        else:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return None

    def set_ov_limit(self, ov_value, channel_index, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value in V for one of the OV_Limit registers using the mcp2221.py writing method at one
        of the 0x3C-0x3F addresses corresponding to the 4 channels of the device and if the refresh type has been added,
        it will send a refresh command for the settings to take effect, after which it will wait for a configurable
        number of seconds, so it makes sure the command has taken effect. The method will convert the ov_value to the
        expected raw value before sending it to the device.

        :param ov_value: Represents the new OV_Limit register value in V; if the value is out of the register range, it
                         will be correctly limited and then sent to the device.
        :param channel_index: This selects for which channel to get the OV_Limit register data. It takes one of the
                              values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the op_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if ov_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        if self.pac5x == 0:
            if (ov_value >= self.VBUS_SCALE_9) | (ov_value >= 8.99):
                ov_limit = 0x7fff
            else:
                if (ov_value <= (-1 * self.VBUS_SCALE_9)) | (ov_value <= -8.99):
                    ov_limit = 0x8000
                else:
                    ov_limit = ov_value * pow(2, 15) / float(self.VBUS_SCALE_9)
        else:
            if (ov_value >= self.VBUS_SCALE_32) | (ov_value >= 31.99):
                ov_limit = 0x7fff
            else:
                if (ov_value <= (-1 * self.VBUS_SCALE_32)) | (ov_value <= -31.99):
                    ov_limit = 0x8000
                else:
                    ov_limit = ov_value * pow(2, 15) / float(self.VBUS_SCALE_32)

        # write OV_LIMIT register
        ov_limit = int(ov_limit)
        value = self.get_array_value(ov_limit, self.registers_addresses['OV_LIMIT_1'][1])
        if channel_index == 1:
            address = self.registers_addresses['OV_LIMIT_1'][0]
        elif channel_index == 2:
            address = self.registers_addresses['OV_LIMIT_2'][0]
        elif channel_index == 3:
            address = self.registers_addresses['OV_LIMIT_3'][0]
        elif channel_index == 4:
            address = self.registers_addresses['OV_LIMIT_4'][0]
        else:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0], value[1]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
        return result

    def get_ov_limit(self, channel_index, refresh_type=None, delay=0.128):
        """
        Description: Gets the OV_Limit register real data in V using the mcp2221.py reading method from one of the
        0x3C-0x3F addresses corresponding to the four channels of the device. A Refresh command will be sent to the
        device before reading the register value if the refresh_type parameter has been added.

        :param channel_index: This selects for which channel to get the OV_Limit register data. It takes one of the
                              values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 15:0 converted to V, if successful;
                 None, otherwise.
        """
        if self.mcp2221:
            if refresh_type is not None:
                result = self.send_refresh(refresh_type, delay)
                if result != 0:
                    self.last_error = result
                    return None

            if not (0 < channel_index & channel_index < 5):
                return self.ERROR_INPUT_PARAMETER

            reg_name = [self.registers_addresses['OV_LIMIT_1'][0], self.registers_addresses['OV_LIMIT_2'][0],
                        self.registers_addresses['OV_LIMIT_3'][0], self.registers_addresses['OV_LIMIT_4'][0]]
            result = self.read_register_i2c_smbus(reg_address=reg_name[channel_index - 1],
                                                  no_of_bytes=self.registers_addresses['OV_LIMIT_1'][1],
                                                  signed=True)

            if (result >> 15) & 0x1 == 1:
                result = result | 0xffff0000
            else:
                result = result & 0xffff

            if self.pac5x == 0:
                ov_limit = (self.VBUS_SCALE_9 * result) / float(pow(2, 15))
            else:
                ov_limit = (self.VBUS_SCALE_32 * result) / float(pow(2, 15))

            return round(ov_limit, 3)
        else:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return None

    def set_uv_limit(self, uv_value, channel_index, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value in V for one of the UV_Limit registers using the mcp2221.py writing method at one
        of the 0x40-0x43 addresses corresponding to the 4 channels of the device and if the refresh type has been added,
        it will send a refresh command for the settings to take effect, after which it will wait for a configurable
        number of seconds, so it makes sure the command has taken effect. The method will convert the uv_value to the
        expected raw value before sending it to the device.

        :param uv_value: Represents the new UV_Limit register value in V; if the value is out of the register range, it
                         will be correctly limited and then sent to the device
        :param channel_index: This selects for which channel to get the UV_Limit register data. It takes one of the
                              values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the op_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if uv_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        if self.pac5x == 0:
            if (uv_value >= self.VBUS_SCALE_9) | (uv_value >= 8.99):
                uv_limit = 0x7fff
            else:
                if (uv_value <= (-1 * self.VBUS_SCALE_9)) | (uv_value <= -8.99):
                    uv_limit = 0x8000
                else:
                    uv_limit = uv_value * pow(2, 15) / float(self.VBUS_SCALE_9)
        else:
            if (uv_value >= self.VBUS_SCALE_32) | (uv_value >= 31.99):
                uv_limit = 0x7fff
            else:
                if (uv_value <= (-1 * self.VBUS_SCALE_32)) | (uv_value <= -31.99):
                    uv_limit = 0x8000
                else:
                    uv_limit = uv_value * pow(2, 15) / float(self.VBUS_SCALE_32)

        # write UV_LIMIT register
        uv_limit = int(uv_limit)
        value = self.get_array_value(uv_limit, self.registers_addresses['UV_LIMIT_1'][1])
        if channel_index == 1:
            address = self.registers_addresses['UV_LIMIT_1'][0]
        elif channel_index == 2:
            address = self.registers_addresses['UV_LIMIT_2'][0]
        elif channel_index == 3:
            address = self.registers_addresses['UV_LIMIT_3'][0]
        elif channel_index == 4:
            address = self.registers_addresses['UV_LIMIT_4'][0]
        else:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0], value[1]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
        return result

    def get_uv_limit(self, channel_index, refresh_type=None, delay=0.128):
        """
        Description: Gets the UV_Limit register real data in W using the mcp2221.py reading method from one of the
        0x40-0x43 addresses corresponding to the four channels of the device. A Refresh command will be sent to the
        device before reading the register value if the refresh_type parameter has been added.

        :param channel_index: This selects for which channel to get the UV_Limit register data. It takes one of the
                              values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 15:0 converted to V, if successful;
                 None, otherwise.
        """
        if self.mcp2221:
            if refresh_type is not None:
                result = self.send_refresh(refresh_type, delay)
                if result != 0:
                    self.last_error = result
                    return None

            if not (0 < channel_index & channel_index < 5):
                return self.ERROR_INPUT_PARAMETER

            reg_name = [self.registers_addresses['UV_LIMIT_1'][0], self.registers_addresses['UV_LIMIT_2'][0],
                        self.registers_addresses['UV_LIMIT_3'][0], self.registers_addresses['UV_LIMIT_4'][0]]
            result = self.read_register_i2c_smbus(reg_address=reg_name[channel_index - 1],
                                                  no_of_bytes=self.registers_addresses['UV_LIMIT_1'][1],
                                                  signed=True)
            if (result >> 15) & 0x1 == 1:
                result = result | 0xffff0000
            else:
                result = result & 0xffff

            if self.pac5x == 0:
                uv_limit = (self.VBUS_SCALE_9 * result) / float(pow(2, 15))
            else:
                uv_limit = (self.VBUS_SCALE_32 * result) / float(pow(2, 15))

            return round(uv_limit, 3)
        else:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return None

    def set_oc_limit_nsamples(self, nsamples_value, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value for the OC_Limit_Nsamples register using the mcp2221.py writing method at the 0x44
        address of the device and if the refresh type has been added, it will send a refresh command for the settings to
        take effect, after which it will wait for a configurable number of seconds, so it makes sure the command has
        taken effect.

        :param nsamples_value: Bits 7:0; Represents the new OC_Limit_Nsamples Limits register value for the device. Note
                               that if the parameter is out of the expected range, an OverflowError will occur as the
                               method expects 1 byte.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the nsamples_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if nsamples_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        # write OC_LIMIT_NSAMPLES register
        value = nsamples_value.to_bytes(self.registers_addresses['OC_LIMIT_NSAMPLES'][1], 'big', signed=False)

        address = self.registers_addresses['OC_LIMIT_NSAMPLES'][0]
        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
        return result

    def get_oc_limit_nsamples(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the OC_Limit_Nsamples register data using the mcp2221.py reading method from the 0x44 address
        of the device. A Refresh command will be sent to the device before reading the register value if the
        refresh_type parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 7:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['OC_LIMIT_NSAMPLES'][0],
                                              no_of_bytes=self.registers_addresses['OC_LIMIT_NSAMPLES'][1],
                                              signed=False)
        return result

    def set_uc_limit_nsamples(self, nsamples_value, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value for the UC_Limit_Nsamples register using the mcp2221.py writing method at the 0x45
        address of the device and if the refresh type has been added, it will send a refresh command for the settings to
        take effect, after which it will wait for a configurable number of seconds, so it makes sure the command has
        taken effect.

        :param nsamples_value: Bits 7:0; Represents the new UC_Limit_Nsamples Limits register value for the device. Note
                               that if the parameter is out of the expected range, an OverflowError will occur as the
                               method expects 1 byte.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the nsamples_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if nsamples_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        # write UC_LIMIT_NSAMPLES register
        value = nsamples_value.to_bytes(self.registers_addresses['UC_LIMIT_NSAMPLES'][1], 'big', signed=False)

        address = self.registers_addresses['UC_LIMIT_NSAMPLES'][0]
        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
        return result

    def get_uc_limit_nsamples(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the UC_Limit_Nsamples register data using the mcp2221.py reading method from the 0x45 address
        of the device. A Refresh command will be sent to the device before reading the register value if the
        refresh_type parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 7:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['UC_LIMIT_NSAMPLES'][0],
                                              no_of_bytes=self.registers_addresses['UC_LIMIT_NSAMPLES'][1],
                                              signed=False)
        return result

    def set_op_limit_nsamples(self, nsamples_value, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value for the OP_Limit_Nsamples register using the mcp2221.py writing method at the 0x46
        address of the device and if the refresh type has been added, it will send a refresh command for the settings to
        take effect, after which it will wait for a configurable number of seconds, so it makes sure the command has
        taken effect.

        :param nsamples_value: Bits 7:0; Represents the new OP_Limit_Nsamples Limits register value for the device. Note
                               that if the parameter is out of the expected range, an OverflowError will occur as the
                               method expects 1 byte.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the nsamples_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if nsamples_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        # write OP_LIMIT_NSAMPLES register
        value = nsamples_value.to_bytes(self.registers_addresses['OP_LIMIT_NSAMPLES'][1], 'big', signed=False)

        address = self.registers_addresses['OP_LIMIT_NSAMPLES'][0]
        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
        return result

    def get_op_limit_nsamples(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the OP_Limit_Nsamples register data using the mcp2221.py reading method from the 0x46 address
        of the device. A Refresh command will be sent to the device before reading the register value if the
        refresh_type parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 7:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['OP_LIMIT_NSAMPLES'][0],
                                              no_of_bytes=self.registers_addresses['OP_LIMIT_NSAMPLES'][1],
                                              signed=False)
        return result

    def set_ov_limit_nsamples(self, nsamples_value, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value for the OV_Limit_Nsamples register using the mcp2221.py writing method at the 0x47
        address of the device and if the refresh type has been added, it will send a refresh command for the settings to
        take effect, after which it will wait for a configurable number of seconds, so it makes sure the command has
        taken effect.

        :param nsamples_value: Bits 7:0; Represents the new OV_Limit_Nsamples Limits register value for the chip. Note
                               that if the parameter is out of the expected range, an OverflowError will occur as the
                               method expects 1 byte.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the nsamples_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if nsamples_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        # write OV_LIMIT_NSAMPLES register
        value = nsamples_value.to_bytes(self.registers_addresses['OV_LIMIT_NSAMPLES'][1], 'big', signed=False)

        address = self.registers_addresses['OV_LIMIT_NSAMPLES'][0]
        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
        return result

    def get_ov_limit_nsamples(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the OV_Limit_Nsamples register data using the mcp2221.py reading method from the 0x47 address
        of the device. A Refresh command will be sent to the device before reading the register value if the
        refresh_type parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 7:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['OV_LIMIT_NSAMPLES'][0],
                                              no_of_bytes=self.registers_addresses['OV_LIMIT_NSAMPLES'][1],
                                              signed=False)
        return result

    def set_uv_limit_nsamples(self, nsamples_value, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value for the UV_Limit_Nsamples register using the mcp2221.py writing method at the 0x48
        address of the device and if the refresh type has been added, it will send a refresh command for the settings to
        take effect, after which it will wait for a configurable number of seconds, so it makes sure the command has
        taken effect.

        :param nsamples_value: Bits 7:0; Represents the new UV_Limit_Nsamples Limits register value for the chip. Note
                               that if the parameter is out of the expected range, an OverflowError will occur as the
                               method expects 1 byte.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the nsamples_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if nsamples_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        # write UV_LIMIT_NSAMPLES register
        value = nsamples_value.to_bytes(self.registers_addresses['UV_LIMIT_NSAMPLES'][1], 'big', signed=False)

        address = self.registers_addresses['UV_LIMIT_NSAMPLES'][0]
        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
        return result

    def get_uv_limit_nsamples(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the UV_Limit_Nsamples register data using the mcp2221.py reading method from the 0x48 address
        of the device. A Refresh command will be sent to the device before reading the register value if the
        refresh_type parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 7:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['UV_LIMIT_NSAMPLES'][0],
                                              no_of_bytes=self.registers_addresses['UV_LIMIT_NSAMPLES'][1],
                                              signed=False)
        return result

    def set_alert_enable(self, alert_value, refresh_type=None, delay=0.128):
        """
        Description: Sets a new value for the Alert_Enable register using the mcp2221.py writing method at the 0x49
        address of the device and if the refresh type has been added, it will send a refresh command for the settings to
        take effect, after which it will wait for a configurable number of seconds, so it makes sure the command has
        taken effect.

        :param alert_value: Bits 23:0; Represents the new Alert_Enable register value for the chip. Note that if the
                            parameter is out of the expected range, an OverflowError will occur as the method expects 3
                            bytes.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the alert_value parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if alert_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        # write ALERT_ENABLE register
        value = alert_value.to_bytes(self.registers_addresses['ALERT_ENABLE'][1], 'big', signed=False)
        if len(value) > self.registers_addresses['ALERT_ENABLE'][1]:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        address = self.registers_addresses['ALERT_ENABLE'][0]
        result = self.mcp2221.I2C_Write(self.i2c_address, [address, value[0], value[1], value[2]])
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
        return result

    def get_alert_enable(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the Alert_Enable register data using the mcp2221.py reading method from the 0x49 address of
        the device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 23:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['ALERT_ENABLE'][0],
                                              no_of_bytes=self.registers_addresses['ALERT_ENABLE'][1],
                                              signed=False)
        return result

    def get_accum_config_act(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the Alert_Enable register data using the mcp2221.py reading method from the 0x49 address of
        the device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 7:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['ACCUM_CONFIG_ACT'][0],
                                              no_of_bytes=self.registers_addresses['ACCUM_CONFIG_ACT'][1],
                                              signed=False)
        return result

    def get_accum_config_lat(self, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Gets the Accum_Config_Lat register data using the mcp2221.py reading method from the 0x4B address
        of the device. A Refresh command will be sent to the device before reading the register value if the
        refresh_type parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The parameter
                         is optional.
        :return: Bits 7:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        if use_list is False:
            result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['ACCUM_CONFIG_LAT'][0],
                                                  no_of_bytes=self.registers_addresses['ACCUM_CONFIG_LAT'][1],
                                                  signed=False)
        else:
            result = self.registers_values['accum_config_lat']
        return result

    def get_product_id(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the Product_ID register data using the mcp2221.py reading method from the 0xFD address of the
        device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 7:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['PRODUCT_ID'][0],
                                              no_of_bytes=self.registers_addresses['PRODUCT_ID'][1],
                                              signed=False)
        return result

    def get_manufacturer_id(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the Manufacturer_ID register data using the mcp2221.py reading method from the 0xFE address of
        the device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 7:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['MANUFACTURER_ID'][0],
                                              no_of_bytes=self.registers_addresses['MANUFACTURER_ID'][1],
                                              signed=False)
        return result

    def get_revision_id(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the Revision_ID register data using the mcp2221.py reading method from the 0xFF address of the
        device. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: Bits 7:0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type=refresh_type, delay=delay)
            if result != 0:
                self.last_error = result
                return None
        result = self.read_register_i2c_smbus(reg_address=self.registers_addresses['REVISION_ID'][0],
                                              no_of_bytes=self.registers_addresses['REVISION_ID'][1],
                                              signed=False)
        return result

    def send_refresh(self, refresh_type, delay=0.128):
        """
        Description: Selects one of the 3 methods that send a refresh command to the device using the mcp2221.py writing
        method to the corresponding address. The refresh type must be specified when calling this method. After the
        selected command is sent, the program waits for a configurable number of seconds, so it makes sure the command
        has taken effect. The method updates the previous and current timestamp.

        :param refresh_type: Represents the type of refresh which will be sent to the device. For sending a refresh,
                             select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G, pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed
                 ERROR_INPUT_PARAMETER, if the refresh_type is out of the specified range
                 ERROR_MCP2221_BRIDGE_MISSING, if no mcp2221 bridge has been added to the pac194x5x attributes
        """
        if refresh_type == self.REFRESH:
            result = self.refresh(delay)
        elif refresh_type == self.REFRESH_G:
            result = self.refresh_g(delay)
        elif refresh_type == self.REFRESH_V:
            result = self.refresh_v(delay)
        else:
            self.last_error = self.ERROR_INPUT_PARAMETER
            result = self.ERROR_INPUT_PARAMETER

        return result

    # Set features

    def set_rsense(self, value, channel_index):
        """
        Description: Sets the sense resistor in Ohms for the selected channel. The value will be saved in the
        pac194x5x.rsense attribute. The value will be used for the specified channel to determine the real values of the
        measurements (e.g. current, current_avg, etc.)

        :param value: The resistor value measured in Ohms that will be stored in the rsense array.
        :param channel_index: Selects for which channel to set the resistor value.It takes one of the values:1, 2, 3, 4.

        :return: Nothing
        """
        self.rsense[channel_index - 1] = value   # ohms

    def set_sample_mode(self, sample_mode, refresh_type=None, delay=0.128):
        """
        Description: Sets the sample mode for the device by reconfiguring the 4 most significant bits of the Control
        register and if the refresh type has been added, it will send a refresh command for the settings to take effect,
        after which it will wait for a configurable number of seconds,so it makes sure the command has taken effect.

        :param sample_mode: Represents a number between 0-11 or that is equal to 15 which corresponds to one of the
                            sample modes of the device. For an easier interpretation and usage, library constants are
                            recommended to be used when setting this parameter.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER, if the sample_mode parameter is None or the refresh_type is out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if sample_mode is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        if (0 <= sample_mode & sample_mode <= 11) | (sample_mode == 15):
            control = self.get_control()
            mode = sample_mode << 12
            control = (control & 0xfff) | mode
        else:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER
        result = self.set_control(control)
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
        return result

    def disable_channel(self, channel_index, disable, refresh_type=None, delay=0.128):
        """
        Description: Disables or enables the selected channel by reconfiguring the Control register value and if the
        refresh type has been added, it will send a refresh command for the settings to take effect, after which it will
        wait for a configurable number of seconds, so it makes sure the command has taken effect.

        :param channel_index: Selects the channel that will be disabled or enabled. It takes one of the values: 1, 2, 3,
                              4
        :param disable: Specifies if the channel should be disabled (disable is True) or enabled (disable is False)
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 MCP2221 error code, if the command could not be performed;
                 ERROR_INPUT_PARAMETER,if the disable parameter is None,the channel_index or the refresh_type parameters
                 are out of range.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if (channel_index is None) | (disable is None):
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        control = self.get_control()
        if channel_index == 1:
            control = control & 0xFF7F
            if disable is True:
                control = control | 0x80
        elif channel_index == 2:
            control = control & 0xFFBF
            if disable is True:
                control = control | 0x40
        elif channel_index == 3:
            control = control & 0xFFDF
            if disable is True:
                control = control | 0x20
        elif channel_index == 4:
            control = control & 0xFFEF
            if disable is True:
                control = control | 0x10
        else:
            return self.ERROR_INPUT_PARAMETER

        result = self.set_control(control)
        if result != 0:
            self.last_error = result
            return result

        # do a refresh in order for the settings to take effect
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
        return result

    # Get measurements features

    def get_bidir_fsr_v_lat(self, channel_index, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Reads the Neg_Pwr_Fsr_Lat register in order to determine the bidirectionality and the full scale
        range of the selected channel corresponding to Vbus measurement. The two values will be returned as separated
        values. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param channel_index: Selects for which channel to get the data. It takes one of the values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: (bool)bidir, (bool)fsr, if successful;
                 None, otherwise.
        """
        if use_list is False:
            value = self.get_neg_pwr_fsr_lat(refresh_type, delay)
        else:
            value = self.registers_values['neg_pwr_fsr_lat']

        if channel_index == 1:
            bits_value = self.get_bits_value(value, 2, 6)
        elif channel_index == 2:
            bits_value = self.get_bits_value(value, 2, 4)
        elif channel_index == 3:
            bits_value = self.get_bits_value(value, 2, 2)
        elif channel_index == 4:
            bits_value = self.get_bits_value(value, 2, 0)
        else:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return None

        if bits_value == 1 or bits_value == 2:
            bidir = True
        else:
            bidir = False

        if bits_value == 2:
            fsr = False
        else:
            fsr = True

        return bidir, fsr

    def get_bidir_fsr_i_lat(self, channel_index, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Reads the Neg_Pwr_Fsr_Lat register in order to determine the bidirectionality and the full scale
        range of the selected channel corresponding to Vsense measurement. The two values will be returned as separated
        values. A Refresh command will be sent to the device before reading the register value if the refresh_type
        parameter has been added.

        :param channel_index: Selects for which channel to get the data. It takes one of the values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: (bool)bidir, (bool)fsr, if successful;
                 None, otherwise.
        """
        if use_list is False:
            value = self.get_neg_pwr_fsr_lat(refresh_type, delay)
        else:
            value = self.registers_values['neg_pwr_fsr_lat']

        if channel_index == 1:
            bits_value = self.get_bits_value(value, 2, 14)
        elif channel_index == 2:
            bits_value = self.get_bits_value(value, 2, 12)
        elif channel_index == 3:
            bits_value = self.get_bits_value(value, 2, 10)
        elif channel_index == 4:
            bits_value = self.get_bits_value(value, 2, 8)
        else:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return None

        if bits_value == 1 or bits_value == 2:
            bidir = True
        else:
            bidir = False

        if bits_value == 2:
            fsr = False
        else:
            fsr = True

        return bidir, fsr

    def get_vbus_lsb(self, channel_index, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Calculates the Vbus LSB value for the selected channel based on the device type, bidirectionality
        and full scale range of the channel. The value is used as a coefficient for establishing the real value of the
        Vbus and/or Vacc (if the accumulator is configured for Vbus) registers: after the necessary register has been
        read from the device, the value will be multiplied by the vbus LSB coefficient. A Refresh command will be sent
        to the device before reading the Neg_Pwr_Fsr_Lat register value if the refresh_type parameter has been added.

        :param channel_index: Selects for which channel to calculate the LSB value. It takes one of the values: 1, 2, 3,
                              4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: (float)vbus_lsb, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
            if result != 0:
                self.last_error = result
                return None

        if self.pac5x == 0:  # if the device is pac194x
            vbus_scale_lat = self.VBUS_SCALE_9
        else:
            vbus_scale_lat = self.VBUS_SCALE_32

        bidir, fsr = self.get_bidir_fsr_v_lat(channel_index, use_list=use_list)
        if bidir is True:
            vbus_scale_lat *= 2
        if fsr is False:  # if is fsr/2
            vbus_scale_lat /= 2

        vbus_lsb = vbus_scale_lat / float(pow(2, 16))

        return vbus_lsb

    def get_vsense_lsb(self, channel_index, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Calculates the Vsense LSB value for the selected channel based on the bidirectionality and
        fullscale range of the channel. The value is used as a coefficient for establishing the real value of the Vsense
        and/or Vacc (if the accumulator is configured for Vsense) registers: after the necessary register has been read
        from the device, the value will be multiplied by the vsense lsb coefficient. A Refresh command will be sent to
        the device before reading the Neg_Pwr_Fsr_Lat register value if the refresh_type parameter has been added.

        :param channel_index: Selects for which channel to calculate the LSB value. It takes one of the values: 1, 2, 3,
                              4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: (float)vsense_lsb, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
            if result != 0:
                self.last_error = result
                return None

        vsense_scale_lat = self.VSENSE_SCALE_100MV

        bidir, fsr = self.get_bidir_fsr_i_lat(channel_index, use_list=use_list)
        if bidir is True:
            vsense_scale_lat *= 2
        if fsr is False:  # if is fsr/2
            vsense_scale_lat /= 2

        vsense_lsb = vsense_scale_lat / float(pow(2, 16))

        return vsense_lsb

    def get_power_unit(self, channel_index, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Calculates the power unit for the selected channel based on the device type, bidirectionality and
        full scale range of the channel. The value is used as a coefficient for establishing the real value of the
        Vpower and/or Vacc (if the accumulator is configured for Vpower) registers: after the necessary register has
        been read from the device, the value will be multiplied by the power coefficient. A Refresh command will be sent
        to the device before reading the Neg_Pwr_Fsr_Lat register value if the refresh_type parameter has been added.

        :param channel_index: Selects for which channel to calculate the power unit. It takes one of the values: 1, 2,
                              3,4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: (float)power_unit, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
            if result != 0:
                self.last_error = result
                return None

        if self.pac5x == 0:  # if the device is pac194x
            power_scale_lat = (self.VSENSE_SCALE_100MV * self.VBUS_SCALE_9) / (self.rsense[channel_index - 1] * 1000)
        else:
            power_scale_lat = (self.VSENSE_SCALE_100MV * self.VBUS_SCALE_32) / (self.rsense[channel_index - 1] * 1000)

        bidir_v, fsr_v = self.get_bidir_fsr_v_lat(channel_index, use_list=use_list)
        bidir_i, fsr_i = self.get_bidir_fsr_i_lat(channel_index, use_list=use_list)

        if (bidir_v is True) or (bidir_i is True):
            power_scale_lat *= 2
        if (fsr_v is False) or (fsr_i is False):  # if is fsr/2
            power_scale_lat /= 2

        power_unit = power_scale_lat / float(pow(2, 30))

        return power_unit

    def get_ch_accum_config(self, channel_index, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Returns the accumulator configuration for the channel mentioned in the parameters that is stored in
        the Accum Config Lat register. A Refresh command will be sent to the device before reading the Neg_Pwr_Fsr_Lat
        register value if the refresh_type parameter has been added.

        :param channel_index: Selects for which channel to get the accumulator configuration.It takes one of the values:
                              1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: 0, if the accumulator is configured for Vpower;
                 1, if the accumulator is configured for Vsense;
                 2, if the accumulator is configured for Vbus;
                 None, otherwise.
        """
        value = self.get_accum_config_lat(refresh_type, delay, use_list=use_list)

        if channel_index == 1:
            bits_value = self.get_bits_value(value, 2, 6)
        elif channel_index == 2:
            bits_value = self.get_bits_value(value, 2, 4)
        elif channel_index == 3:
            bits_value = self.get_bits_value(value, 2, 2)
        elif channel_index == 4:
            bits_value = self.get_bits_value(value, 2, 0)
        else:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return None
        return bits_value

    def get_sample_frequency(self, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Reads the Control Lat register and extracts the frequency of the device that has been set. The
        method is used for computing the energy based on the frequency. A Refresh command will be sent to the device
        before reading the Neg_Pwr_Fsr_Lat register value if the refresh_type parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: sample_frequency, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
            if result != 0:
                self.last_error = result
                return None

        res = self.get_control_lat(use_list=use_list)
        if res is None:
            return None

        result = self.get_bits_value(res, 4, 4)
        no_ch_on = 0
        if (result & 0x1) == 0:
            no_ch_on += 1
        elif (result & 0x2) == 0:
            no_ch_on += 1
        elif (result & 0x4) == 0:
            no_ch_on += 1
        elif (result & 0x8) == 0:
            no_ch_on += 1

        if self.active_channels < no_ch_on:
            no_ch_on = self.active_channels

        result = self.get_bits_value(res, 4, 12)
        if (result >= 0) & (result < 5):
            return 1024
        elif result == 5:
            return 256
        elif result == 6:
            return 64
        elif result == 7:
            return 8
        elif result == 8:
            return 0xffffffff
        elif result == 9:
            return 0xffffffff
        elif (result == 10) | (result == 11):
            return (1024 * 5) / float(no_ch_on)
        elif result == 15:
            return 0xffffffff

    def get_sample_mode(self, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Reads the Control Lat register in order to determine the sample mode of the device. A Refresh
        command will be sent to the device before reading the register value if the refresh_type parameter has been
        added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: 0, for 1024sps adaptive accumulation mode;
                 1, for 256sps adaptive accumulation mode;
                 2, for 64sps adaptive accumulation mode;
                 3, for 8sps mode;
                 4, for 1024sps mode;
                 5, for 256sps mode;
                 6, for 64sps mode;
                 7, for 8sps mode;
                 8, for Single Shot mode;
                 9, for Single Shot 8x mode;
                 10, for FAST mode;
                 11, for BURST mode;
                 15, for SLEEP mode;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
            if result != 0:
                self.last_error = result
                return None

        result = self.get_control_lat(use_list=use_list)
        if result is None:
            return None

        return self.get_bits_value(result, 4, 12)

    def get_channel_alert_status(self, channel_index, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Reads the Alert Status register and gets the data for the selected channel, returning an array of
        five boolean elements that contains the status of all 5 alerts: over current, under current, over power, over
        voltage and under voltage. An alert has been triggered if its status is True, else it is False. A Refresh
        command will be sent to the device before reading the register value if the refresh_type parameter has been
        added.

        :param channel_index: Selects for which channel to get the alerts status. It takes one of the values:1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: (boolean array) alerts, if successful containing the boolean state of the channel alerts in this order:
                 over current, under current, over power, over voltage and under voltage;
                 None, otherwise.

        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
            if result != 0:
                self.last_error = result
                return None

        value = self.get_alert_status(use_list=use_list)
        if value is None:
            return None
        alerts = np.empty(5, dtype=bool)    # OC, UC, OV, UV, OP
        position = [23, 22, 21, 20]
        pos_cnt = 0
        alerts[0] = bool(self.get_bits_value(value, 1, position[channel_index-1]-pos_cnt))
        pos_cnt += 4
        alerts[1] = bool(self.get_bits_value(value, 1, position[channel_index-1]-pos_cnt))
        pos_cnt += 4
        alerts[2] = bool(self.get_bits_value(value, 1, position[channel_index-1]-pos_cnt))
        pos_cnt += 4
        alerts[3] = bool(self.get_bits_value(value, 1, position[channel_index-1]-pos_cnt))
        pos_cnt += 4
        alerts[4] = bool(self.get_bits_value(value, 1, position[channel_index-1]-pos_cnt))

        return alerts

    def detect_slow_transition(self, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Reads the Slow register and checks what kind of transition took place. A Refresh command will be
        sent to the device before reading the register value if the refresh_type parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: 0, no change;
                 1, low-high transition;
                 2, low-high refresh;
                 3, low-high refresh_v;
                 5, high-low transition;
                 6, high-low refresh;
                 7, high-low refresh_v;
                 10, low-high and high-low double transition;
                 None, otherwise.
        """
        # SLOW, SLOW-HL, SLOW-LH flags are updated by the SLOW transition - no REFRESH need
        # return codes:
        # -1=error, 0=no change.
        # 1=LH, 2=LH REFRESH, 3=LH REFRESH_V
        # 5=HL, 6=HL RERESH, 7=HL REFRESH_V
        # 10=LH and HL (double transition)

        # read SLOW register
        if use_list is False:
            slow_reg = self.get_slow(refresh_type=refresh_type, delay=delay)
            if slow_reg is None:
                return None
        else:
            slow_reg = self.registers_values['slow']

        slow_transition = 0  # no transition

        if (slow_reg & 0x60) == 0x60:
            slow_transition = 10  # double transition
        elif (slow_reg & 0x40) == 0x40:
            # if SLOW-LH is set check R_RISE and R_V_RISE
            # if both R_RISE and R_V_RISE set, lim REFRESH takes priority
            slow_transition = 1
            if (slow_reg & 0x18) == 0x08:
                slow_transition = 3  # LH lim REFRESH_V
            if (slow_reg & 0x10) == 0x10:
                slow_transition = 2  # SLOW[4,3]=b11 => LH lim REFRESH
        elif (slow_reg & 0x20) == 0x20:
            # if SLOW-HL is set check R_FALL and R_V_FALL
            # if both R_FALL and R_V_FALL set, lim REFRESH takes priority
            slow_transition = 5
            if (slow_reg & 0x06) == 0x02:
                slow_transition = 7  # HL lim REFRESH_V
            if (slow_reg & 0x04) == 0x04:
                slow_transition = 6  # SLOW[2,1]=b11 => HL lim REFRESH

        return slow_transition

    def detect_overflow(self, refresh_type=None, delay=0.128, use_list=False):
        """
        Description: Reads the Alerts Status register and checks the state of the overflow bit, returning if this was
        set to True or False. A Refresh command will be sent to the device before reading the register value if the
        refresh_type parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :param use_list: Represents the choice whether the data will be read from the device (use_list is False) or from
                         the self.registers_values dictionary (use_list is True) after it has been updated. The
                         parameter is optional.
        :return: True, if an overflow has been detected;
                 False, if an overflow has not been detected;
                 None, otherwise.
        """
        value = self.get_alert_status(refresh_type=refresh_type, delay=delay, use_list=use_list)
        if value is None:
            return None
        ovf_det = bool(self.get_bits_value(value, 1, 3))
        return ovf_det

    # Get data methods

    def update_registers_values(self, refresh_type=None, delay=0.128):
        """
        Description: Updates the dictionary attribute register_values by reading all the registers from the device and
        storing their values individually. This method verifies if the NO SKIP feature is enabled or not and interprets
        the data accordingly from the device. Besides, the Control Lat and Neg_Pwr_Fsr_Lat registers are also taken into
        consideration as the number of available channels, bidirectionality and full scale range are important for data
        interpretation from the device. The registers_values dictionary can be used to access data faster by using the
        use_list parameter available for some of the library methods. A Refresh command will be sent to the device
        before reading the data if the refresh_type parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: 0, if successful;
                 None, otherwise.
        """
        if refresh_type is not None:
            result = self.send_refresh(refresh_type, delay)
            if result != 0:
                return result

        for reg in self.registers_values:
            self.registers_values[reg] = 0

        result = self.get_smbus()
        if result is None:
            return result
        self.registers_values['smbus'] = result
        noskip = (result >> 1) & 0x1

        result = self.get_control_lat()
        if result is None:
            return result
        self.registers_values['control_lat'] = result

        result = self.get_neg_pwr_fsr_lat()
        if result is None:
            return result
        self.registers_values['neg_pwr_fsr_lat'] = result

        result = self.read_all_registers()
        if result is None:
            return result

        res = 0
        # result = result.tobytes()
        offset = 0

        bidir_v = np.empty(4, dtype=bool)
        bidir_v[0], _ = self.get_bidir_fsr_v_lat(1, use_list=True)
        bidir_v[1], _ = self.get_bidir_fsr_v_lat(2, use_list=True)
        bidir_v[2], _ = self.get_bidir_fsr_v_lat(3, use_list=True)
        bidir_v[3], _ = self.get_bidir_fsr_v_lat(4, use_list=True)
        bidir_i = np.empty(4, dtype=bool)
        bidir_i[0], _ = self.get_bidir_fsr_i_lat(1, use_list=True)
        bidir_i[1], _ = self.get_bidir_fsr_i_lat(2, use_list=True)
        bidir_i[2], _ = self.get_bidir_fsr_i_lat(3, use_list=True)
        bidir_i[3], _ = self.get_bidir_fsr_i_lat(4, use_list=True)

        if noskip == 1:
            self.registers_values['control'] = int.from_bytes(result[offset:offset + 2],
                                                              byteorder='big', signed=False)
            offset += 2
            self.registers_values['acc_count'] = int.from_bytes(result[offset:offset + 4],
                                                                byteorder='big', signed=False)
            offset += 4
            self.registers_values['vacc_ch1'] = int.from_bytes(result[offset:offset + 7], byteorder='big',
                                                               signed=(bidir_v[0] | bidir_i[0]))
            offset += 7
            self.registers_values['vacc_ch2'] = int.from_bytes(result[offset:offset + 7], byteorder='big',
                                                               signed=(bidir_v[1] | bidir_i[1]))
            offset += 7
            self.registers_values['vacc_ch3'] = int.from_bytes(result[offset:offset + 7], byteorder='big',
                                                               signed=(bidir_v[2] | bidir_i[2]))
            offset += 7
            self.registers_values['vacc_ch4'] = int.from_bytes(result[offset:offset + 7], byteorder='big',
                                                               signed=(bidir_v[3] | bidir_i[3]))
            offset += 7
            self.registers_values['vbus_ch1'] = int.from_bytes(result[offset:offset + 2], byteorder='big',
                                                               signed=bidir_v[0])
            offset += 2
            self.registers_values['vbus_ch2'] = int.from_bytes(result[offset:offset + 2], byteorder='big',
                                                               signed=bidir_v[1])
            offset += 2
            self.registers_values['vbus_ch3'] = int.from_bytes(result[offset:offset + 2], byteorder='big',
                                                               signed=bidir_v[2])
            offset += 2
            self.registers_values['vbus_ch4'] = int.from_bytes(result[offset:offset + 2], byteorder='big',
                                                               signed=bidir_v[3])
            offset += 2
            self.registers_values['vsense_ch1'] = int.from_bytes(result[offset:offset + 2], byteorder='big',
                                                                 signed=bidir_i[0])
            offset += 2
            self.registers_values['vsense_ch2'] = int.from_bytes(result[offset:offset + 2], byteorder='big',
                                                                 signed=bidir_i[1])
            offset += 2
            self.registers_values['vsense_ch3'] = int.from_bytes(result[offset:offset + 2], byteorder='big',
                                                                 signed=bidir_i[2])
            offset += 2
            self.registers_values['vsense_ch4'] = int.from_bytes(result[offset:offset + 2], byteorder='big',
                                                                 signed=bidir_i[3])
            offset += 2
            self.registers_values['vbus_avg_ch1'] = int.from_bytes(result[offset:offset + 2], byteorder='big',
                                                                   signed=bidir_v[0])
            offset += 2
            self.registers_values['vbus_avg_ch2'] = int.from_bytes(result[offset:offset + 2], byteorder='big',
                                                                   signed=bidir_v[1])
            offset += 2
            self.registers_values['vbus_avg_ch3'] = int.from_bytes(result[offset:offset + 2], byteorder='big',
                                                                   signed=bidir_v[2])
            offset += 2
            self.registers_values['vbus_avg_ch4'] = int.from_bytes(result[offset:offset + 2], byteorder='big',
                                                                   signed=bidir_v[3])
            offset += 2
            self.registers_values['vsense_avg_ch1'] = int.from_bytes(result[offset:offset + 2], byteorder='big',
                                                                     signed=bidir_i[0])
            offset += 2
            self.registers_values['vsense_avg_ch2'] = int.from_bytes(result[offset:offset + 2], byteorder='big',
                                                                     signed=bidir_i[1])
            offset += 2
            self.registers_values['vsense_avg_ch3'] = int.from_bytes(result[offset:offset + 2], byteorder='big',
                                                                     signed=bidir_i[2])
            offset += 2
            self.registers_values['vsense_avg_ch4'] = int.from_bytes(result[offset:offset + 2], byteorder='big',
                                                                     signed=bidir_i[3])
            offset += 2
            self.registers_values['vpower_ch1'] = int.from_bytes(result[offset:offset + 4], byteorder='big',
                                                                 signed=(bidir_v[0] | bidir_i[0]))
            offset += 4
            self.registers_values['vpower_ch2'] = int.from_bytes(result[offset:offset + 4], byteorder='big',
                                                                 signed=(bidir_v[1] | bidir_i[1]))
            offset += 4
            self.registers_values['vpower_ch3'] = int.from_bytes(result[offset:offset + 4], byteorder='big',
                                                                 signed=(bidir_v[2] | bidir_i[2]))
            offset += 4
            self.registers_values['vpower_ch4'] = int.from_bytes(result[offset:offset + 4], byteorder='big',
                                                                 signed=(bidir_v[3] | bidir_i[3]))
            offset += 4
        else:
            ch_on = np.empty(4)
            no_ch_on = 0
            ch1_off, ch2_off, ch3_off, ch4_off = 1, 1, 1, 1
            idx2, idx3,  idx4, idx7 = 0, 0, 0, 0

            self.registers_values['control'] = int.from_bytes(result[offset:offset + 2],
                                                              byteorder='big', signed=False)
            offset += 2
            ctrl_reg = self.registers_values['control']
            if (ctrl_reg & 0x80) == 0:
                ch_on[no_ch_on] = 0
                ch1_off = 0
                no_ch_on += 1
            if (ctrl_reg & 0x40) == 0:
                ch_on[no_ch_on] = 0
                ch2_off = 0
                no_ch_on += 1
            if (ctrl_reg & 0x20) == 0:
                ch_on[no_ch_on] = 0
                ch3_off = 0
                no_ch_on += 1
            if (ctrl_reg & 0x10) == 0:
                ch_on[no_ch_on] = 0
                ch4_off = 0
                no_ch_on += 1

            if self.active_channels < no_ch_on:
                no_ch_on = self.active_channels

            # number_ch_on = no_ch_on
            vacc = bytearray()
            vbus = bytearray()
            vsense = bytearray()
            vbusavg = bytearray()
            vsenseavg = bytearray()
            vpow = bytearray()

            self.registers_values['acc_count'] = int.from_bytes(result[offset:offset + 4],
                                                                byteorder='big', signed=False)
            offset += 4

            for i in range(0, no_ch_on * 7):
                vacc.append(result[offset])
                offset += 1
            for i in range(0, no_ch_on * 2):
                vbus.append(result[offset])
                offset += 1
            for i in range(0, no_ch_on * 2):
                vsense.append(result[offset])
                offset += 1
            for i in range(0, no_ch_on * 2):
                vbusavg.append(result[offset])
                offset += 1
            for i in range(0, no_ch_on * 2):
                vsenseavg.append(result[offset])
                offset += 1
            for i in range(0, no_ch_on * 4):
                vpow.append(result[offset])
                offset += 1

            if (ch1_off == 0) & (1 <= self.active_channels):
                self.registers_values['vacc_ch1'] = int.from_bytes(vacc[idx7:idx7 + 7], byteorder='big',
                                                                   signed=(bidir_v[0] | bidir_i[0]))
                self.registers_values['vbus_ch1'] = int.from_bytes(vbus[idx2:idx2 + 2], byteorder='big',
                                                                   signed=bidir_v[0])
                self.registers_values['vsense_ch1'] = int.from_bytes(vsense[idx2:idx2 + 2], byteorder='big',
                                                                     signed=bidir_i[0])
                self.registers_values['vbus_avg_ch1'] = int.from_bytes(vbusavg[idx2:idx2 + 2], byteorder='big',
                                                                       signed=bidir_v[0])
                self.registers_values['vsense_avg_ch1'] = int.from_bytes(vsenseavg[idx2:idx2 + 2], byteorder='big',
                                                                         signed=bidir_i[0])
                self.registers_values['vpower_ch1'] = int.from_bytes(vpow[idx4:idx4 + 4], byteorder='big',
                                                                     signed=(bidir_v[0] | bidir_i[0]))
                idx2 += 2
                idx4 += 4
                idx7 += 7

            if (ch2_off == 0) & (2 <= self.active_channels):
                self.registers_values['vacc_ch2'] = int.from_bytes(vacc[idx7:idx7 + 7], byteorder='big',
                                                                   signed=(bidir_v[1] | bidir_i[1]))
                self.registers_values['vbus_ch2'] = int.from_bytes(vbus[idx2:idx2 + 2], byteorder='big',
                                                                   signed=bidir_v[1])
                self.registers_values['vsense_ch2'] = int.from_bytes(vsense[idx2:idx2 + 2], byteorder='big',
                                                                     signed=bidir_i[1])
                self.registers_values['vbus_avg_ch2'] = int.from_bytes(vbusavg[idx2:idx2 + 2], byteorder='big',
                                                                       signed=bidir_v[1])
                self.registers_values['vsense_avg_ch2'] = int.from_bytes(vsenseavg[idx2:idx2 + 2], byteorder='big',
                                                                         signed=bidir_i[1])
                self.registers_values['vpower_ch2'] = int.from_bytes(vpow[idx4:idx4 + 4], byteorder='big',
                                                                     signed=(bidir_v[1] | bidir_i[1]))
                idx2 += 2
                idx4 += 4
                idx7 += 7

            if (ch3_off == 0) & (3 <= self.active_channels):
                self.registers_values['vacc_ch3'] = int.from_bytes(vacc[idx7:idx7 + 7], byteorder='big',
                                                                   signed=(bidir_v[2] | bidir_i[2]))
                self.registers_values['vbus_ch3'] = int.from_bytes(vbus[idx2:idx2 + 2], byteorder='big',
                                                                   signed=bidir_v[2])
                self.registers_values['vsense_ch3'] = int.from_bytes(vsense[idx2:idx2 + 2], byteorder='big',
                                                                     signed=bidir_i[2])
                self.registers_values['vbus_avg_ch3'] = int.from_bytes(vbusavg[idx2:idx2 + 2], byteorder='big',
                                                                       signed=bidir_v[2])
                self.registers_values['vsense_avg_ch3'] = int.from_bytes(vsenseavg[idx2:idx2 + 2], byteorder='big',
                                                                         signed=bidir_i[2])
                self.registers_values['vpower_ch3'] = int.from_bytes(vpow[idx4:idx4 + 4], byteorder='big',
                                                                     signed=(bidir_v[2] | bidir_i[2]))
                idx2 += 2
                idx4 += 4
                idx7 += 7

            if (ch4_off == 0) & (4 <= self.active_channels):
                self.registers_values['vacc_ch4'] = int.from_bytes(vacc[idx7:idx7 + 7], byteorder='big',
                                                                   signed=(bidir_v[3] | bidir_i[3]))
                self.registers_values['vbus_ch4'] = int.from_bytes(vbus[idx2:idx2 + 2], byteorder='big',
                                                                   signed=bidir_v[3])
                self.registers_values['vsense_ch4'] = int.from_bytes(vsense[idx2:idx2 + 2], byteorder='big',
                                                                     signed=bidir_i[3])
                self.registers_values['vbus_avg_ch4'] = int.from_bytes(vbusavg[idx2:idx2 + 2], byteorder='big',
                                                                       signed=bidir_v[3])
                self.registers_values['vsense_avg_ch4'] = int.from_bytes(vsenseavg[idx2:idx2 + 2], byteorder='big',
                                                                         signed=bidir_i[3])
                self.registers_values['vpower_ch4'] = int.from_bytes(vpow[idx4:idx4 + 4], byteorder='big',
                                                                     signed=(bidir_v[3] | bidir_i[3]))
                idx2 += 2
                idx4 += 4
                idx7 += 7
        self.registers_values['smbus'] = int.from_bytes(result[offset:offset + 1], byteorder='big', signed=False)
        offset += 1
        self.registers_values['neg_pwr_fsr'] = int.from_bytes(result[offset:offset + 2],
                                                              byteorder='big', signed=False)
        offset += 2
        self.registers_values['slow'] = int.from_bytes(result[offset:offset + 1], byteorder='big', signed=False)
        offset += 1
        self.registers_values['control_act'] = int.from_bytes(result[offset:offset + 2],
                                                              byteorder='big', signed=False)
        offset += 2
        self.registers_values['neg_pwr_fsr_act'] = int.from_bytes(result[offset:offset + 2],
                                                                  byteorder='big', signed=False)
        offset += 2
        self.registers_values['control_lat'] = int.from_bytes(result[offset:offset + 2],
                                                              byteorder='big', signed=False)
        offset += 2
        self.registers_values['neg_pwr_fsr_lat'] = int.from_bytes(result[offset:offset + 2],
                                                                  byteorder='big', signed=False)
        offset += 2
        self.registers_values['accum_config'] = int.from_bytes(result[offset:offset + 1],
                                                               byteorder='big', signed=False)
        offset += 1
        self.registers_values['alert_status'] = int.from_bytes(result[offset:offset + 3],
                                                               byteorder='big', signed=False)
        offset += 3
        self.registers_values['slow_alert1'] = int.from_bytes(result[offset:offset + 3],
                                                              byteorder='big', signed=False)
        offset += 3
        self.registers_values['gpio_alert2'] = int.from_bytes(result[offset:offset + 3],
                                                              byteorder='big', signed=False)
        offset += 3
        self.registers_values['acc_fullness_limits'] = int.from_bytes(result[offset:offset + 2],
                                                                      byteorder='big', signed=False)
        offset += 2

        oclimit = bytearray()
        uclimit = bytearray()
        oplimit = bytearray()
        ovlimit = bytearray()
        uvlimit = bytearray()

        for i in range(self.active_channels * 2):
            oclimit.append(result[offset])
            offset += 1

        for i in range(self.active_channels * 2):
            uclimit.append(result[offset])
            offset += 1

        for i in range(self.active_channels * 3):
            oplimit.append(result[offset])
            offset += 1

        for i in range(self.active_channels * 2):
            ovlimit.append(result[offset])
            offset += 1

        for i in range(self.active_channels * 2):
            uvlimit.append(result[offset])
            offset += 1

        idx2 = 0

        if(ch1_off == 0) & (1 <= self.active_channels):
            self.registers_values['oc_limit_ch1'] = int.from_bytes(oclimit[idx2:idx2 + 2], byteorder='big', signed=True)
            self.registers_values['uc_limit_ch1'] = int.from_bytes(uclimit[idx2:idx2 + 2], byteorder='big', signed=True)
            self.registers_values['op_limit_ch1'] = int.from_bytes(oplimit[idx3:idx3 + 3], byteorder='big', signed=True)
            self.registers_values['ov_limit_ch1'] = int.from_bytes(ovlimit[idx2:idx2 + 2], byteorder='big', signed=True)
            self.registers_values['uv_limit_ch1'] = int.from_bytes(uvlimit[idx2:idx2 + 2], byteorder='big', signed=True)
            idx2 += 2
            idx3 += 3

        if (ch2_off == 0) & (2 <= self.active_channels):
            self.registers_values['oc_limit_ch2'] = int.from_bytes(oclimit[idx2:idx2 + 2], byteorder='big', signed=True)
            self.registers_values['uc_limit_ch2'] = int.from_bytes(uclimit[idx2:idx2 + 2], byteorder='big', signed=True)
            self.registers_values['op_limit_ch2'] = int.from_bytes(oplimit[idx3:idx3 + 3], byteorder='big', signed=True)
            self.registers_values['ov_limit_ch2'] = int.from_bytes(ovlimit[idx2:idx2 + 2], byteorder='big', signed=True)
            self.registers_values['uv_limit_ch2'] = int.from_bytes(uvlimit[idx2:idx2 + 2], byteorder='big', signed=True)
            idx2 += 2
            idx3 += 3

        if (ch3_off == 0) & (3 <= self.active_channels):
            self.registers_values['oc_limit_ch3'] = int.from_bytes(oclimit[idx2:idx2 + 2], byteorder='big', signed=True)
            self.registers_values['uc_limit_ch3'] = int.from_bytes(uclimit[idx2:idx2 + 2], byteorder='big', signed=True)
            self.registers_values['op_limit_ch3'] = int.from_bytes(oplimit[idx3:idx3 + 3], byteorder='big', signed=True)
            self.registers_values['ov_limit_ch3'] = int.from_bytes(ovlimit[idx2:idx2 + 2], byteorder='big', signed=True)
            self.registers_values['uv_limit_ch3'] = int.from_bytes(uvlimit[idx2:idx2 + 2], byteorder='big', signed=True)
            idx2 += 2
            idx3 += 3

        if (ch4_off == 0) & (4 <= self.active_channels):
            self.registers_values['oc_limit_ch4'] = int.from_bytes(oclimit[idx2:idx2 + 2], byteorder='big', signed=True)
            self.registers_values['uc_limit_ch4'] = int.from_bytes(uclimit[idx2:idx2 + 2], byteorder='big', signed=True)
            self.registers_values['op_limit_ch4'] = int.from_bytes(oplimit[idx3:idx3 + 3], byteorder='big', signed=True)
            self.registers_values['ov_limit_ch4'] = int.from_bytes(ovlimit[idx2:idx2 + 2], byteorder='big', signed=True)
            self.registers_values['uv_limit_ch4'] = int.from_bytes(uvlimit[idx2:idx2 + 2], byteorder='big', signed=True)
            idx2 += 2
            idx3 += 3


        # self.registers_values['oc_limit_ch1'] = int.from_bytes(oclimit[idx2:idx2 + 2],
        #                                                        byteorder='big', signed=True)
        # offset += 2
        # self.registers_values['oc_limit_ch2'] = int.from_bytes(result[offset:offset + 2],
        #                                                        byteorder='big', signed=True)
        # offset += 2
        # self.registers_values['oc_limit_ch3'] = int.from_bytes(result[offset:offset + 2],
        #                                                        byteorder='big', signed=True)
        # offset += 2
        # self.registers_values['oc_limit_ch4'] = int.from_bytes(result[offset:offset + 2],
        #                                                        byteorder='big', signed=True)
        # offset += 2
        # self.registers_values['uc_limit_ch1'] = int.from_bytes(result[offset:offset + 2],
        #                                                        byteorder='big', signed=True)
        # offset += 2
        # self.registers_values['uc_limit_ch2'] = int.from_bytes(result[offset:offset + 2],
        #                                                        byteorder='big', signed=True)
        # offset += 2
        # self.registers_values['uc_limit_ch3'] = int.from_bytes(result[offset:offset + 2],
        #                                                        byteorder='big', signed=True)
        # offset += 2
        # self.registers_values['uc_limit_ch4'] = int.from_bytes(result[offset:offset + 2],
        #                                                        byteorder='big', signed=True)
        # offset += 2
        # self.registers_values['op_limit_ch1'] = int.from_bytes(result[offset:offset + 3],
        #                                                        byteorder='big', signed=True)
        # offset += 3
        # self.registers_values['op_limit_ch2'] = int.from_bytes(result[offset:offset + 3],
        #                                                        byteorder='big', signed=True)
        # offset += 3
        # self.registers_values['op_limit_ch3'] = int.from_bytes(result[offset:offset + 3],
        #                                                        byteorder='big', signed=True)
        # offset += 3
        # self.registers_values['op_limit_ch4'] = int.from_bytes(result[offset:offset + 3],
        #                                                        byteorder='big', signed=True)
        # offset += 3
        # self.registers_values['ov_limit_ch1'] = int.from_bytes(result[offset:offset + 2],
        #                                                        byteorder='big', signed=True)
        # offset += 2
        # self.registers_values['ov_limit_ch2'] = int.from_bytes(result[offset:offset + 2],
        #                                                        byteorder='big', signed=True)
        # offset += 2
        # self.registers_values['ov_limit_ch3'] = int.from_bytes(result[offset:offset + 2],
        #                                                        byteorder='big', signed=True)
        # offset += 2
        # self.registers_values['ov_limit_ch4'] = int.from_bytes(result[offset:offset + 2],
        #                                                        byteorder='big', signed=True)
        # offset += 2
        # self.registers_values['uv_limit_ch1'] = int.from_bytes(result[offset:offset + 2],
        #                                                        byteorder='big', signed=True)
        # offset += 2
        # self.registers_values['uv_limit_ch2'] = int.from_bytes(result[offset:offset + 2],
        #                                                        byteorder='big', signed=True)
        # offset += 2
        # self.registers_values['uv_limit_ch3'] = int.from_bytes(result[offset:offset + 2],
        #                                                        byteorder='big', signed=True)
        # offset += 2
        # self.registers_values['uv_limit_ch4'] = int.from_bytes(result[offset:offset + 2],
        #                                                        byteorder='big', signed=True)
        # offset += 2
        self.registers_values['oc_limit_nsample'] = int.from_bytes(result[offset:offset + 1],
                                                                   byteorder='big', signed=False)
        offset += 1
        self.registers_values['uc_limit_nsample'] = int.from_bytes(result[offset:offset + 1],
                                                                   byteorder='big', signed=False)
        offset += 1
        self.registers_values['op_limit_nsample'] = int.from_bytes(result[offset:offset + 1],
                                                                   byteorder='big', signed=False)
        offset += 1
        self.registers_values['ov_limit_nsample'] = int.from_bytes(result[offset:offset + 1],
                                                                   byteorder='big', signed=False)
        offset += 1
        self.registers_values['uv_limit_nsample'] = int.from_bytes(result[offset:offset + 1],
                                                                   byteorder='big', signed=False)
        offset += 1
        self.registers_values['alert_enable'] = int.from_bytes(result[offset:offset + 3],
                                                               byteorder='big', signed=False)
        offset += 3
        self.registers_values['accum_config_act'] = int.from_bytes(result[offset:offset + 1],
                                                                   byteorder='big', signed=False)
        offset += 1
        self.registers_values['accum_config_lat'] = int.from_bytes(result[offset:offset + 1],
                                                                   byteorder='big', signed=False)
        offset += 1
        self.registers_values['product_id'] = int.from_bytes(result[offset:offset + 1],
                                                             byteorder='big', signed=False)
        offset += 1
        self.registers_values['manufacturer_id'] = int.from_bytes(result[offset:offset + 1],
                                                                  byteorder='big', signed=False)
        offset += 1
        self.registers_values['revision_id'] = int.from_bytes(result[offset:offset + 1],
                                                              byteorder='big', signed=False)

        return res

    def read_register_i2c_smbus(self, reg_address, no_of_bytes, signed=False):
        """
        Description: Returns the value of the register whose address and number of bytes are specified in the input
        parameters. The reading procedure is done accordingly to the communication protocol (I2C or SMBus). If the
        register that will be read from the device is the 'SMBUS', then the method will check if the communication
        protocol has changed, so it will use the correct protocol when communicating with the device.

        :param reg_address: Represents the address of the register that is to be read from the device.
        :param no_of_bytes: Represents the number of bytes of the register that is to be read from the device.
        :param signed: Represents the sign of the register that is to be read from the device.

        :return: (int)register_value, bits MSB:LSB, if successful;
                 None, otherwise.
        """
        if self.i2c_communication_protocol is True:
            if self.mcp2221:
                result = self.mcp2221.I2C_Write(self.i2c_address, [reg_address])
                if result == 0:
                    result = self.mcp2221.I2C_Read(self.i2c_address, no_of_bytes)
                    result = int.from_bytes(result, byteorder='big', signed=signed)
                else:
                    self.last_error = result
                    return None
            else:
                self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
                return None
        else:
            if self.mcp2221:
                result = self.mcp2221.SMBus_Block_Read(self.i2c_address, usePec=0,
                                                       regAddr=reg_address, byteCount=no_of_bytes)
                result = int.from_bytes(result, byteorder='big', signed=signed)
            else:
                self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
                return None

        if reg_address == self.registers_addresses['SMBUS'][0]:
            byte_count = self.get_bits_value(value=result, no_of_bits=1, position=2)
            if byte_count == 1:
                self.i2c_communication_protocol = False
            else:
                self.i2c_communication_protocol = True

        return result

    def write_register(self, reg_value, reg_address, no_of_bytes):
        """
        Description: Writes the specified value to the address mentioned in the input parameters which corresponds to a
        specific register. If the register that will be written to the device is the 'SMBUS', then the method will check
        if the communication protocol has changed, so it will use the correct protocol when communicating with the
        device.

        :param reg_value: Represents the value that will be sent to the device in order to set a register.
        :param reg_address: Represents the address of the register that will be set.
        :param no_of_bytes: Represents the number of bytes corresponding to the register that will be set.

        :return: 0, if successful;
                 ERROR_MCP2221_BRIDGE_MISSING, if no mcp2221 bridge has been added to the pac194x5x attributes;
                 ERROR_INPUT_PARAMETER, if the reg_value exceeds the number of bytes specified or if the number of bytes
                 is out of the range {0, 1, 2, 3} or if the reg_value is None.
        """
        if self.mcp2221 is None:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return self.ERROR_MCP2221_BRIDGE_MISSING
        if reg_value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        value = reg_value.to_bytes(no_of_bytes, 'big', signed=False)
        if len(value) > no_of_bytes:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        if no_of_bytes == 0:
            result = self.mcp2221.I2C_Write(self.i2c_address, [reg_address])
        elif no_of_bytes == 1:
            result = self.mcp2221.I2C_Write(self.i2c_address, [reg_address, value[0]])
        elif no_of_bytes == 2:
            result = self.mcp2221.I2C_Write(self.i2c_address, [reg_address, value[0], value[1]])
        elif no_of_bytes == 3:
            result = self.mcp2221.I2C_Write(self.i2c_address, [reg_address, value[0], value[1], value[2]])
        else:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return self.ERROR_INPUT_PARAMETER

        if result != 0:
            self.last_error = result
            return result

        if reg_address == self.registers_addresses['SMBUS'][0]:
            byte_count = self.get_bits_value(value=reg_value, no_of_bits=1, position=2)
            if byte_count == 1:
                self.i2c_communication_protocol = False
            else:
                self.i2c_communication_protocol = True

        # # do a refresh in order for the settings to take effect
        # if refresh_type is not None:
        #     result = self.send_refresh(refresh_type, delay)
        return result

    def read_all_registers(self, refresh_type=None, delay=0.128):
        """
        Description: Performs a reading command from the device that gets all the registers values packed in a bytearray.
        The method sends the first address from the registers list (0x01) and the total number of readable bytes, then
        it will get the data. The reading procedure is done accordingly to the established communication protocol
        (I2C/SMBus). A Refresh command will be sent to the device before reading the data if the refresh_type parameter
        has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: (bytearray) registers values, if successful;
                 None, otherwise.
        """
        if self.i2c_communication_protocol is True:
            start_address = 0x1
            if self.mcp2221:
                if refresh_type is not None:
                    result = self.send_refresh(refresh_type, delay)
                    if result != 0:
                        self.last_error = result
                        return None

                result = self.mcp2221.I2C_Write(self.i2c_address, [start_address])
                if result == 0:
                    result = self.mcp2221.I2C_Read(self.i2c_address, self.TOTAL_NUMBER_OF_BYTES)
                    if len(result) == self.TOTAL_NUMBER_OF_BYTES:
                        return result
                    else:
                        self.last_error = result
                        return None
                else:
                    self.last_error = result
                    return None
            else:
                self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
                return None
        else:
            # SMBUS - READ BLOCK
            #  we wanted to get all data using MCP2221.M_Mcp2221_SmbusBlockRead(CtrlIfHandle, I2cAddr_7b,
            #  use7bitAddress, usePEC, startAddr, byteCount, txDataSmbus);
            # we got -414 error code (block mismatch) and data was not written in the txDataSmbus buffer
            # for reading the data we use the method below
            # we get the next sequence of data: [xx bb .. bb xx bb ..bb xx bb..bb ........]
            # xx - number of bytes corresponding to the upcoming register
            # bb .. bb - the xx bytes of the register which contain the data we need

            # AIM: to separate the [bb..bb] from [xx] and add them in the regsValues buffer that the
            # methos is sending forward

            start_address = 0x1
            byte_count = 232
            # regs_values = np.zeros(self.TOTAL_NUMBER_OF_BYTES)
            regs_values = bytearray()
            if self.mcp2221:
                if refresh_type is not None:
                    result = self.send_refresh(refresh_type, delay)
                    if result != 0:
                        self.last_error = result
                        return None

                result = self.mcp2221.I2C_Write(self.i2c_address, [start_address])
                if result == 0:
                    result = self.mcp2221.I2C_Read(self.i2c_address, byte_count)

                    tx_idx = 0   # used to iterate/go through result
                    reg_idx = 0  # used to iterate/go through regValue - used for adding data (bb data mentioned above)

                    while tx_idx < len(result):
                        no_of_bytes = result[tx_idx]
                        for i in range(0, no_of_bytes):
                            tx_idx += 1
                            if tx_idx < len(result):
                                regs_values.append(result[tx_idx])
                        tx_idx += 1

                    return regs_values
                else:
                    self.last_error = result
                    return None
            else:
                self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
                return None

    def read_channel(self, channel_index, refresh_type=None, delay=0.128):
        """
        Description: Gets the measurements of the channel specified in the input parameters. The measurements consist of
        Vacc, Vbus, Vsense, Current, Vbus Avg, Vsense Avg, Current Avg, Vpower and Energy.A Refresh command will be sent
        to the device before reading the data, if the refresh_type parameter has been added.

        :param channel_index: Selects for which channel to get the data. It takes one of the values: 1, 2, 3, 4.
        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: (dictionary) channel_values: Vacc(W or V), Vbus(V), Vsense(V), Current(mA), Vbus Avg(V), Vsense Avg(V),
                 Current Avg(mA), Vpower(W) and Energy(pWh), if successful;
                 None, otherwise.
        """
        if self.mcp2221:
            if refresh_type is not None:
                result = self.send_refresh(refresh_type, delay)
                if result != 0:
                    self.last_error = result
                    return None

            channel_values = {'vacc': self.get_vacc(channel_index),
                              'vbus': self.get_vbus(channel_index),
                              'vsense': self.get_vsense(channel_index),
                              'current': self.get_current(channel_index),
                              'vbus_avg': self.get_vbus_avg(channel_index),
                              'vsense_avg': self.get_vsense_avg(channel_index),
                              'current_avg': self.get_current_avg(channel_index),
                              'vpower': self.get_vpower(channel_index),
                              'energy': self.get_energy(channel_index)}

            return channel_values
        else:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return None

    def read_measurements(self, refresh_type=None, delay=0.128):
        """
        Description: Gets the measurements for the available channels. The measurements consist of Vacc, Vbus, Vsense,
        Current, Vbus Avg, Vsense Avg, Current Avg, Vpower and Energy for each channel. The unavailable channels will
        contain the 0 value for every measurement. The method uses the registers_values dictionary of the pac194x5x
        class to store the read values. A Refresh command will be sent to the device before reading the data if the
        refresh_type parameter has been added.

        :param refresh_type: Represents the type of refresh which will be sent to the device. The parameter is optional.
                             If it is not set when calling the method, no refresh will be sent to the device. For
                             sending a refresh, select from {0, 1, 2}: pac194x5x.REFRESH, pac194x5x.REFRESH_G,
                             pac194x5x.REFRESH_V
        :param delay: Represents the value of the delay measured in seconds after a refresh. The parameter is optional.
                      The default value is 0.128s, but it can be changed when calling the method.
        :return: (dictionary) channel_values, (dictionary) alerts, timestamp; channel_values consists of Vacc(W or V),
                 Vbus(V), Vsense(V), Current(mA), Vbus Avg(V), Vsense Avg(V), Current Avg(mA), Vpower(W) and Energy(pWh)
                 for each channel; alerts consists of Over Current, Under Current, Over Power, Over Voltage and Under
                 Voltage alerts for each channel; timestamp is the difference between the current timestamp and the
                 previous one; if successful;
                 None, otherwise.
        """
        if self.mcp2221:
            if refresh_type is not None:
                result = self.send_refresh(refresh_type, delay)
                if result != 0:
                    self.last_error = result
                    return None
            result = self.update_registers_values()
            if result is None:
                return None

            channel_values = {'acc_count': self.get_acc_count(use_list=True),
                              'vacc1': self.get_vacc(1, use_list=True),
                              'vbus1': self.get_vbus(1, use_list=True),
                              'vsense1': self.get_vsense(1, use_list=True),
                              'current1': self.get_current(1, use_list=True),
                              'vbus_avg1': self.get_vbus_avg(1, use_list=True),
                              'vsense_avg1': self.get_vsense_avg(1, use_list=True),
                              'current_avg1': self.get_current_avg(1, use_list=True),
                              'vpower1': self.get_vpower(1, use_list=True),
                              'energy1': self.get_energy(1, use_list=True),
                              'vacc2': self.get_vacc(2, use_list=True),
                              'vbus2': self.get_vbus(2, use_list=True),
                              'vsense2': self.get_vsense(2, use_list=True),
                              'current2': self.get_current(2, use_list=True),
                              'vbus_avg2': self.get_vbus_avg(2, use_list=True),
                              'vsense_avg2': self.get_vsense_avg(2, use_list=True),
                              'current_avg2': self.get_current_avg(2, use_list=True),
                              'vpower2': self.get_vpower(2, use_list=True),
                              'energy2': self.get_energy(2, use_list=True),
                              'vacc3': self.get_vacc(3, use_list=True),
                              'vbus3': self.get_vbus(3, use_list=True),
                              'vsense3': self.get_vsense(3, use_list=True),
                              'current3': self.get_current(3, use_list=True),
                              'vbus_avg3': self.get_vbus_avg(3, use_list=True),
                              'vsense_avg3': self.get_vsense_avg(3, use_list=True),
                              'current_avg3': self.get_current_avg(3, use_list=True),
                              'vpower3': self.get_vpower(3, use_list=True),
                              'energy3': self.get_energy(3, use_list=True),
                              'vacc4': self.get_vacc(4, use_list=True),
                              'vbus4': self.get_vbus(4, use_list=True),
                              'vsense4': self.get_vsense(4, use_list=True),
                              'current4': self.get_current(4, use_list=True),
                              'vbus_avg4': self.get_vbus_avg(4, use_list=True),
                              'vsense_avg4': self.get_vsense_avg(4, use_list=True),
                              'current_avg4': self.get_current_avg(4, use_list=True),
                              'vpower4': self.get_vpower(4, use_list=True),
                              'energy4': self.get_energy(4, use_list=True)
                              }
            alerts_ch1 = self.get_channel_alert_status(channel_index=1, use_list=True)
            alerts_ch2 = self.get_channel_alert_status(channel_index=2, use_list=True)
            alerts_ch3 = self.get_channel_alert_status(channel_index=3, use_list=True)
            alerts_ch4 = self.get_channel_alert_status(channel_index=4, use_list=True)
            alerts = {'Ch1_OC_alert': alerts_ch1[0],
                      'Ch1_UC_alert': alerts_ch1[1],
                      'Ch1_OV_alert': alerts_ch1[2],
                      'Ch1_UV_alert': alerts_ch1[3],
                      'Ch1_OP_alert': alerts_ch1[4],
                      'Ch2_OC_alert': alerts_ch2[0],
                      'Ch2_UC_alert': alerts_ch2[1],
                      'Ch2_OV_alert': alerts_ch2[2],
                      'Ch2_UV_alert': alerts_ch2[3],
                      'Ch2_OP_alert': alerts_ch2[4],
                      'Ch3_OC_alert': alerts_ch3[0],
                      'Ch3_UC_alert': alerts_ch3[1],
                      'Ch3_OV_alert': alerts_ch3[2],
                      'Ch3_UV_alert': alerts_ch3[3],
                      'Ch3_OP_alert': alerts_ch3[4],
                      'Ch4_OC_alert': alerts_ch4[0],
                      'Ch4_UC_alert': alerts_ch4[1],
                      'Ch4_OV_alert': alerts_ch4[2],
                      'Ch4_UV_alert': alerts_ch4[3],
                      'Ch4_OP_alert': alerts_ch4[4]
                      }
            time_stamp = self.time_stamp - self.prev_timestamp
            return channel_values, alerts, time_stamp
        else:
            self.last_error = self.ERROR_MCP2221_BRIDGE_MISSING
            return None, None, None

    # Helpful methods

    def get_last_error(self):
        """
        Description: Gets the last error that occurred during the usage of the library. It can be used to find what
        error occurred when a getter method of a register value failed and returned None.

        :return: (int)last_error, the value of the last error that occurred.
        """
        return self.last_error

    def get_array_value(self, value, nr_bytes):
        """
        Description: Converts the given value into an array of bytes. Its main purpose is to divide in bytes the values
        that will be sent to the device via mcp2221.py writing method.

        :param value: Represents the value that will be divided into bytes
        :param nr_bytes: Represents the number of bytes that the given value will be divided into.

        :return: (array of bytes)value which contains the given value divided, if successful;
                 None, if there is no value given to convert.
        """
        if value is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return None

        result = [0] * nr_bytes     # np.empty(nr_bytes)
        for i in range(nr_bytes - 1, -1, -1):
            x = value & 0xff
            result[i] = int(x)
            value = value >> 8
        return result

    def get_bits_value(self, value, no_of_bits, position):
        """
        Description: Returns the value of a specific number of bits from the number that was given in the input
        parameters. For this it is necessary to provide the position of the extreme right bit. The method can be used in
        extract some specific and individual features from a register that contains useful information in a specific
        number of bits.

        :param value: Represents the value from which to extract the value of the bit(s);
        :param no_of_bits: Represents how many bits to extract from the input and it can take one of the values 1, 2, or
                           4 because each individual feature from the registers is composed from one of those exact
                           number of bits.
        :param position: Represents the position of the extreme right bit from the group meant to be extracted.
        :return: (int)bits_value, the value of the extracted bits, if successful;
                 None, otherwise.
        """
        if value is None or position is None:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return None

        if no_of_bits == 1:
            bits = (value >> position) & 0x1
        elif no_of_bits == 2:
            bits = (value >> position) & 0x3
        elif no_of_bits == 4:
            bits = (value >> position) & 0xf
        else:
            self.last_error = self.ERROR_INPUT_PARAMETER
            return None
        return bits
