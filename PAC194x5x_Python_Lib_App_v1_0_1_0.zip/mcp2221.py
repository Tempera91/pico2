# -*- coding: utf-8 -*-
#
# ©[2016] Microchip Technology Inc.and its subsidiaries.You may use this software and any derivatives exclusively with Microchip products.
#
# THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
# WARRANTIES OF NON - INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION WITH ANY 
# OTHER PRODUCTS, OR USE IN ANY APPLICATION.
#
# IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER
# RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.TO THE FULLEST EXTENT ALLOWED
# BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID
# DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
#
# MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE TERMS.

import sys, os, struct, ctypes
from ctypes import *

#get a handle to the DLL
if (ctypes.sizeof(ctypes.c_voidp) == 4):
    #32-bit version of Python - load the 32-bit DLL
    DLL_mcp2221 = windll.LoadLibrary("mcp2221_dll_um_x86.dll");
else:
    DLL_mcp2221 = windll.LoadLibrary("mcp2221_dll_um_x64.dll");
    
class MCP2221:
    def __init__(self, vid = 0x4D8, pid = 0xDD):
        #get a handle to the DLL
        # DLL_mcp2221 = windll.LoadLibrary("mcp2221_dll_um_x64.dll")
        self.bridge_index = 0;
        self.bridge_handle = c_void_p(0);
        self.VID_mcp2221 = c_ushort(vid)
        self.PID_mcp2221 = c_ushort(pid)
        # get the needed DLL function
        self.mcp2221_GetNumBridges = DLL_mcp2221.Mcp2221_GetConnectedDevices
        # tell Python what arguments to expect and what result type
        self.mcp2221_GetNumBridges.argtypes = [c_ushort, c_ushort, POINTER(c_ushort)]
        self.mcp2221_GetNumBridges.restype = c_int
        # void* __stdcall Mcp2221_OpenByIndex(unsigned int VID, unsigned int PID, unsigned int index);
        self.mcp2221_OpenByIndex = DLL_mcp2221.Mcp2221_OpenByIndex;
        # arguments and returned type
        self.mcp2221_OpenByIndex.argtypes = [c_ushort, c_ushort, c_ushort];
        self.mcp2221_OpenByIndex.restype = c_void_p;
        #
        # void* __stdcall Mcp2221_OpenBySN(unsigned int VID, unsigned int PID, wchar_t *serialNo);
        self.mcp2221_OpenBySN = DLL_mcp2221.Mcp2221_OpenBySN;
        # arguments and returned type
        self.mcp2221_OpenBySN.argtypes = [c_ushort, c_ushort, c_wchar_p];
        self.mcp2221_OpenBySN.restype = c_void_p;
        #
        # int __stdcall Mcp2221_GetLibraryVersion(wchar_t *version);
        self.mcp2221_GetLibraryVersion = DLL_mcp2221.Mcp2221_GetLibraryVersion;
        # arguments and returned type
        self.mcp2221_GetLibraryVersion.argtypes = [c_wchar_p];
        self.mcp2221_GetLibraryVersion.restype = c_int
        #
        # int __stdcall Mcp2221_GetManufacturerDescriptor(void* handle, wchar_t* manufacturerString);
        self.mcp2221_GetManufacturerDescriptor = DLL_mcp2221.Mcp2221_GetManufacturerDescriptor;
        # arguments and returned type
        self.mcp2221_GetManufacturerDescriptor.argtypes = [c_void_p, c_wchar_p]
        self.mcp2221_GetManufacturerDescriptor.restype = c_int
        #
        # int __stdcall Mcp2221_GetProductDescriptor(void* handle, wchar_t* productString);
        self.mcp2221_GetProductDescriptor = DLL_mcp2221.Mcp2221_GetProductDescriptor;
        # arguments and returned type
        self.mcp2221_GetProductDescriptor.argtypes = [c_void_p, c_wchar_p]
        self.mcp2221_GetProductDescriptor.restype = c_int
        #
        # int __stdcall Mcp2221_GetSerialNumberDescriptor(void* handle, wchar_t* serialNumber);
        self.mcp2221_GetSerialNumberDescriptor = DLL_mcp2221.Mcp2221_GetSerialNumberDescriptor;
        # arguments and returned type
        self.mcp2221_GetSerialNumberDescriptor.argtypes = [c_void_p, c_wchar_p]
        self.mcp2221_GetSerialNumberDescriptor.restype = c_int
        #
        # int __stdcall Mcp2221_GetFactorySerialNumber(void* handle, wchar_t* serialNumber);
        self.mcp2221_GetFactorySerialNumber = DLL_mcp2221.Mcp2221_GetFactorySerialNumber;
        # arguments and returned type
        self.mcp2221_GetFactorySerialNumber.argtypes = [c_void_p, c_wchar_p]
        self.mcp2221_GetFactorySerialNumber.restype = c_int
        #
        # int __stdcall Mcp2221_GetHwFwRevisions(void* handle, wchar_t* hardwareRevision, wchar_t* firmwareRevision);
        self.mcp2221_GetHwFwRevisions = DLL_mcp2221.Mcp2221_GetHwFwRevisions;
        # arguments and returned type
        self.mcp2221_GetHwFwRevisions.argtypes = [c_void_p, c_wchar_p, c_wchar_p]
        self.mcp2221_GetHwFwRevisions.restype = c_int
        #
        #
        # int __stdcall Mcp2221_Close(void *handle);
        self.mcp2221_Close = DLL_mcp2221.Mcp2221_Close;
        self.mcp2221_Close.argtypes = [c_void_p];
        self.mcp2221_Close.restype = c_int;
        # int __stdcall Mcp2221_I2cCancelCurrentTransfer(void* handle);
        self.mcp2221_I2cCancel = DLL_mcp2221.Mcp2221_I2cCancelCurrentTransfer;
        self.mcp2221_I2cCancel.argtypes = [c_void_p];
        self.mcp2221_I2cCancel.restype = c_int;
        # int __stdcall Mcp2221_SetSpeed(void* handle, unsigned int speed);
        self.mcp2221_SetSpeed = DLL_mcp2221.Mcp2221_SetSpeed;
        self.mcp2221_SetSpeed.argtypes = [c_void_p, c_ushort];
        self.mcp2221_SetSpeed.restype = c_int;
        # int __stdcall Mcp2221_I2cRead(void* handle, unsigned int bytesToRead, unsigned char i2cAddress, unsigned char use7bitAddress, unsigned char* i2cRxData);
        self.mcp2221_I2cRead = DLL_mcp2221.Mcp2221_I2cRead;
        self.mcp2221_I2cRead.argtypes = [c_void_p, c_ushort, c_ubyte, c_ubyte, POINTER(c_ubyte)];
        self.mcp2221_I2cRead.restype = c_int
        # int __stdcall Mcp2221_I2cWrite(void* handle, unsigned int bytesToWrite, unsigned char i2cAddress, unsigned char use7bitAddress, unsigned char* i2cTxData);
        self.mcp2221_I2cWrite = DLL_mcp2221.Mcp2221_I2cWrite;
        self.mcp2221_I2cWrite.argtypes = [c_void_p, c_ushort, c_ubyte, c_ubyte, POINTER(c_ubyte)];
        self.mcp2221_I2cWrite.restype = c_int
        # int __stdcall Mcp2221_I2cRead(void* handle, unsigned int bytesToRead, unsigned char i2cAddress, unsigned char use7bitAddress, unsigned char* i2cRxData);
        self.mcp2221_Smbus_Block_Read = DLL_mcp2221.Mcp2221_SmbusBlockRead;
        self.mcp2221_Smbus_Block_Read.argtypes = [c_void_p, c_ubyte, c_ubyte, c_ubyte, c_ubyte, c_ubyte, POINTER(c_ubyte)];
        self.mcp2221_Smbus_Block_Read.restype = c_int
        # int __stdcall Mcp2221_GetGpioSettings(void* handle, unsigned char whichToGet, unsigned char* pinFunctions, unsigned char* pinDirections, unsigned char* outputValues);
        self.mcp2221_GetGpioSettings = DLL_mcp2221.Mcp2221_GetGpioSettings;
        self.mcp2221_GetGpioSettings.argtypes = [c_void_p, c_ubyte, POINTER(c_ubyte), POINTER(c_ubyte), POINTER(c_ubyte)];
        self.mcp2221_GetGpioSettings.restype = c_int
        # int __stdcall Mcp2221_SetGpioSettings(void* handle, unsigned char whichToSet, unsigned char* pinFunctions, unsigned char* pinDirections, unsigned char* outputValues);
        self.mcp2221_SetGpioSettings = DLL_mcp2221.Mcp2221_SetGpioSettings;
        self.mcp2221_SetGpioSettings.argtypes = [c_void_p, c_ubyte, POINTER(c_ubyte), POINTER(c_ubyte), POINTER(c_ubyte)];
        self.mcp2221_SetGpioSettings.restype = c_int
        # int __stdcall Mcp2221_GetGpioValues(void* handle, unsigned char* gpioValues);
        self.mcp2221_GetGpioValues = DLL_mcp2221.Mcp2221_GetGpioValues;
        self.mcp2221_GetGpioValues.argtypes = [c_void_p, POINTER(c_ubyte)];
        self.mcp2221_GetGpioValues.restype = c_int
        # int __stdcall Mcp2221_SetGpioValues(void* handle, unsigned char* gpioValues);
        self.mcp2221_SetGpioValues = DLL_mcp2221.Mcp2221_SetGpioValues;
        self.mcp2221_SetGpioValues.argtypes = [c_void_p, POINTER(c_ubyte)];
        self.mcp2221_SetGpioValues.restype = c_int
        # int __stdcall Mcp2221_GetGpioDirection(void* handle, unsigned char* gpioDir);
        self.mcp2221_GetGpioDirection = DLL_mcp2221.Mcp2221_GetGpioDirection;
        self.mcp2221_GetGpioDirection.argtypes = [c_void_p, POINTER(c_ubyte)];
        self.mcp2221_GetGpioDirection.restype = c_int
        # int __stdcall Mcp2221_SetGpioDirection(void* handle, unsigned char* gpioDir);
        self.mcp2221_SetGpioDirection = DLL_mcp2221.Mcp2221_SetGpioDirection;
        self.mcp2221_SetGpioDirection.argtypes = [c_void_p, POINTER(c_ubyte)];
        self.mcp2221_SetGpioDirection.restype = c_int
        #call one of the initializer functions
        self.SetParams();
        
    def Open(self, index = 0):
        self.bridge_index = index;
        # see how many devices we have
        self.ret_num_conn_devices = c_ushort();
        ret_code = self.mcp2221_GetNumBridges(self.VID_mcp2221, self.PID_mcp2221, byref(self.ret_num_conn_devices));
        print ("Number of mcp2221 bridges: %d" % self.ret_num_conn_devices.value);
        print ("Opening the bridge index %d" % self.bridge_index);
        if (self.ret_num_conn_devices.value == 0):
            return -1;
        #try to open the device
        self.bridge_handle = self.mcp2221_OpenByIndex(self.VID_mcp2221, self.PID_mcp2221, c_ushort(self.bridge_index));
        if (self.bridge_handle != 0):
            #print ('Got a good device HANDLE');
            return 0;
        else:
            #print ('Invalid HANDLE');
            return -1;
            
    def Close(self):
        # close the bridge handle
        if (self.bridge_handle != 0):
            ret_code = self.mcp2221_Close(self.bridge_handle);
            if (ret_code == 0):
                #print ('Succesfully closed the bridge HANDLE');
                return 0;
            else:
                #print ('Cannot close the bridge HANDLE');
                return -1;
        else:
            return -2;
    def SetParams(self, speed = 100000, addr7Bit = 0):
        #setup the communication params
        self.speed = speed;
        self.addr7Bit = addr7Bit;
        
    def I2C_Read(self, i2cAddress, numBytesToRead):
        #read some I2C data
        if (self.bridge_handle != 0):
            read_data = (c_ubyte * numBytesToRead)();
            ret_code = self.mcp2221_I2cRead(self.bridge_handle, numBytesToRead, i2cAddress, self.addr7Bit, read_data);
            #print ('I2C Read returned: %d' %ret_code);
            if (ret_code == 0):
                #print ('I2C Read successfull');
                #for i in range(0, numBytesToRead):
                    #print read_data[i]
                res_bytearr = bytearray(read_data);
                #for v in res_bytearr:
                #    print (v)
            else:
                res_bytearr = bytearray();
        else:
            res_bytearr = bytearray();
            
        return res_bytearr;
        
    def I2C_Write(self, i2cAddress, dataToWrite):
        #write the I2C data
        if (self.bridge_handle != 0):
            numBytesToWrite = len(dataToWrite);
            #print ('I2C Write numbytes: %d' % numBytesToWrite);
            bytearr_write_data = bytearray(dataToWrite);
            # create a ctype array from a bytearray
            write_data = (c_ubyte * numBytesToWrite)(*(bytearr_write_data));
            #counter = 0;
            #for byte_val in bytearr_write_data:
            #    write_data[counter] = byte_val;
                #print ('Data byte %d' %write_data[counter]);
            #    counter = counter + 1;
            
            ret_code = self.mcp2221_I2cWrite(self.bridge_handle, numBytesToWrite, i2cAddress, self.addr7Bit, write_data);
            return ret_code;
        else:
            return -1;
    
    def Scan_Bus(self, startAddr, endAddr, addr7Bit = 0):
        #scan the I2C bus between the given addresses
        list_devices = [];
        #transform the parameters to 8-bit addresses
        if (addr7Bit != 0):
            #7-bit address range given. Transform it to 8-bit addresses
            #lcl_startAddr = startAddr * 2;
            lcl_startAddr  = startAddr << 1;
            #lcl_endAddr = endAddr * 2;
            lcl_endAddr = endAddr << 1;
        else:
            #8-bit addresses used
            lcl_startAddr = startAddr;
            lcl_endAddr = endAddr;
        
        if (lcl_startAddr < 0) or (lcl_startAddr > 255) or (lcl_endAddr < 0) or (lcl_endAddr > 255) or (lcl_startAddr > lcl_endAddr):
            return list_devices;
        for crt_addr in range(lcl_startAddr, lcl_endAddr):
            #print ('Scan address %d' %crt_addr);
            #if ((crt_addr % 2) == 0):
            if ((crt_addr & 0x1) == 0):
                #write operation
                op_res = self.I2C_Write(crt_addr, []);
                if (op_res == 0):
                    if (addr7Bit != 0):
                        #list_devices.append(crt_addr/2);
                        list_devices.append(crt_addr>>1);
                    else:
                        list_devices.append(crt_addr);
            else:
                #read operation - read at least 1 byte
                op_res = self.I2C_Read(crt_addr, 1);
                if (len(op_res) > 0):
                    if (addr7Bit != 0):
                        #list_devices.append(crt_addr/2);
                        list_devices.append(crt_addr>>1);
                    else:
                        list_devices.append(crt_addr);
        return list_devices;
        
    def GPIO_Input_Set_Function(self, gpioNumber):
        #setup the given GPIO as digital input
        if (gpioNumber < 0) or (gpioNumber > 3):
            return -3;
        #read first the runtime pin assignments (there are 4 GPIOs in total)
        pinFunctions = (c_ubyte * 4)();
        pinDirections = (c_ubyte * 4)();
        outputValues = (c_ubyte * 4)();
        result = self.mcp2221_GetGpioSettings(self.bridge_handle, 1, pinFunctions, pinDirections, outputValues);
        #print ('GetGpioSettings returned: %d' % result );
        if (result != 0):
            return -1;
        #for pinF in pinFunctions:
        #    print ('PinFunc -> %d' % pinF );
        #for pinD in pinDirections:
        #    print ('PinDir -> %d' % pinD );
        #for outV in outputValues:
        #    print ('OutVal -> %d' % outV );
        #now, change the runtime designation for the given pin and make it an input
        pinFunctions[gpioNumber] = 0; #set as GPIO
        pinDirections[gpioNumber] = 1; #set as input
        result = self.mcp2221_SetGpioSettings(self.bridge_handle, 1, pinFunctions, pinDirections, outputValues);
        #print ('SetGpioSettings returned: %d' % result );
        if (result != 0):
            return -1;
        #now read back to confirm the changes
        result = self.mcp2221_GetGpioSettings(self.bridge_handle, 1, pinFunctions, pinDirections, outputValues);
        #print ('GetGpioSettings returned: %d' % result );
        if (result != 0):
            return -1;
        if (pinFunctions[gpioNumber] != 0) or (pinDirections[gpioNumber] != 1):
            return -2;
        #for pinF in pinFunctions:
        #    print ('PinFunc -> %d' % pinF );
        #for pinD in pinDirections:
        #    print ('PinDir -> %d' % pinD );
        #for outV in outputValues:
        #    print ('OutVal -> %d' % outV );
        return 0;
        
    def GPIO_Input_Get_Value(self, gpioNumber):
        #get the value of the given GPIO
        if (gpioNumber < 0) or (gpioNumber > 3):
            return -3;
        gpioValues = (c_ubyte * 4)();
        result = self.mcp2221_GetGpioValues(self.bridge_handle, gpioValues);
        #print ('GetGpioValues returned: %d' % result );
        if (result != 0):
            return -1;
        return gpioValues[gpioNumber];
        
    def GPIO_Output_Set_Funtion(self, gpioNumber, gpioValue):
        #set the given GPIO as output having a given logic value
        if (gpioNumber < 0) or (gpioNumber > 3) or ((gpioValue != 0) and (gpioValue != 1)):
            return -3;
        #read first the runtime pin assignments (there are 4 GPIOs in total)
        pinFunctions = (c_ubyte * 4)();
        pinDirections = (c_ubyte * 4)();
        outputValues = (c_ubyte * 4)();
        result = self.mcp2221_GetGpioSettings(self.bridge_handle, 1, pinFunctions, pinDirections, outputValues);
        #print ('GetGpioSettings returned: %d' % result );
        if (result != 0):
            return -1;
        #for pinF in pinFunctions:
        #    print ('PinFunc -> %d' % pinF );
        #for pinD in pinDirections:
        #    print ('PinDir -> %d' % pinD );
        #for outV in outputValues:
        #    print ('OutVal -> %d' % outV );
        #now, change the runtime designation for the given pin and make it an input
        pinFunctions[gpioNumber] = 0; #set as GPIO
        pinDirections[gpioNumber] = 0; #set as output
        outputValues[gpioNumber] = gpioValue; #set the output value
        result = self.mcp2221_SetGpioSettings(self.bridge_handle, 1, pinFunctions, pinDirections, outputValues);
        #print ('SetGpioSettings returned: %d' % result );
        if (result != 0):
            return -1;
        #now read back to confirm the changes
        result = self.mcp2221_GetGpioSettings(self.bridge_handle, 1, pinFunctions, pinDirections, outputValues);
        #print ('GetGpioSettings returned: %d' % result );
        if (result != 0):
            return -1;
        if (pinFunctions[gpioNumber] != 0) or (pinDirections[gpioNumber] != 0):
            return -2;
        #for pinF in pinFunctions:
        #    print ('PinFunc -> %d' % pinF );
        #for pinD in pinDirections:
        #    print ('PinDir -> %d' % pinD );
        #for outV in outputValues:
        #    print ('OutVal -> %d' % outV );
        return 0;
        
    def GPIO_Output_Set_Value(self, gpioNumber, gpioValue):
        #set the given GPIO value using the provided value
        if (gpioNumber < 0) or (gpioNumber > 3) or ((gpioValue != 0) and (gpioValue != 1)):
            return -3;
        outputValues = (c_ubyte * 4)();
        result = self.mcp2221_GetGpioValues(self.bridge_handle, outputValues);
        if (result != 0):
            return -1;
        #for outV in outputValues:
        #    print ('OutVal -> %d' % outV );   
        for indexPin in range(0,4):
            #print ('OutPin(%d) -> %d' % (indexPin, outputValues[indexPin]) );
            if (outputValues[indexPin] == 0xEE): #pin is not assign as GPIO - set don't care
                outputValues[indexPin] = 0xFF;
        outputValues[gpioNumber] = gpioValue;
        #for outV in outputValues:
        #    print ('OutVal -> %d' % outV );
        result = self.mcp2221_SetGpioValues(self.bridge_handle, outputValues);
        if (result != 0):
            return -1;
        return 0;
        
    def GPIO_Output_Get_Value(self, gpioNumber):
        #return the current value of the GPIO output latch
        if (gpioNumber < 0) or (gpioNumber > 3):
            return -3;
        outputValues = (c_ubyte * 4)();
        result = self.mcp2221_GetGpioValues(self.bridge_handle, outputValues);
        if (result != 0):
            return -1;
        return outputValues[gpioNumber];

    def SMBus_Block_Read(self, i2cAddress, usePec, regAddr, byteCount):
        if (self.bridge_handle != 0):
            read_data = (c_ubyte * byteCount)()
            ret_code = self.mcp2221_Smbus_Block_Read(self.bridge_handle, i2cAddress, self.addr7Bit,
                                                     usePec, regAddr, byteCount, read_data)
            if (ret_code == 0):
                res_bytearr = bytearray(read_data)
            else:
                res_bytearr = bytearray();
        else:
            res_bytearr = bytearray();

        return res_bytearr;
