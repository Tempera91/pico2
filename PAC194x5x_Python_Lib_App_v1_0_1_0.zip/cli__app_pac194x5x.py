# © 2021 Microchip Technology Inc. and its subsidiaries
#
# Subject to your compliance with these terms, you may use Microchip software
# and any derivatives exclusively with Microchip products. You're responsible
# for complying with 3rd party license terms applicable to your use of 3rd party
# software (including open source software) that may accompany Microchip software.
# SOFTWARE IS "AS IS." NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY,
# APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,
# MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP
# BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS,
# DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER
# CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE
# FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY
# ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT EXCEED AMOUNT OF FEES, IF ANY,
# YOU PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

# PAC194x5x Command Line Interface Version 1.0.0

import sys
import os
import struct
import time
from datetime import datetime
import binascii
import msvcrt
import csv
import argparse
import numpy as np
from mcp2221 import *
from pac194x5x import *


display_fmtstrings = {'i2c_addr'       : '{0:15s} (8b) -> {1:#04x}',
                      'acc_count'      : '{0:15s}      -> {1:d}',
                      'vacc1'          : '{0:15s} ( W) -> {1:12.4f}',
                      'vacc2'          : '{0:15s} ( W) -> {1:12.4f}',
                      'vacc3'          : '{0:15s} ( W) -> {1:12.4f}',
                      'vacc4'          : '{0:15s} ( W) -> {1:12.4f}',
                      'vbus1'          : '{0:15s} ( V) -> {1:12.4f}',
                      'vbus2'          : '{0:15s} ( V) -> {1:12.4f}',
                      'vbus3'          : '{0:15s} ( V) -> {1:12.4f}',
                      'vbus4'          : '{0:15s} ( V) -> {1:12.4f}',
                      'vsense1'        : '{0:15s} (mV) -> {1:12.4f}',
                      'vsense2'        : '{0:15s} (mV) -> {1:12.4f}',
                      'vsense3'        : '{0:15s} (mV) -> {1:12.4f}',
                      'vsense4'        : '{0:15s} (mV) -> {1:12.4f}',
                      'current1'       : '{0:15s} (mA) -> {1:12.4f}',
                      'current2'       : '{0:15s} (mA) -> {1:12.4f}',
                      'current3'       : '{0:15s} (mA) -> {1:12.4f}',
                      'current4'       : '{0:15s} (mA) -> {1:12.4f}',
                      'vbus_avg1'      : '{0:15s} ( V) -> {1:12.4f}',
                      'vbus_avg2'      : '{0:15s} ( V) -> {1:12.4f}',
                      'vbus_avg3'      : '{0:15s} ( V) -> {1:12.4f}',
                      'vbus_avg4'      : '{0:15s} ( V) -> {1:12.4f}',
                      'vsense_avg1'    : '{0:15s} (mV) -> {1:12.4f}',
                      'vsense_avg2'    : '{0:15s} (mV) -> {1:12.4f}',
                      'vsense_avg3'    : '{0:15s} (mV) -> {1:12.4f}',
                      'vsense_avg4'    : '{0:15s} (mV) -> {1:12.4f}',
                      'current_avg1'   : '{0:15s} (mA) -> {1:12.4f}',
                      'current_avg2'   : '{0:15s} (mA) -> {1:12.4f}',
                      'current_avg3'   : '{0:15s} (mA) -> {1:12.4f}',
                      'current_avg4'   : '{0:15s} (mA) -> {1:12.4f}',
                      'vpower1'        : '{0:15s} ( W) -> {1:12.4f}',
                      'vpower2'        : '{0:15s} ( W) -> {1:12.4f}',
                      'vpower3'        : '{0:15s} ( W) -> {1:12.4f}',
                      'vpower4'        : '{0:15s} ( W) -> {1:12.4f}',
                      'energy1'        : '{0:14s} (pWh) -> {1:12.4f}',
                      'energy2'        : '{0:14s} (pWh) -> {1:12.4f}',
                      'energy3'        : '{0:14s} (pWh) -> {1:12.4f}',
                      'energy4'        : '{0:14s} (pWh) -> {1:12.4f}',
                      'rsense1'        : '{0:14s} (Ohm) -> {1:12.4f}',
                      'rsense2'        : '{0:14s} (Ohm) -> {1:12.4f}',
                      'rsense3'        : '{0:14s} (Ohm) -> {1:12.4f}',
                      'rsense4'        : '{0:14s} (Ohm) -> {1:12.4f}',
                      'Ch1_OC_alert'   : '{0:15s}      -> {1:s}',
                      'Ch1_UC_alert'   : '{0:15s}      -> {1:s}',
                      'Ch1_OV_alert'   : '{0:15s}      -> {1:s}',
                      'Ch1_UV_alert'   : '{0:15s}      -> {1:s}',
                      'Ch1_OP_alert'   : '{0:15s}      -> {1:s}',
                      'Ch2_OC_alert'   : '{0:15s}      -> {1:s}',
                      'Ch2_UC_alert'   : '{0:15s}      -> {1:s}',
                      'Ch2_OV_alert'   : '{0:15s}      -> {1:s}',
                      'Ch2_UV_alert'   : '{0:15s}      -> {1:s}',
                      'Ch2_OP_alert'   : '{0:15s}      -> {1:s}',
                      'Ch3_OC_alert'   : '{0:15s}      -> {1:s}',
                      'Ch3_UC_alert'   : '{0:15s}      -> {1:s}',
                      'Ch3_OV_alert'   : '{0:15s}      -> {1:s}',
                      'Ch3_UV_alert'   : '{0:15s}      -> {1:s}',
                      'Ch3_OP_alert'   : '{0:15s}      -> {1:s}',
                      'Ch4_OC_alert'   : '{0:15s}      -> {1:s}',
                      'Ch4_UC_alert'   : '{0:15s}      -> {1:s}',
                      'Ch4_OV_alert'   : '{0:15s}      -> {1:s}',
                      'Ch4_UV_alert'   : '{0:15s}      -> {1:s}',
                      'Ch4_OP_alert'   : '{0:15s}      -> {1:s}',
                      'Overflow_Alert' : '{0:15s}      -> {1:s}',
                      'Slow_Transition': '{0:15s}      -> {1:d}',
                      'Any_Alert'      : '{0:15s}      -> {1:s}',
                      'time_stamp'     : '{0:15s} ( s) -> {1:.3f}'}

display_info = {'acc_count',
                'vacc1',
                'vbus1',
                'vsense1',
                'current1',
                'vbus_avg1',
                'vsense_avg1',
                'current_avg1',
                'vpower1',
                'energy1',
                'vacc2',
                'vbus2',
                'vsense2',
                'current2',
                'vbus_avg2',
                'vsense_avg2',
                'current_avg2',
                'vpower2',
                'energy2',
                'vacc3',
                'vbus3',
                'vsense3',
                'current3',
                'vbus_avg3',
                'vsense_avg3',
                'current_avg3',
                'vpower3',
                'energy3',
                'vacc4',
                'vbus4',
                'vsense4',
                'current4',
                'vbus_avg4',
                'vsense_avg4',
                'current_avg4',
                'vpower4',
                'energy4'
                }

display_alerts = {'Ch1_OC_alert',
                  'Ch1_UC_alert',
                  'Ch1_OV_alert',
                  'Ch1_UV_alert',
                  'Ch1_OP_alert',
                  'Ch2_OC_alert',
                  'Ch2_UC_alert',
                  'Ch2_OV_alert',
                  'Ch2_UV_alert',
                  'Ch2_OP_alert',
                  'Ch3_OC_alert',
                  'Ch3_UC_alert',
                  'Ch3_OV_alert',
                  'Ch3_UV_alert',
                  'Ch3_OP_alert',
                  'Ch4_OC_alert',
                  'Ch4_UC_alert',
                  'Ch4_OV_alert',
                  'Ch4_UV_alert',
                  'Ch4_OP_alert'
                  }

csv_log_info = ['timestamp(H:M:S)',
                'acc_count',
                'vacc1',
                'vbus1',
                'vsense1',
                'current1',
                'vbus_avg1',
                'vsense_avg1',
                'current_avg1',
                'vpower1',
                'energy1',
                'vacc2',
                'vbus2',
                'vsense2',
                'current2',
                'vbus_avg2',
                'vsense_avg2',
                'current_avg2',
                'vpower2',
                'energy2',
                'vacc3',
                'vbus3',
                'vsense3',
                'current3',
                'vbus_avg3',
                'vsense_avg3',
                'current_avg3',
                'vpower3',
                'energy3',
                'vacc4',
                'vbus4',
                'vsense4',
                'current4',
                'vbus_avg4',
                'vsense_avg4',
                'current_avg4',
                'vpower4',
                'energy4'
                ]


def display_data(pac194x5x, bridge, refresh_type, refresh_delay, refresh_period,
                 readings_number, log_feature, log_pause, csv_name, display_min, display_avg):
    for i in range(0, readings_number):
        if refresh_type == -1:
            channel_values, alerts, timestamp = pac194x5x.read_measurements()
        else:
            channel_values, alerts, timestamp = pac194x5x.read_measurements(refresh_type=refresh_type,
                                                                            delay=refresh_delay)

        # Get time
        now = datetime.now()
        current_time = now.strftime(" %H:%M:%S.%f")

        if channel_values is not None:
            ch_values = tuple(channel_values.items())
            if display_min is False:
                # Get any alert
                any_alert = pac194x5x.get_smbus()
                any_alert = any_alert >> 5
                any_alert = bool(any_alert & 1)

                # print('\nPAC194x5x Acquisition %d read at%s (h:m:s) \n' % (i + 1, current_time))

                print("ALERTS\n")
                alert_values = tuple(alerts.items())
                for idx in range(0, len(alert_values), 5):
                    ch = (idx / 5) + 1
                    print("CHANNEL %d" % ch)
                    print("{:<10}{:<10}{:<10}{:<10}{:<10}".format("OC", "UC", "OV", "UV", "OP"))
                    print("{:<10}{:<10}{:<10}{:<10}{:<10}".format(str(alert_values[idx][1]),
                                                                  str(alert_values[idx + 1][1]),
                                                                  str(alert_values[idx + 2][1]),
                                                                  str(alert_values[idx + 3][1]),
                                                                  str(alert_values[idx + 4][1])))
                    print("\n")
                print(display_fmtstrings['Overflow_Alert'].format('Overflow_Alert',
                                                                  str(pac194x5x.detect_overflow(use_list=True))))
                print("\n")

                print("\nMEASUREMENTS\n")
                for index in range(0, len(ch_values)):
                    key = ch_values[index][0]
                    value = ch_values[index][1]
                    if index == 0:
                        print(display_fmtstrings[key].format(key, value))
                        print('\n')
                    elif index == 1:
                        print('CHANNEL %d \t\t\t\t     CHANNEL %d' % (1, 2))
                        idx = index + 9
                        key_2 = ch_values[idx][0]
                        value_2 = ch_values[idx][1]
                        print("{:<45}{:<45}".format(display_fmtstrings[key].format(key, value),
                                                    display_fmtstrings[key_2].format(key_2, value_2)))
                    elif index == 19:
                        print('\n')
                        print('CHANNEL %d \t\t\t\t     CHANNEL %d' % (3, 4))
                        idx = index + 9
                        key_2 = ch_values[idx][0]
                        value_2 = ch_values[idx][1]
                        print("{:<45}{:<45}".format(display_fmtstrings[key].format(key, value),
                                                    display_fmtstrings[key_2].format(key_2, value_2)))
                    elif (1 < index) & (index < 10):
                        idx = index + 9
                        key_2 = ch_values[idx][0]
                        value_2 = ch_values[idx][1]
                        print("{:<45}{:<45}".format(display_fmtstrings[key].format(key, value),
                                                    display_fmtstrings[key_2].format(key_2, value_2)))
                        if index == 9:
                            print("{:<45}{:<45}".format(display_fmtstrings['rsense1'].format('rsense1',
                                                                                             pac194x5x.rsense[0]),
                                                        display_fmtstrings['rsense2'].format('rsense2',
                                                                                             pac194x5x.rsense[1])))
                    elif (19 < index) & (index < 28):
                        idx = index + 9
                        key_2 = ch_values[idx][0]
                        value_2 = ch_values[idx][1]
                        print("{:<45}{:<45}".format(display_fmtstrings[key].format(key, value),
                                                    display_fmtstrings[key_2].format(key_2, value_2)))
                        if index == 27:
                            print("{:<45}{:<45}".format(display_fmtstrings['rsense3'].format('rsense3',
                                                                                             pac194x5x.rsense[2]),
                                                        display_fmtstrings['rsense4'].format('rsense4',
                                                                                             pac194x5x.rsense[3])))

                print("\n")
                print(display_fmtstrings['Slow_Transition'].format('Slow_Transition',
                                                                   pac194x5x.detect_slow_transition(use_list=True)))
                print(display_fmtstrings['Any_Alert'].format('Any_Alert', str(any_alert)))
            else:
                if display_avg is False:
                    ch_values_str = [str("{:4.3f}".format(ch_values[2][1])) + "V",
                                     str("{:4.3f}".format(ch_values[3][1])) + "mV",
                                     str("{:4.3f}".format(ch_values[8][1])) + "W", "#",
                                     str("{:4.3f}".format(ch_values[11][1])) + "V",
                                     str("{:4.3f}".format(ch_values[12][1])) + "mV",
                                     str("{:4.3f}".format(ch_values[17][1])) + "W", "#",
                                     str("{:4.3f}".format(ch_values[20][1])) + "V",
                                     str("{:4.3f}".format(ch_values[21][1])) + "mV",
                                     str("{:4.3f}".format(ch_values[26][1])) + "W", "#",
                                     str("{:4.3f}".format(ch_values[29][1])) + "V",
                                     str("{:4.3f}".format(ch_values[30][1])) + "mV",
                                     str("{:4.3f}".format(ch_values[35][1])) + "W"]
                    
                    print("{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}".format(
                        ch_values_str[0], ch_values_str[1], ch_values_str[2], ch_values_str[3], ch_values_str[4],
                        ch_values_str[5], ch_values_str[6], ch_values_str[7], ch_values_str[8], ch_values_str[9],
                        ch_values_str[10], ch_values_str[11], ch_values_str[12], ch_values_str[13], ch_values_str[14]))
                else:
                    ch_values_str = [str("{:4.3f}".format(ch_values[5][1])) + "V",
                                     str("{:4.3f}".format(ch_values[6][1])) + "mV",
                                     str("{:4.3f}".format(ch_values[8][1])) + "W", "#",
                                     str("{:4.3f}".format(ch_values[14][1])) + "V",
                                     str("{:4.3f}".format(ch_values[15][1])) + "mV",
                                     str("{:4.3f}".format(ch_values[17][1])) + "W", "#",
                                     str("{:4.3f}".format(ch_values[23][1])) + "V",
                                     str("{:4.3f}".format(ch_values[24][1])) + "mV",
                                     str("{:4.3f}".format(ch_values[26][1])) + "W", "#",
                                     str("{:4.3f}".format(ch_values[32][1])) + "V",
                                     str("{:4.3f}".format(ch_values[33][1])) + "mV",
                                     str("{:4.3f}".format(ch_values[35][1])) + "W"]

                    print("{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}".format(
                            ch_values_str[0], ch_values_str[1], ch_values_str[2], ch_values_str[3], ch_values_str[4],
                            ch_values_str[5], ch_values_str[6], ch_values_str[7], ch_values_str[8], ch_values_str[9],
                            ch_values_str[10], ch_values_str[11], ch_values_str[12], ch_values_str[13],
                            ch_values_str[14]))

            # record the data in .csv file
            if log_feature is True:
                if log_pause == 0:
                    with open(csv_name, 'a', newline='\n') as csvfile:
                        csv_writer = csv.DictWriter(csvfile, fieldnames=csv_log_info, extrasaction='ignore',
                                                    dialect='excel')
                        channel_values['timestamp(H:M:S)'] = current_time
                        csv_writer.writerow(channel_values)
            if display_min is False:
                print('\n\n')
        else:
            print('Cannot get access to the bridge (e.g. other application might use it) ... exit')
            result = bridge.Close()
            exit()

        if refresh_period != 0:
            time.sleep(refresh_period)


def display_regs(target_pac194x5x):
    print("{:<20}{:<20}".format('Control', str(hex(target_pac194x5x.get_control()))))
    print("{:<20}{:<20}".format('SMBus', str(hex(target_pac194x5x.get_smbus()))))
    print("{:<20}{:<20}".format('Neg_Pwr_Fsr', str(hex(target_pac194x5x.get_neg_pwr_fsr()))))
    print("{:<20}{:<20}".format('Slow', str(hex(target_pac194x5x.get_slow()))))
    print("{:<20}{:<20}".format('Control Act', str(hex(target_pac194x5x.get_control_act()))))
    print("{:<20}{:<20}".format('Neg_Pwr_Fsr Act', str(hex(target_pac194x5x.get_neg_pwr_fsr_act()))))
    print("{:<20}{:<20}".format('Control Lat', str(hex(target_pac194x5x.get_control_lat()))))
    print("{:<20}{:<20}".format('Neg_Pwr_Fsr Lat', str(hex(target_pac194x5x.get_neg_pwr_fsr_lat()))))
    print("{:<20}{:<20}".format('Accum Config', str(hex(target_pac194x5x.get_accum_config()))))
    print("{:<20}{:<20}".format('Alert Status', str(hex(target_pac194x5x.get_alert_status()))))
    print("{:<20}{:<20}".format('SLOW Alert1', str(hex(target_pac194x5x.get_slow_alert1()))))
    print("{:<20}{:<20}".format('GPIO Alert2', str(hex(target_pac194x5x.get_gpio_alert2()))))
    print("{:<20}{:<20}".format('ACC Fullness', str(hex(target_pac194x5x.get_acc_fullness_limits()))))
    print("{:<20}{:<20}".format('OC limit ch1', str(target_pac194x5x.get_oc_limit(channel_index=1))))
    print("{:<20}{:<20}".format('OC limit ch2', str(target_pac194x5x.get_oc_limit(channel_index=2))))
    print("{:<20}{:<20}".format('OC limit ch3', str(target_pac194x5x.get_oc_limit(channel_index=3))))
    print("{:<20}{:<20}".format('OC limit ch4', str(target_pac194x5x.get_oc_limit(channel_index=4))))
    print("{:<20}{:<20}".format('UC limit ch1', str(target_pac194x5x.get_uc_limit(channel_index=1))))
    print("{:<20}{:<20}".format('UC limit ch2', str(target_pac194x5x.get_uc_limit(channel_index=2))))
    print("{:<20}{:<20}".format('UC limit ch3', str(target_pac194x5x.get_uc_limit(channel_index=3))))
    print("{:<20}{:<20}".format('UC limit ch4', str(target_pac194x5x.get_uc_limit(channel_index=4))))
    print("{:<20}{:<20}".format('OP limit ch1', str(target_pac194x5x.get_op_limit(channel_index=1))))
    print("{:<20}{:<20}".format('OP limit ch2', str(target_pac194x5x.get_op_limit(channel_index=2))))
    print("{:<20}{:<20}".format('OP limit ch3', str(target_pac194x5x.get_op_limit(channel_index=3))))
    print("{:<20}{:<20}".format('OP limit ch4', str(target_pac194x5x.get_op_limit(channel_index=4))))
    print("{:<20}{:<20}".format('OV limit ch1', str(target_pac194x5x.get_ov_limit(channel_index=1))))
    print("{:<20}{:<20}".format('OV limit ch2', str(target_pac194x5x.get_ov_limit(channel_index=2))))
    print("{:<20}{:<20}".format('OV limit ch3', str(target_pac194x5x.get_ov_limit(channel_index=3))))
    print("{:<20}{:<20}".format('OV limit ch4', str(target_pac194x5x.get_ov_limit(channel_index=4))))
    print("{:<20}{:<20}".format('UV limit ch1', str(target_pac194x5x.get_uv_limit(channel_index=1))))
    print("{:<20}{:<20}".format('UV limit ch2', str(target_pac194x5x.get_uv_limit(channel_index=2))))
    print("{:<20}{:<20}".format('UV limit ch3', str(target_pac194x5x.get_uv_limit(channel_index=3))))
    print("{:<20}{:<20}".format('UV limit ch4', str(target_pac194x5x.get_uv_limit(channel_index=4))))
    print("{:<20}{:<20}".format('OC limit nsamples', str(hex(target_pac194x5x.get_oc_limit_nsamples()))))
    print("{:<20}{:<20}".format('UC limit nsamples', str(hex(target_pac194x5x.get_uc_limit_nsamples()))))
    print("{:<20}{:<20}".format('OP limit nsamples', str(hex(target_pac194x5x.get_op_limit_nsamples()))))
    print("{:<20}{:<20}".format('OV limit nsamples', str(hex(target_pac194x5x.get_ov_limit_nsamples()))))
    print("{:<20}{:<20}".format('UV limit nsamples', str(hex(target_pac194x5x.get_uc_limit_nsamples()))))
    print("{:<20}{:<20}".format('Alert Enable', str(hex(target_pac194x5x.get_alert_enable()))))
    print("{:<20}{:<20}".format('Accum Config Act', str(hex(target_pac194x5x.get_accum_config_act()))))
    print("{:<20}{:<20}".format('Accum Config Lat', str(hex(target_pac194x5x.get_accum_config_lat()))))


def main():
    # define the cmdline arguments
    cmd_parser = argparse.ArgumentParser(description="PAC194x5x monitor")
    cmd_parser.add_argument("-v", "--version", action='version',
                            version='version 1.0',
                            help="Application version.")

    cmd_parser.add_argument("-ip", "--identify_part", type=int, default=0, choices=[0, 1],
                            help="Select 1 if you want to display the identity of the part at the beginning of the \
                            session.")

    cmd_parser.add_argument("-am", "--app_mode", type=int, default=0, choices=[0, 1],
                            help="Select 1 if you want to use the script in the application mode.")

    cmd_parser.add_argument("-rr", "--read_regs", type=int, default=0, choices=[0, 1],
                            help="Select 1 if you want to read the registers only.")

    cmd_parser.add_argument("-rn", "--readings_number", default="1",
                            help="Select how many readings from the chip will be performed. For continuous reading \
                            type 'c' or 'C' after the command.")

    # cmd_parser.add_argument("-cr", "--cont_reading", type=int, default=0, choices=[0, 1],
    #                         help="Select 1 for continuous data acquisition. To exit the acquisition, press X.")

    display_group = cmd_parser.add_argument_group('--display_option')
    display_group.add_argument("-dm", '--display_minimal', type=int, default=0, choices=[0, 1],
                               help='Select 0 for displaying all measurements or 1 for displaying only Accum, VBus and\
                               VSense.')
    display_group.add_argument("-av", '--avg_values', type=int, default=0, choices=[0, 1],
                               help='Select 0 for displaying real values or 1 for displaying average values.')

    cmd_parser.add_argument("-cfg", "--config",
                            help="Configuration filename (.csv format). \".csv\" suffix is appended automatically.\
                            Append a configuration file for the chip settings. The empty fields will be ignored \
                            and the corresponding register(s) will not be written.")

    cmd_parser.add_argument("-ln", "--log_name",
                            help="Set log filename. If not provided, the logging feature is disabled. \".csv\" suffix\
                            appended automatically.")

    cmd_parser.add_argument("-rp", "--refresh_period", type=float, default=0.5,
                            help="Set the delay in seconds between two acquisitions. The default is 0.5s")

    cmd_parser.add_argument("-a", "--address", default="0x20",
                            help="Select the 8-bit i2c hexadecimal address of the PAC194x5x \
                            device printed on the screen. The default is \"0x20\".")

    cmd_parser.add_argument("-vr", "--voltage_ratio",
                            help="Set the voltage ratio for each channel separated by comma. These will determine the\
                            parameters used for scaling the necessary measurements by multiplication.(param = 1 / ratio)\
                            If '#' is added for a channel, the ratio value will not be changed")

    cmd_parser.add_argument("-rs", "--rsense",
                            help="Set the Rsense values (Ohms) for each channel separated by comma. If '#' is added for\
                            a channel, the rsense value for that channel will not be changed.")

    cmd_parser.add_argument("--refresh_type", type=int, default=0, choices=[0, 1, 2],
                            help="Set the type of the refresh that will be applied: 0 - for refresh, \
                            1 - for refresh_g, 2 - for refresh_v.")

    # cmd_parser.add_argument("--ref_delay", type=float, default=0.128,
    #                         help="Set how many seconds to wait after a refresh has been sent.")

    cmd_parser.add_argument("--ctrl", help="Write the input hex value into CTRL register.")

    cmd_parser.add_argument("--sample_mode", type=int, choices=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 15],
                            help="Set sample mode according to the options presented: 0 - 1024sps, adaptive accum; \
                            1 - 256sps, adaptive accum; 2 - 64sps, adaptive accum; 3 - 8sps, adaptive accum;  \
                            4 - 1024sps; 5 - 256sps; 6 - 64sps; 7 - 8sps; 8 - single shot; 9 - single shot 8x; \
                            10 - fast mode; 11 - burst mode; 15 - sleep mode.")

    cmd_parser.add_argument("--ch_disable", type=int, choices=[1, 2, 3, 4], help="Disable the mentioned channel.")

    cmd_parser.add_argument("--ch_enable", type=int, help="Enable the mentioned channel.")

    cmd_parser.add_argument("--ch_enable_all", type=int, choices=[0, 1], help="Enable all the channels by typing True.")

    cmd_parser.add_argument("--smbus", help="Write the input hex value into SMBUS register.")

    cmd_parser.add_argument("--neg_pwr_fsr", help="Write the input hex value into the NEG_PWR_FSR register.")

    cmd_parser.add_argument("--slow", help="Write the input hex value into the SLOW register.")

    cmd_parser.add_argument("--acc_config", help="Write the input hex value into the Accum Config register.")

    cmd_parser.add_argument("--alert1", help="Write the input hex value into the SLOW_ALERT1 register.")

    cmd_parser.add_argument("--alert2", help="Write the input hex value into the GPIO_ALERT2 register.")

    cmd_parser.add_argument("--acc_lim",
                            help="Write the input hex value into the ACC Fullness Limits register.")

    cmd_parser.add_argument("--oc_limit",
                            help="Set the OC limit values in mA for each channel separated by comma. If '#' is added \
                            for a channel, the limit value for that channel will not be changed. \
                            (e.g. --oc_limit 5.1,10.7,15.7,19.7)")

    cmd_parser.add_argument("--uc_limit",
                            help="Set the UC limit values in mA for each channel separated by comma. If '#' is added \
                            for a channel, the limit value for that channel will not be changed.\
                            (e.g. --uc_limit 5.1,10.7,15.7,19.7)")

    cmd_parser.add_argument("--op_limit",
                            help="Set the OP limit values in W for each channel separated by comma. If '#' is added \
                            for a channel, the limit value for that channel will not be changed.\
                            (e.g. --op_limit 0.0171,0.03,0.035,0.037)")

    cmd_parser.add_argument("--ov_limit",
                            help="Set the OV limit values in V for each channel separated by comma. If '#' is added \
                            for a channel, the limit value for that channel will not be changed.\
                            (e.g. --ov_limit 3.28,2.8,2.45,1.9)")

    cmd_parser.add_argument("--uv_limit",
                            help="Set the UV limit values in V for each channel separated by comma. If '#' is added \
                            for a channel, the limit value for that channel will not be changed.\
                            (e.g. --uv_limit 3.28,2.8,2.45,1.9)")

    cmd_parser.add_argument("--oc_limit_nsamples",
                            help="Write the input hex value into the OC Limit Nsamples register.")

    cmd_parser.add_argument("--uc_limit_nsamples",
                            help="Write the input hex value into the UC Limit Nsamples register.")

    cmd_parser.add_argument("--op_limit_nsamples",
                            help="Write the input hex value into the OP Limit Nsamples register.")

    cmd_parser.add_argument("--ov_limit_nsamples",
                            help="Write the input hex value into the OV Limit Nsamples register.")

    cmd_parser.add_argument("--uv_limit_nsamples",
                            help="Write the input hex value into the UV Limit Nsamples register.")

    cmd_parser.add_argument("--alert_en",
                            help="Write the input hex value into the ALERT ENABLE register.")

    cmd_parser.add_argument("-s", "--scan", type=int, choices=[0, 1],
                            help="Scans the I2C bus, lists the devices found and exits the application. \
                            Input 0 for 8-bit address and 1 for 7-bit address")

    # parse and validate the cmdline arguments
    args = cmd_parser.parse_args()

    if args.scan is not None:
        print("Scanning the I2C bus for devices....")
        # create an instance of the MCP2221 class
        bridge = MCP2221()
        result = bridge.Open()
        if result == -1:
            print('Cannot get access to the bridge (e.g. other application might use it) ... exit')
            result = bridge.Close()
            exit()
        if args.scan == 0:
            # scan all the 8bit addresses
            devices_found = bridge.Scan_Bus(0, 0xFF, 0)
            print("Found the I2C clients - 8-bit addresses:")
        else:
            # scan all the 7bit addresses
            devices_found = bridge.Scan_Bus(0, 0x7F, 1)
            print("Found the I2C clients - 7-bit addresses:")
        for i2c_addr in devices_found:
            print("%#x" % i2c_addr)
        result = bridge.Close()
        exit()

    app_mode = bool(args.app_mode)
    identify_part = bool(args.identify_part)
    read_regs = bool(args.read_regs)

    i2c_addr = int(args.address, 16)
    if i2c_addr > 0xff:
        print("Invalid I2C address input (-a): %#x" % i2c_addr)
        exit()

    if args.config is not None:
        # config from file
        cfg_feature = True
        cfg_name = args.config + ".csv"
    else:
        cfg_feature = False
        cfg_name = ""

    if args.log_name is not None:
        # logging is enabled
        log_feature = True
        # logging is not paused
        log_pause = 0
        csv_name = args.log_name + ".csv"
    else:
        log_feature = False
        # logging is paused
        log_pause = 1
        csv_name = ""

    # readings_number = args.readings_number
    # if readings_number < 0:
    #     print("Invalid readings numver input (-readings_number): %f" % readings_number)
    #     exit()

    if (args.readings_number == 'c') | (args.readings_number == 'C'):
        cont_reading = True
    else:
        value = int(args.readings_number)
        if value < 0:
            print("Invalid readings number (--readings_number): %f" % value)
            exit()
        readings_number = value
        cont_reading = False

    refresh_period = args.refresh_period
    if refresh_period < 0:
        print("Invalid refresh period input (-p): %f" % refresh_period)
        exit()

    # cont_reading = bool(args.cont_reading)

    display_minimal = bool(args.display_minimal)
    avg_values = bool(args.avg_values)

    refresh_type = args.refresh_type
    if (refresh_type < 0) | (refresh_type > 2):
        print("Invalid refresh type input (--refresh_type): %f" % refresh_type)
        exit()

    refresh_delay = 0.128
    if refresh_delay < 0:
        print("Invalid refresh delay input (--ref_delay): %f" % refresh_delay)
        exit()

    # create an instance of the MCP2221 class
    bridge = MCP2221()
    result = bridge.Open()
    print('Open bridge result: %d' % result)
    if result == -1:
        print('Cannot get access to the bridge (e.g. other application might use it) ... exit')
        result = bridge.Close()
        exit()

    # create a list of PAC194x5x class instances
    pac194x5x_list = []
    if cfg_feature is False:
        # create an instance of the PAC194x5x class
        # use 8bit I2C addres
        voltage_ratio = np.ones(4)
        if args.voltage_ratio is not None:
            vratio = args.voltage_ratio.split(',')
            for i in range(0, 4):
                ch = i + 1
                if vratio[i] != '#':
                    voltage_ratio[i] = float(vratio[i])

        pac194x5x = PAC194x5x(i2c_address=i2c_addr, mcp2221_i2c_bridge=bridge, voltage_ratio1=voltage_ratio[0],
                              voltage_ratio2=voltage_ratio[1], voltage_ratio3=voltage_ratio[2],
                              voltage_ratio4=voltage_ratio[3])
        pac194x5x_list.append(pac194x5x)

        # validate and set arguments
        if args.rsense is not None:
            rsense = args.rsense.split(',')
            file = open("sense_resistors.txt", "w")
            for i in range(0, 4):
                ch = i + 1
                if rsense[i] != '#':
                    value = float(rsense[i])
                    if value <= 0:
                        print("Invalid Rsense value for CH%d (-rsense): %f" % (ch, value))
                        exit()
                    pac194x5x.set_rsense(value=value, channel_index=ch)
                    file.write(str(rsense[i]) + '\n')
                else:
                    file.write(str(pac194x5x.rsense[i]) + '\n')
            file.close()
        else:
            if os.stat("sense_resistors.txt").st_size != 0:
                file = open("sense_resistors.txt", "r")
                for i in range(0, 4):
                    value = file.readline()
                    value = float(value)
                    pac194x5x.set_rsense(value=value, channel_index=i+1)
                file.close()

        if args.ctrl is not None:
            ctrl_input = int(args.ctrl, 16)
            if ctrl_input > 0xffff:
                print("Invalid value input for CTRL register change (--ctrl): %#x" % ctrl_input)
                exit()
            else:
                result = pac194x5x.set_control(ctrl_value=ctrl_input)
                if result != 0:
                    print('Could not set Control register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()

        if args.sample_mode is not None:
            sample_mode = args.sample_mode
            if ((0 <= sample_mode) & (sample_mode <= 11)) | (sample_mode == 15):
                result = pac194x5x.set_sample_mode(sample_mode=sample_mode)
                if result != 0:
                    print('Could not set Control register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()
            else:
                print("Invalid value input for Sample mode change (--sample_mode): %#x" % sample_mode)
                exit()

        if args.ch_disable is not None:
            ch_dis = args.ch_disable
            if (ch_dis < 1) | (4 < ch_dis):
                print("Invalid value input for channel index change (--ch_disable): %#x" % ch_dis)
                exit()
            else:
                result = pac194x5x.disable_channel(channel_index=ch_dis, disable=True)
                if result != 0:
                    print('Could not set Control register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()

        if args.ch_enable is not None:
            ch_en = args.ch_enable
            if (ch_en < 1) | (4 < ch_en):
                print("Invalid value input for channel index change (--ch_enable): %#x" % ch_en)
                exit()
            else:
                result = pac194x5x.disable_channel(channel_index=ch_en, disable=False)
                if result != 0:
                    print('Could not set Control register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()

        if args.ch_enable_all is not None:
            enable = args.ch_enable_all
            if enable is True:
                result = pac194x5x.disable_channel(channel_index=1, disable=False)
                result = pac194x5x.disable_channel(channel_index=2, disable=False)
                result = pac194x5x.disable_channel(channel_index=3, disable=False)
                result = pac194x5x.disable_channel(channel_index=4, disable=False)
                if result != 0:
                    print('Could not set Control register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()

        if args.smbus is not None:
            smbus_input = int(args.smbus, 16)
            if smbus_input > 0xff:
                print("Invalid value input for Smbus register change (--smbus): %#x" % smbus_input)
                exit()
            else:
                result = pac194x5x.set_smbus(smbus_value=smbus_input)
                if result != 0:
                    print('Could not set Smbus register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()

        if args.neg_pwr_fsr is not None:
            neg_fsr_input = int(args.neg_pwr_fsr, 16)
            if neg_fsr_input > 0xffff:
                print("Invalid value input for Neg_Pwr_Fsr register change (--neg_pwr_fsr): %#x" % neg_fsr_input)
                exit()
            else:
                result = pac194x5x.set_neg_pwr_fsr(fsr_value=neg_fsr_input)
                if result != 0:
                    print('Could not set Neg_Pwr_Fsr register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()

        if args.slow is not None:
            slow_input = int(args.slow, 16)
            if slow_input > 0xff:
                print("Invalid value input for Slow register change (--slow): %#x" % slow_input)
                exit()
            else:
                result = pac194x5x.set_slow(slow_value=slow_input)
                if result != 0:
                    print('Could not set Slow register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()

        if args.acc_config is not None:
            acc_input = int(args.acc_config, 16)
            if acc_input > 0xff:
                print("Invalid value input for Accum Config register change (--acc_config): %#x" % acc_input)
                exit()
            else:
                result = pac194x5x.set_accum_config(accum_value=acc_input)
                if result != 0:
                    print('Could not set Accum Config register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()

        if args.alert1 is not None:
            alert1_input = int(args.alert1, 16)
            if alert1_input > 0xffffff:
                print("Invalid value input for Slow Alert1 register change (--alert1): %#x" % alert1_input)
                exit()
            else:
                result = pac194x5x.set_slow_alert1(slow_value=alert1_input)
                if result != 0:
                    print('Could not set Slow Alert1 register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()

        if args.alert2 is not None:
            alert2_input = int(args.alert2, 16)
            if alert2_input > 0xffffff:
                print("Invalid value input for Slow Alert2 register change (--alert2): %#x" % alert2_input)
                exit()
            else:
                result = pac194x5x.set_gpio_alert2(gpio_value=alert2_input)
                if result != 0:
                    print('Could not set Slow Alert2 register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()

        if args.acc_lim is not None:
            acc_input = int(args.acc_lim, 16)
            if acc_input > 0xffff:
                print("Invalid value input for Acc Fullness Limits register change (--acc_lim): %#x" % acc_input)
                exit()
            else:
                result = pac194x5x.set_acc_fullness_limits(limits_value=acc_input)
                if result != 0:
                    print('Could not set Acc Fullness Limits register. '
                          'Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()

        if args.oc_limit is not None:
            limit = args.oc_limit.split(',')
            for i in range(0, 4):
                ch = i + 1
                if limit[i] != '#':
                    value = float(limit[i])
                    result = pac194x5x.set_oc_limit(oc_value=value, channel_index=ch)
                    if result != 0:
                        print('Could not set OC Limit register for CH%d. Error code: %d. Exit.'
                              % (ch, result))
                        result = bridge.Close()
                        exit()

        if args.uc_limit is not None:
            limit = args.uc_limit.split(',')
            for i in range(0, 4):
                ch = i + 1
                if limit[i] != '#':
                    value = float(limit[i])
                    result = pac194x5x.set_uc_limit(uc_value=value, channel_index=ch)
                    if result != 0:
                        print('Could not set UC Limit register for CH%d. Error code: %d. Exit.'
                              % (ch, pac194x5x.get_last_error()))
                        result = bridge.Close()
                        exit()

        if args.op_limit is not None:
            limit = args.op_limit.split(',')
            for i in range(0, 4):
                ch = i + 1
                if limit[i] != '#':
                    value = float(limit[i])
                    result = pac194x5x.set_op_limit(op_value=value, channel_index=ch)
                    if result != 0:
                        print('Could not set OP Limit register for CH%d. Error code: %d. Exit.'
                              % (ch, pac194x5x.get_last_error()))
                        result = bridge.Close()
                        exit()

        if args.ov_limit is not None:
            limit = args.ov_limit.split(',')
            for i in range(0, 4):
                ch = i + 1
                if limit[i] != '#':
                    value = float(limit[i])
                    result = pac194x5x.set_ov_limit(ov_value=value, channel_index=ch)
                    if result != 0:
                        print('Could not set OV Limit register for CH%d. Error code: %d. Exit.'
                              % (ch, pac194x5x.get_last_error()))
                        result = bridge.Close()
                        exit()

        if args.uv_limit is not None:
            limit = args.uv_limit.split(',')
            for i in range(0, 4):
                ch = i + 1
                if limit[i] != '#':
                    value = float(limit[i])
                    result = pac194x5x.set_uv_limit(uv_value=value, channel_index=ch)
                    if result != 0:
                        print('Could not set UV Limit register for CH%d. Error code: %d. Exit.'
                              % (ch, pac194x5x.get_last_error()))
                        result = bridge.Close()
                        exit()

        if args.oc_limit_nsamples is not None:
            oc_nsamp_input = int(args.oc_limit_nsamples, 16)
            if oc_nsamp_input > 0xff:
                print("Invalid value input for OC Limit Nsamples register \
                      change (--oc_limit_nsamples): %#x" % oc_nsamp_input)
                exit()
            else:
                result = pac194x5x.set_oc_limit_nsamples(nsamples_value=oc_nsamp_input)
                if result != 0:
                    print('Could not set OC Limit Nsamples register.Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()

        if args.uc_limit_nsamples is not None:
            uc_nsamp_input = int(args.uc_limit_nsamples, 16)
            if uc_nsamp_input > 0xff:
                print("Invalid value input for UC Limit Nsamples register \
                      change (--uc_limit_nsamples): %#x" % uc_nsamp_input)
                exit()
            else:
                result = pac194x5x.set_uc_limit_nsamples(nsamples_value=uc_nsamp_input)
                if result != 0:
                    print('Could not set UC Limit Nsamples register.Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()

        if args.op_limit_nsamples is not None:
            op_nsamp_input = int(args.op_limit_nsamples, 16)
            if op_nsamp_input > 0xff:
                print("Invalid value input for OP Limit Nsamples register \
                      change (--op_limit_nsamples): %#x" % op_nsamp_input)
                exit()
            else:
                result = pac194x5x.set_op_limit_nsamples(nsamples_value=op_nsamp_input)
                if result != 0:
                    print('Could not set OP Limit Nsamples register.Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()

        if args.ov_limit_nsamples is not None:
            ov_nsamp_input = int(args.ov_limit_nsamples, 16)
            if ov_nsamp_input > 0xff:
                print("Invalid value input for OV Limit Nsamples register \
                      change (--ov_limit_nsamples): %#x" % ov_nsamp_input)
                exit()
            else:
                result = pac194x5x.set_ov_limit_nsamples(nsamples_value=ov_nsamp_input)
                if result != 0:
                    print('Could not set OV Limit Nsamples register.Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()

        if args.uv_limit_nsamples is not None:
            uv_nsamp_input = int(args.uv_limit_nsamples, 16)
            if uv_nsamp_input > 0xff:
                print("Invalid value input for UV Limit Nsamples register \
                      change (--uv_limit_nsamples): %#x" % uv_nsamp_input)
                exit()
            else:
                result = pac194x5x.set_uv_limit_nsamples(nsamples_value=uv_nsamp_input)
                if result != 0:
                    print('Could not set UV Limit Nsamples register.Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()

        if args.alert_en is not None:
            alert_en_input = int(args.alert_en, 16)
            if alert_en_input > 0xffffff:
                print("Invalid value input for Alert Enable register \
                      change (--alert_en): %#x" % alert_en_input)
                exit()
            else:
                result = pac194x5x.set_alert_enable(alert_value=alert_en_input)
                if result != 0:
                    print('Could not set Alert Enable register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                    result = bridge.Close()
                    exit()
    else:
        # open the config file and create a dictionary from it
        with open(cfg_name, 'r', newline='\n') as cfgfile:
            cfg_reader = csv.DictReader(cfgfile)
            for row in cfg_reader:
                # print(row)
                if ((row['i2c_addr'] == '') or (row['rsense1'] == '') or (row['rsense2'] == '') or
                        (row['rsense3'] == '') or (row['rsense4'] == '')):
                    # i2c_addr, rsense and voltage coefficient values are mandatory
                    print("Config file enty error ... skip this device")
                    continue
                cfg_i2c_addr = int(row['i2c_addr'], 16)
                cfg_rsense1 = float(row['rsense1'])
                cfg_rsense2 = float(row['rsense2'])
                cfg_rsense3 = float(row['rsense3'])
                cfg_rsense4 = float(row['rsense4'])
                cfg_voltage_ratio1 = float(row['voltage_ratio1'])
                cfg_voltage_ratio2 = float(row['voltage_ratio2'])
                cfg_voltage_ratio3 = float(row['voltage_ratio3'])
                cfg_voltage_ratio4 = float(row['voltage_ratio4'])
                pac194x5x = PAC194x5x(i2c_address=cfg_i2c_addr, mcp2221_i2c_bridge=bridge, rsense1=cfg_rsense1,
                                      rsense2=cfg_rsense2, rsense3=cfg_rsense3, rsense4=cfg_rsense4,
                                      voltage_ratio1=cfg_voltage_ratio1, voltage_ratio2=cfg_voltage_ratio2,
                                      voltage_ratio3=cfg_voltage_ratio3, voltage_ratio4=cfg_voltage_ratio4)

                if row['ctrl'] != '':
                    cfg_ctrl = int(row['ctrl'], 16)
                    result = pac194x5x.set_control(ctrl_value=cfg_ctrl)
                    if result != 0:
                        print('Could not set Control register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['sample_mode'] != '':
                    cfg_smode = int(row['sample_mode'])
                    result = pac194x5x.set_sample_mode(sample_mode=cfg_smode)
                    if result != 0:
                        print('Could not set Control register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['ch_dis'] != '':
                    cfg_ch_dis = int(row['ch_dis'])
                    result = pac194x5x.disable_channel(channel_index=cfg_ch_dis, disable=True)
                    if result != 0:
                        print('Could not set Control register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['ch_en'] != '':
                    cfg_ch_en = int(row['ch_en'])
                    result = pac194x5x.disable_channel(channel_index=cfg_ch_en, disable=False)
                    if result != 0:
                        print('Could not set Control register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['ch_en_all'] != '':
                    cfg_en = bool(row['ch_en_all'])
                    if cfg_en is True:
                        result = pac194x5x.disable_channel(channel_index=1, disable=False)
                        result = pac194x5x.disable_channel(channel_index=2, disable=False)
                        result = pac194x5x.disable_channel(channel_index=3, disable=False)
                        result = pac194x5x.disable_channel(channel_index=4, disable=False)
                        if result != 0:
                            print('Could not set Control register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                            result = bridge.Close()
                            exit()

                if row['smbus'] != '':
                    cfg_smbus = int(row['smbus'], 16)
                    result = pac194x5x.set_smbus(smbus_value=cfg_smbus)
                    if result != 0:
                        print('Could not set Smbus register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['neg_pwr_fsr'] != '':
                    cfg_fsr = int(row['neg_pwr_fsr'], 16)
                    result = pac194x5x.set_neg_pwr_fsr(fsr_value=cfg_fsr)
                    if result != 0:
                        print('Could not set Neg_Pwr_Fsr register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['slow'] != '':
                    cfg_slow = int(row['slow'], 16)
                    result = pac194x5x.set_slow(slow_value=cfg_slow)
                    if result != 0:
                        print('Could not set Slow register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['acc_config'] != '':
                    cfg_acc = int(row['acc_config'], 16)
                    result = pac194x5x.set_accum_config(accum_value=cfg_acc)
                    if result != 0:
                        print('Could not set Accum Config register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['alert1'] != '':
                    cfg_alert1 = int(row['alert1'], 16)
                    result = pac194x5x.set_slow_alert1(slow_value=cfg_alert1)
                    if result != 0:
                        print('Could not set Slow Alert1 register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['alert2'] != '':
                    cfg_alert2 = int(row['alert2'], 16)
                    result = pac194x5x.set_gpio_alert2(gpio_value=cfg_alert2)
                    if result != 0:
                        print('Could not set Slow Alert2 register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['acc_lim'] != '':
                    cfg_acc = int(row['acc_lim'], 16)
                    result = pac194x5x.set_acc_fullness_limits(limits_value=cfg_acc)
                    if result != 0:
                        print('Could not set Acc Fullness Limits register. \
                         Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['oc_ch1_lim'] != '':
                    cfg_oc_ch1 = float(row['oc_ch1_lim'])
                    result = pac194x5x.set_oc_limit(oc_value=cfg_oc_ch1, channel_index=1)
                    if result != 0:
                        print('Could not set OC Ch1 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['oc_ch2_lim'] != '':
                    cfg_oc_ch2 = float(row['oc_ch2_lim'])
                    result = pac194x5x.set_oc_limit(oc_value=cfg_oc_ch2, channel_index=2)
                    if result != 0:
                        print('Could not set OC Ch2 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['oc_ch3_lim'] != '':
                    cfg_oc_ch3 = float(row['oc_ch3_lim'])
                    result = pac194x5x.set_oc_limit(oc_value=cfg_oc_ch3, channel_index=3)
                    if result != 0:
                        print('Could not set OC Ch3 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['oc_ch4_lim'] != '':
                    cfg_oc_ch4 = float(row['oc_ch4_lim'])
                    result = pac194x5x.set_oc_limit(oc_value=cfg_oc_ch4, channel_index=4)
                    if result != 0:
                        print('Could not set OC Ch4 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['uc_ch1_lim'] != '':
                    cfg_uc_ch1 = float(row['uc_ch1_lim'])
                    result = pac194x5x.set_uc_limit(uc_value=cfg_uc_ch1, channel_index=1)
                    if result != 0:
                        print('Could not set UC Ch1 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['uc_ch2_lim'] != '':
                    cfg_uc_ch2 = float(row['uc_ch2_lim'])
                    result = pac194x5x.set_uc_limit(uc_value=cfg_uc_ch2, channel_index=2)
                    if result != 0:
                        print('Could not set UC Ch2 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['uc_ch3_lim'] != '':
                    cfg_uc_ch3 = float(row['uc_ch3_lim'])
                    result = pac194x5x.set_uc_limit(uc_value=cfg_uc_ch3, channel_index=3)
                    if result != 0:
                        print('Could not set UC Ch3 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['uc_ch4_lim'] != '':
                    cfg_uc_ch4 = float(row['uc_ch4_lim'])
                    result = pac194x5x.set_uc_limit(uc_value=cfg_uc_ch4, channel_index=4)
                    if result != 0:
                        print('Could not set UC Ch4 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['op_ch1_lim'] != '':
                    cfg_op_ch1 = float(row['op_ch1_lim'])
                    result = pac194x5x.set_op_limit(op_value=cfg_op_ch1, channel_index=1)
                    if result != 0:
                        print('Could not set OP Ch1 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['op_ch2_lim'] != '':
                    cfg_op_ch2 = float(row['op_ch2_lim'])
                    result = pac194x5x.set_op_limit(op_value=cfg_op_ch2, channel_index=2)
                    if result != 0:
                        print('Could not set OP Ch2 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['op_ch3_lim'] != '':
                    cfg_op_ch3 = float(row['op_ch3_lim'])
                    result = pac194x5x.set_op_limit(op_value=cfg_op_ch3, channel_index=3)
                    if result != 0:
                        print('Could not set OP Ch3 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['op_ch4_lim'] != '':
                    cfg_op_ch4 = float(row['op_ch4_lim'])
                    result = pac194x5x.set_op_limit(op_value=cfg_op_ch4, channel_index=4)
                    if result != 0:
                        print('Could not set OP Ch4 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['ov_ch1_lim'] != '':
                    cfg_ov_ch1 = float(row['ov_ch1_lim'])
                    result = pac194x5x.set_ov_limit(ov_value=cfg_ov_ch1, channel_index=1)
                    if result != 0:
                        print('Could not set OV Ch1 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['ov_ch2_lim'] != '':
                    cfg_ov_ch2 = float(row['ov_ch2_lim'])
                    result = pac194x5x.set_ov_limit(ov_value=cfg_ov_ch2, channel_index=2)
                    if result != 0:
                        print('Could not set OV Ch2 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['ov_ch3_lim'] != '':
                    cfg_ov_ch3 = float(row['ov_ch3_lim'])
                    result = pac194x5x.set_ov_limit(ov_value=cfg_ov_ch3, channel_index=3)
                    if result != 0:
                        print('Could not set OV Ch3 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['ov_ch4_lim'] != '':
                    cfg_ov_ch4 = float(row['ov_ch4_lim'])
                    result = pac194x5x.set_ov_limit(ov_value=cfg_ov_ch4, channel_index=4)
                    if result != 0:
                        print('Could not set OV Ch4 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['uv_ch1_lim'] != '':
                    cfg_uv_ch1 = float(row['uv_ch1_lim'])
                    result = pac194x5x.set_uv_limit(uv_value=cfg_uv_ch1, channel_index=1)
                    if result != 0:
                        print('Could not set UV Ch1 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['uv_ch2_lim'] != '':
                    cfg_uv_ch2 = float(row['uv_ch2_lim'])
                    result = pac194x5x.set_uv_limit(uv_value=cfg_uv_ch2, channel_index=2)
                    if result != 0:
                        print('Could not set UV Ch2 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['uv_ch3_lim'] != '':
                    cfg_uv_ch3 = float(row['uv_ch3_lim'])
                    result = pac194x5x.set_uv_limit(uv_value=cfg_uv_ch3, channel_index=3)
                    if result != 0:
                        print('Could not set UV Ch3 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['uv_ch4_lim'] != '':
                    cfg_uv_ch4 = float(row['uv_ch4_lim'])
                    result = pac194x5x.set_uv_limit(uv_value=cfg_uv_ch4, channel_index=4)
                    if result != 0:
                        print('Could not set UV Ch4 Limit register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['oc_nsamp'] != '':
                    cfg_oc_nsamp = int(row['oc_nsamp'], 16)
                    result = pac194x5x.set_oc_limit_nsamples(nsamples_value=cfg_oc_nsamp)
                    if result != 0:
                        print('Could not set OC Limit Nsamples register. \
                              Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['uc_nsamp'] != '':
                    cfg_uc_nsamp = int(row['uc_nsamp'], 16)
                    result = pac194x5x.set_uc_limit_nsamples(nsamples_value=cfg_uc_nsamp)
                    if result != 0:
                        print('Could not set UC Limit Nsamples register. \
                              Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['op_nsamp'] != '':
                    cfg_op_nsamp = int(row['op_nsamp'], 16)
                    result = pac194x5x.set_op_limit_nsamples(nsamples_value=cfg_op_nsamp)
                    if result != 0:
                        print('Could not set OP Limit Nsamples register. \
                              Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['ov_nsamp'] != '':
                    cfg_ov_nsamp = int(row['ov_nsamp'], 16)
                    result = pac194x5x.set_ov_limit_nsamples(nsamples_value=cfg_ov_nsamp)
                    if result != 0:
                        print('Could not set OV Limit Nsamples register. \
                              Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['uv_nsamp'] != '':
                    cfg_uv_nsamp = int(row['uv_nsamp'], 16)
                    result = pac194x5x.set_uv_limit_nsamples(nsamples_value=cfg_uv_nsamp)
                    if result != 0:
                        print('Could not set UV Limit Nsamples register. \
                              Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()

                if row['alert_en'] != '':
                    cfg_alert_en = int(row['alert_en'], 16)
                    result = pac194x5x.set_alert_enable(alert_value=cfg_alert_en)
                    if result != 0:
                        print('Could not set Alert Enable register. Error code: %d. Exit.' % pac194x5x.get_last_error())
                        result = bridge.Close()
                        exit()
                pac194x5x_list.append(pac194x5x)
            print("Number of PAC194x5x devices: %d" % len(pac194x5x_list))

    # connection check
    for pac194x5x in pac194x5x_list:
        prod_id = pac194x5x.get_product_id()
        man_id = pac194x5x.get_manufacturer_id()
        rev_id = pac194x5x.get_revision_id()

        if (prod_id is not None) & (man_id is not None) & (rev_id is not None):
            print('\nCommands sent successful!\n')
            print('PAC194x5x: %#x' % pac194x5x.i2c_address)
            print('Product ID: %#x' % prod_id)
            print('Manufacturer ID: %#x' % man_id)
            print('Revision ID: %#x' % rev_id)
        else:
            print('Cannot access PAC194x5x. Error code: %d. Exit.' % pac194x5x.get_last_error())
            result = bridge.Close()
            exit()

    # reset the accumulator
    for pac194x5x in pac194x5x_list:
        result = pac194x5x.refresh(delay=refresh_delay)
        if result != 0:
            print('Cannot access PAC194x5x. Error code: %d. Exit.' % result)
            result = bridge.Close()
            exit()

    if log_feature is True:
        with open(csv_name, 'w', newline='\n') as csvfile:
            csv_writer = csv.DictWriter(csvfile, fieldnames=csv_log_info, extrasaction='ignore', dialect='excel')
            csv_writer.writeheader()

    target_pac194x5x = 0
    for pac194x5x in pac194x5x_list:
        if pac194x5x.i2c_address == i2c_addr:
            target_pac194x5x = pac194x5x

    if target_pac194x5x == 0:
        print('Cannot find PAC194x5x with the same I2C address as the one provided in the cmd arguments.')
        res = bridge.Close()
        exit()
    
    if identify_part is True:
        res = target_pac194x5x.get_product_id()
        if res == target_pac194x5x.PAC1941_PRODUCT_ID:
            part = 'PAC1941'
        elif res == target_pac194x5x.PAC1942_1_PRODUCT_ID:
            part = 'PAC1942_1'
        elif res == target_pac194x5x.PAC1943_PRODUCT_ID:
            part = 'PAC1943'
        elif res == target_pac194x5x.PAC1944_PRODUCT_ID:
            part = 'PAC1944-1'
        elif res == target_pac194x5x.PAC1941_2_PRODUCT_ID:
            part = 'PAC1941_2'
        elif res == target_pac194x5x.PAC1942_2_PRODUCT_ID:
            part = 'PAC1942_2'
        elif res == target_pac194x5x.PAC1951_PRODUCT_ID:
            part = 'PAC1951'
        elif res == target_pac194x5x.PAC1952_1_PRODUCT_ID:
            part = 'PAC1952_1'
        elif res == target_pac194x5x.PAC1953_PRODUCT_ID:
            part = 'PAC1953'
        elif res == target_pac194x5x.PAC1954_PRODUCT_ID:
            part = 'PAC1954'
        elif res == target_pac194x5x.PAC1951_2_PRODUCT_ID:
            part = 'PAC1951_2'
        elif res == target_pac194x5x.PAC1952_2_PRODUCT_ID:
            part = 'PAC1952_2'
        else:
            part = ''
        print('\nPart Identity: ' + part + '\n')

    if read_regs is True:
        display_regs(target_pac194x5x)
    else:
        if (app_mode is True) & (cont_reading is False):
            print('\nKey press menu (NOT case sensitive):')
            print('\tR -> execute REFRESH')
            print('\tG -> execute REFRESH_G')
            print('\tV -> execute REFRESH_V')
            print('\tA -> execute acquisition')
            print('\tM -> execute acquisition with manual refresh')
            print('\tC -> get registers')
            print('\tH -> display Key press menu')
            if log_feature is True:
                if log_pause == 0:
                    print('\tL -> PAUSE csv log recording')
                else:
                    print('\tL -> RESUME csv log recording')
            print('\tX -> EXIT application!')

            app_exit = False
            while not app_exit:
                wait_kbinput = True
                while wait_kbinput is True:
                    if msvcrt.kbhit():
                        kbinput = msvcrt.getwch().upper()
                        if kbinput[0] == 'R':
                            print("'R' key pressed.\n")
                            res = target_pac194x5x.send_refresh(refresh_type=0, delay=refresh_delay)
                            if res != 0:
                                print('Cannot access PAC194x5x. Error code: %d. Exit.' % result)
                                result = bridge.Close()
                                exit()
                            else:
                                print('Refresh sent!')
                            break
                        elif kbinput[0] == 'G':
                            print("'G' key pressed.\n")
                            res = target_pac194x5x.send_refresh(refresh_type=1, delay=refresh_delay)
                            if res != 0:
                                print('Cannot access PAC194x5x. Error code: %d. Exit.' % result)
                                result = bridge.Close()
                                exit()
                            else:
                                print('Refresh G sent!')
                            break
                        elif kbinput[0] == 'V':
                            print("'V' key pressed.\n")
                            res = target_pac194x5x.send_refresh(refresh_type=2, delay=refresh_delay)
                            if res != 0:
                                print('Cannot access PAC194x5x. Error code: %d. Exit.' % result)
                                result = bridge.Close()
                                exit()
                            else:
                                print('Refresh V sent!')
                            break
                        elif kbinput[0] == 'A':
                            print("'A' key pressed.\n")
                            if display_minimal is True:
                                if avg_values is False:
                                    print("{:<38}{:<38}{:<38}{:<32}".format("CH1", "CH2", "CH3", "CH4"))
                                    print("{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}{:<2}"
                                          "{:<12}{:<12}{:<12}".format("VBUS", "VSENSE", "VPOWER", "#", "VBUS", "VSENSE",
                                                                      "VPOWER", "#", "VBUS", "VSENSE", "VPOWER", "#",
                                                                      "VBUS", "VSENSE", "VPOWER"))
                                else:
                                    print("{:<38}{:<38}{:<38}{:<30}".format("CH1", "CH2", "CH3", "CH4"))
                                    print("{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}{:<2}"
                                          "{:<12}{:<12}{:<12}".format("VBUS AVG", "VSENSE AVG", "VPOWER", "#", "VBUS AVG",
                                                                      "VSENSE AVG",
                                                                      "VPOWER", "#", "VBUS AVG", "VSENSE AVG", "VPOWER",
                                                                      "#",
                                                                      "VBUS AVG", "VSENSE AVG", "VPOWER"))

                            display_data(target_pac194x5x, bridge, refresh_type, refresh_delay, refresh_period,
                                         readings_number, log_feature, log_pause, csv_name, display_minimal, avg_values)
                            break
                        elif kbinput[0] == 'M':
                            print("'M' key pressed.\n")
                            if display_minimal is True:
                                if avg_values is False:
                                    print("{:<38}{:<38}{:<38}{:<32}".format("CH1", "CH2", "CH3", "CH4"))
                                    print("{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}{:<2}"
                                          "{:<12}{:<12}{:<12}".format("VBUS", "VSENSE", "VPOWER", "#", "VBUS", "VSENSE",
                                                                      "VPOWER", "#", "VBUS", "VSENSE", "VPOWER", "#",
                                                                      "VBUS", "VSENSE", "VPOWER"))
                                else:
                                    print("{:<38}{:<38}{:<38}{:<30}".format("CH1", "CH2", "CH3", "CH4"))
                                    print("{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}{:<2}"
                                          "{:<12}{:<12}{:<12}".format("VBUS AVG", "VSENSE AVG", "VPOWER", "#", "VBUS AVG",
                                                                      "VSENSE AVG",
                                                                      "VPOWER", "#", "VBUS AVG", "VSENSE AVG", "VPOWER",
                                                                      "#",
                                                                      "VBUS AVG", "VSENSE AVG", "VPOWER"))

                            ref_type = -1
                            ref_delay = -1
                            display_data(target_pac194x5x, bridge, ref_type, ref_delay, refresh_period,
                                         readings_number, log_feature, log_pause, csv_name, display_minimal, avg_values)
                            break
                        elif kbinput[0] == 'H':
                            print("'H' key pressed.\n")
                            print('\nKey press menu:')
                            print('    -\'R\' -> execute REFRESH')
                            print('    -\'G\' -> execute REFRESH_G')
                            print('    -\'V\' -> execute REFRESH_V')
                            print('    -\'A\' -> execute acquisition')
                            print('    -\'C\' -> get registers')
                            print('    -\'H\' -> display Key press menu')
                            if log_feature is True:
                                if log_pause == 0:
                                    print('    -\'L\' -> PAUSE csv log recording')
                                else:
                                    print('    -\'L\' -> RESUME csv log recording')
                            print('    -\'X\' -> EXIT application!')
                            break
                        elif kbinput[0] == 'C':
                            print("'C' key pressed.\n")
                            display_regs(target_pac194x5x)
                            break
                        elif (log_feature is True) & (kbinput[0] == 'L'):
                            print("'L' key pressed.\n")
                            log_pause ^= 1  # PAUSE/RESUME csv recording
                            if log_pause == 0:
                                print('csv log recording RESUMED')
                            else:
                                print('csv log recording PAUSED')
                        elif kbinput[0] == 'X':
                            print("'X' key pressed.\n")
                            app_exit = True
                            wait_kbinput = False
                            break
        else:
            if display_minimal is True:
                if avg_values is False:
                    print("{:<38}{:<38}{:<38}{:<32}".format("CH1", "CH2", "CH3", "CH4"))
                    print("{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}{:<2}"
                          "{:<12}{:<12}{:<12}".format("VBUS", "VSENSE", "VPOWER", "#", "VBUS", "VSENSE",
                                                      "VPOWER", "#", "VBUS", "VSENSE", "VPOWER", "#",
                                                      "VBUS", "VSENSE", "VPOWER"))
                else:
                    print("{:<38}{:<38}{:<38}{:<30}".format("CH1", "CH2", "CH3", "CH4"))
                    print("{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}{:<2}{:<12}{:<12}{:<12}{:<2}"
                          "{:<12}{:<12}{:<12}".format("VBUS AVG", "VSENSE AVG", "VPOWER", "#", "VBUS AVG", "VSENSE AVG",
                                                      "VPOWER", "#", "VBUS AVG", "VSENSE AVG", "VPOWER", "#",
                                                      "VBUS AVG", "VSENSE AVG", "VPOWER"))
            if cont_reading is False:
                display_data(target_pac194x5x, bridge, refresh_type, refresh_delay, refresh_period,
                             readings_number, log_feature, log_pause, csv_name, display_minimal, avg_values)
            else:
                app_exit = False
                while not app_exit:
                    display_data(target_pac194x5x, bridge, refresh_type, refresh_delay, refresh_period,
                                 readings_number=1, log_feature=log_feature, log_pause=log_pause, csv_name=csv_name,
                                 display_min=display_minimal, display_avg=avg_values)
                    wait_kbinput = True
                    while wait_kbinput is True:
                        if msvcrt.kbhit():
                            kbinput = msvcrt.getwch().upper()
                            if (log_feature is True) & (kbinput[0] == 'L'):
                                log_pause ^= 1  # PAUSE/RESUME csv recording
                                if log_pause == 0:
                                    print('csv log recording RESUMED')
                                else:
                                    print('csv log recording PAUSED')
                            elif kbinput[0] == 'X':
                                app_exit = True
                                # wait_kbinput = False
                                break
                        if refresh_period >= 0:
                            wait_kbinput = False

    result = bridge.Close()
    print('\nClose bridge result: %d' % result)
    # exit()


if __name__ == '__main__':
    main()
